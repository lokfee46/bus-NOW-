package hk.busnow.app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import hk.busnow.app.data.EtaCache;
import hk.busnow.app.data.Pins;
import hk.busnow.app.data.Prefs;
import hk.busnow.app.data.Seed;
import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Pin;
import hk.busnow.app.net.Refresh;
import hk.busnow.app.ui.AuroraBackground;
import hk.busnow.app.ui.Dock;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Style;
import hk.busnow.app.ui.Ui;
import hk.busnow.app.util.Clock;

/** Home: pinned arrivals, refreshed in place, rendered from cache on the very first frame. */
public class MainActivity extends BaseActivity implements Refresh.Listener {

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, Arrivals> arrivals = new HashMap<String, Arrivals>();
    private final Map<String, String> errors = new HashMap<String, String>();
    private final ExecutorService io = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "busnow-io");
            t.setDaemon(true);
            return t;
        }
    });

    private List<Pin> pins = new ArrayList<Pin>();
    private PinRow adapter;
    private ListView list;
    private TextView updated;
    private View refreshButton;
    private Refresh refresh;
    private boolean refreshing;
    private boolean resumed;
    private long lastStartAt;
    private int lang;
    private int appliedLang;
    private int appliedTheme;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (adapter != null) {
                adapter.updateVisible();
            }
            updateHeader();
            main.postDelayed(this, 1000L);
        }
    };

    private final Runnable autoRefresh = new Runnable() {
        @Override
        public void run() {
            doRefresh(false);
            main.postDelayed(this, Math.max(10, Prefs.interval(MainActivity.this)) * 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final long startUptime = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
                ? Process.getStartUptimeMillis() : SystemClock.uptimeMillis();
        setContentView(R.layout.activity_main);

        View content = findViewById(R.id.content);
        Ui.edgeToEdge(this, content);

        lang = L.lang(this);
        appliedLang = Prefs.lang(this);
        appliedTheme = Prefs.theme(this);
        pins = Pins.load(this);

        list = (ListView) findViewById(R.id.list);
        list.setDivider(null);
        list.setSelector(android.R.color.transparent);
        list.setCacheColorHint(0);
        adapter = new PinRow(this, pins, arrivals, errors, lang, list);
        list.setAdapter(adapter);
        list.setEmptyView(findViewById(R.id.empty));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openStop(pins.get(position));
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showPinMenu(pins.get(position));
                return true;
            }
        });

        updated = (TextView) findViewById(R.id.updated);
        refreshButton = findViewById(R.id.refresh);
        Style.iconButton(refreshButton, getResources().getColor(R.color.ink2));
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doRefresh(true);
                scheduleAutoRefresh();
            }
        });

        View search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });
        findViewById(R.id.emptyCta).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });

        Dock dock = (Dock) findViewById(R.id.dock);
        dock.setOnPick(new Dock.OnPick() {
            @Override
            public void onPick(int tab) {
                switch (tab) {
                    case Dock.SEARCH:
                        startActivity(new Intent(MainActivity.this, SearchActivity.class));
                        break;
                    case Dock.NEARBY:
                        startActivity(new Intent(MainActivity.this, NearbyActivity.class));
                        break;
                    case Dock.SETTINGS:
                        startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                        break;
                    default:
                        break;
                }
            }
        });

        AuroraBackground aurora = (AuroraBackground) findViewById(R.id.aurora);
        aurora.setAnimate(Prefs.animationsEnabled(this));

        if (L.isSmallScreen(this)) {
            tightenForSmallScreen(dock);
        }

        Seed.preload(this);
        loadCache();
        measureFirstFrame(startUptime);
    }

    /** Smallest phones and watch-class screens: less chrome, more rows. */
    private void tightenForSmallScreen(Dock dock) {
        findViewById(R.id.tagline).setVisibility(View.GONE);
        View header = findViewById(R.id.header);
        header.setPadding(Ui.dpi(this, 12), Ui.dpi(this, 6), Ui.dpi(this, 12), Ui.dpi(this, 6));
        View search = findViewById(R.id.search);
        ViewGroup.LayoutParams lp = search.getLayoutParams();
        lp.height = Ui.dpi(this, 42);
        ((ViewGroup.MarginLayoutParams) lp).leftMargin = Ui.dpi(this, 10);
        ((ViewGroup.MarginLayoutParams) lp).rightMargin = Ui.dpi(this, 10);
        search.setLayoutParams(lp);
        ViewGroup.LayoutParams dlp = dock.getLayoutParams();
        dlp.height = Ui.dpi(this, 46);
        ((ViewGroup.MarginLayoutParams) dlp).leftMargin = Ui.dpi(this, 8);
        ((ViewGroup.MarginLayoutParams) dlp).rightMargin = Ui.dpi(this, 8);
        ((ViewGroup.MarginLayoutParams) dlp).bottomMargin = Ui.dpi(this, 6);
        dock.setLayoutParams(dlp);
        dock.setCompact(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Prefs.lang(this) != appliedLang || Prefs.theme(this) != appliedTheme) {
            recreate();
            return;
        }
        refreshedPins();
        resumed = true;
        refresh = new Refresh();
        main.removeCallbacks(ticker);
        main.post(ticker);
        doRefresh(false);
        scheduleAutoRefresh();
    }

    @Override
    protected void onPause() {
        resumed = false;
        main.removeCallbacks(ticker);
        main.removeCallbacks(autoRefresh);
        if (refresh != null) {
            refresh.cancel();
        }
        refreshing = false;
        if (refreshButton != null) {
            refreshButton.setAlpha(1f);
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    private void refreshedPins() {
        List<Pin> fresh = Pins.load(this);
        boolean same = fresh.size() == pins.size();
        if (same) {
            for (int i = 0; i < pins.size(); i++) {
                if (!pins.get(i).key().equals(fresh.get(i).key())) {
                    same = false;
                    break;
                }
            }
        }
        if (!same) {
            pins.clear();
            pins.addAll(fresh);
            adapter.notifyDataSetChanged();
        }
    }

    private void scheduleAutoRefresh() {
        main.removeCallbacks(autoRefresh);
        if (resumed) {
            main.postDelayed(autoRefresh, Math.max(10, Prefs.interval(this)) * 1000L);
        }
    }

    private void doRefresh(boolean manual) {
        if (refresh == null || refreshing) {
            return;
        }
        if (pins.isEmpty()) {
            updateHeader();
            return;
        }
        if (!manual && System.currentTimeMillis() - lastStartAt < 1500L) {
            return;
        }
        refreshing = true;
        lastStartAt = System.currentTimeMillis();
        refreshButton.setAlpha(0.45f);
        refresh.pins(pins, lang, this);
    }

    @Override
    public void onArrivals(String pinKey, Arrivals a) {
        if (a.ok()) {
            arrivals.put(pinKey, a);
            errors.remove(pinKey);
        } else {
            errors.put(pinKey, a.error == null ? "offline" : a.error);
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onDone() {
        refreshing = false;
        refreshButton.setAlpha(1f);
        updateHeader();
        saveCache();
    }

    private void updateHeader() {
        long newest = 0;
        for (Arrivals a : arrivals.values()) {
            if (a.fetchedAt > newest) {
                newest = a.fetchedAt;
            }
        }
        if (newest == 0) {
            updated.setText("");
            return;
        }
        long age = Math.max(0, Clock.now() - newest) / 1000L;
        updated.setText(getString(R.string.updated_ago, L.ago(this, newest, Clock.now())));
        updated.setTextColor(getResources().getColor(age > 180 ? R.color.warn : R.color.ink3));
    }

    private void loadCache() {
        io.execute(new Runnable() {
            @Override
            public void run() {
                final Map<String, Arrivals> cached = EtaCache.load(MainActivity.this);
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        for (Map.Entry<String, Arrivals> e : cached.entrySet()) {
                            if (!arrivals.containsKey(e.getKey())) {
                                arrivals.put(e.getKey(), e.getValue());
                            }
                        }
                        adapter.notifyDataSetChanged();
                        updateHeader();
                    }
                });
            }
        });
    }

    private void saveCache() {
        final Map<String, Arrivals> snapshot = new HashMap<String, Arrivals>(arrivals);
        io.execute(new Runnable() {
            @Override
            public void run() {
                EtaCache.save(MainActivity.this, snapshot);
            }
        });
    }

    private void measureFirstFrame(long startUptime) {
        final View decor = getWindow().getDecorView();
        decor.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                decor.getViewTreeObserver().removeOnPreDrawListener(this);
                long ms = SystemClock.uptimeMillis() - startUptime;
                if (ms > 0 && ms < 30000) {
                    Prefs.setColdStartMs(MainActivity.this, ms);
                }
                return true;
            }
        });
    }

    private void openStop(Pin pin) {
        int idx = pin.stopIdx;
        if (idx < 0) {
            SeedFormat s = Seed.peek();
            if (s != null) {
                idx = s.findStop(pin.op, pin.stopKey);
            }
        }
        if (idx >= 0) {
            StopActivity.start(this, idx);
        }
    }

    private void showPinMenu(final Pin pin) {
        final String[] items = {getString(R.string.move_top), getString(R.string.remove)};
        new AlertDialog.Builder(this)
                .setTitle(pin.route + "  " + pin.dest(lang))
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            pins.remove(pin);
                            pins.add(0, pin);
                        } else {
                            pins.remove(pin);
                            arrivals.remove(pin.key());
                            errors.remove(pin.key());
                        }
                        Pins.save(MainActivity.this, pins);
                        adapter.notifyDataSetChanged();
                        doRefresh(true);
                    }
                })
                .show();
    }
}
