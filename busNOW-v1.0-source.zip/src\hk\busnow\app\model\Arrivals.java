package hk.busnow.app.model;

/** A refresh result for one route/stop pair. */
public final class Arrivals {

    public static final Arrivals EMPTY = new Arrivals(new Eta[0], 0, 0, null);

    public final Eta[] list;
    /** Local receive time (millis) of the response that produced this list. */
    public final long fetchedAt;
    /** Newest data_timestamp reported by the operator. */
    public final long dataTs;
    /** Non-null when the refresh failed; [list] may then hold the previous good data. */
    public final String error;

    public Arrivals(Eta[] list, long fetchedAt, long dataTs, String error) {
        this.list = list == null ? new Eta[0] : list;
        this.fetchedAt = fetchedAt;
        this.dataTs = dataTs;
        this.error = error;
    }

    public boolean ok() {
        return error == null;
    }
}
