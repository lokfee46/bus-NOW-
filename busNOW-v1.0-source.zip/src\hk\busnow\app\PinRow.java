package hk.busnow.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Eta;
import hk.busnow.app.model.Pin;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Style;
import hk.busnow.app.ui.Ui;
import hk.busnow.app.util.Clock;
import hk.busnow.app.util.TimeUtil;

/** Rows of the home screen: one pinned route/stop each. */
final class PinRow extends BaseAdapter {

    static final class H {
        TextView badge;
        TextView dest;
        TextView stop;
        TextView age;
        TextView flag;
        TextView primary;
        TextView unit;
        TextView secondary;
        Pin pin;
    }

    private final Context c;
    private final List<Pin> pins;
    private final Map<String, Arrivals> arrivals;
    private final Map<String, String> errors;
    private final int lang;
    private final boolean compact;
    private final ListView list;
    private final int inkColor;
    private final int ink2Color;
    private final int ink3Color;
    private final int warnColor;

    PinRow(Context c, List<Pin> pins, Map<String, Arrivals> arrivals, Map<String, String> errors,
           int lang, ListView list) {
        this.c = c;
        this.pins = pins;
        this.arrivals = arrivals;
        this.errors = errors;
        this.lang = lang;
        this.list = list;
        this.compact = L.isSmallScreen(c);
        this.inkColor = c.getResources().getColor(R.color.ink);
        this.ink2Color = c.getResources().getColor(R.color.ink2);
        this.ink3Color = c.getResources().getColor(R.color.ink3);
        this.warnColor = c.getResources().getColor(R.color.warn);
    }

    @Override
    public int getCount() {
        return pins.size();
    }

    @Override
    public Object getItem(int position) {
        return pins.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(c).inflate(R.layout.item_pin, parent, false);
            H h = new H();
            h.badge = (TextView) v.findViewById(R.id.route_badge);
            h.dest = (TextView) v.findViewById(R.id.dest);
            h.stop = (TextView) v.findViewById(R.id.stop_name);
            h.age = (TextView) v.findViewById(R.id.age);
            h.flag = (TextView) v.findViewById(R.id.flag);
            h.primary = (TextView) v.findViewById(R.id.primary);
            h.unit = (TextView) v.findViewById(R.id.unit);
            h.secondary = (TextView) v.findViewById(R.id.secondary);
            h.primary.setFontFeatureSettings("tnum");
            h.secondary.setFontFeatureSettings("tnum");
            h.primary.setTextColor(inkColor);
            h.dest.setTextColor(inkColor);
            h.stop.setTextColor(ink2Color);
            h.age.setTextColor(ink3Color);
            h.secondary.setTextColor(ink2Color);
            h.unit.setTextColor(ink2Color);
            Style.chip(h.flag, c.getResources().getColor(R.color.accent),
                    Ui.alpha(c.getResources().getColor(R.color.accent), 0x1F));
            h.flag.setText(R.string.scheduled_badge);
            h.flag.setSingleLine(true);
            h.flag.setMaxWidth(Ui.dpi(c, 78));
            h.flag.setEllipsize(android.text.TextUtils.TruncateAt.END);
            v.setTag(h);
        }
        H h = (H) v.getTag();
        Pin p = pins.get(position);
        h.pin = p;
        Style.routeBadge(h.badge, p.op);
        h.badge.setText(p.route);
        h.badge.setTextSize(compact ? 12.5f : 14f);
        h.dest.setText(p.dest(lang));
        h.dest.setTextSize(compact ? 13f : 15f);
        h.stop.setText(L.opName(c, p.op) + " · " + p.stopName(lang));
        h.stop.setTextSize(compact ? 10f : 11.5f);
        bindTimes(h);
        return v;
    }

    void bindTimes(H h) {
        if (h.pin == null) {
            return;
        }
        long now = Clock.now();
        Arrivals a = arrivals.get(h.pin.key());
        String err = errors.get(h.pin.key());
        if (a == null || a.list.length == 0) {
            boolean noService = a != null && a.ok();
            setSmallPrimary(h, noService ? c.getString(R.string.no_arrivals) : "—");
            h.unit.setText("");
            h.secondary.setText("");
            h.age.setText(err == null ? "" : c.getString(R.string.offline_cached));
            h.age.setTextColor(err == null ? ink3Color : warnColor);
            h.flag.setVisibility(View.GONE);
            return;
        }
        Eta e0 = a.list[0];
        int start = L.firstUpcoming(a.list, now);
        if (start < 0) {
            setSmallPrimary(h, c.getString(R.string.departed));
            h.unit.setText("");
            h.secondary.setText("");
            h.age.setText(err != null ? c.getString(R.string.offline_cached)
                    : TimeUtil.hhmm(e0.etaMs) + " · " + L.ago(c, a.fetchedAt, now));
            h.age.setTextColor(err != null ? warnColor : ink3Color);
            h.flag.setVisibility(View.GONE);
            return;
        }
        e0 = a.list[start];
        int m = L.etaMinutes(e0.etaMs, now);
        if (m >= 0) {
            h.primary.setText(String.valueOf(m));
            h.primary.setTextSize(compact ? 24f : 30f);
            h.primary.setMaxWidth(Integer.MAX_VALUE);
            h.unit.setText(R.string.minute_unit);
        } else {
            setSmallPrimary(h, c.getString(m == L.ARRIVING ? R.string.arriving : R.string.departed));
            h.unit.setText("");
        }

        StringBuilder sb = new StringBuilder();
        for (int i = start + 1; i < a.list.length && i < start + 3; i++) {
            if (sb.length() > 0) {
                sb.append(" · ");
            }
            int mm = L.etaMinutes(a.list[i].etaMs, now);
            sb.append(mm >= 0 ? String.valueOf(mm) : "—");
        }
        h.secondary.setText(sb);
        h.secondary.setVisibility(sb.length() == 0 ? View.INVISIBLE : View.VISIBLE);

        if (err != null) {
            h.age.setText(c.getString(R.string.offline_cached));
            h.age.setTextColor(warnColor);
        } else {
            h.age.setText(TimeUtil.hhmm(e0.etaMs) + " · " + L.ago(c, a.fetchedAt, now));
            h.age.setTextColor(ink3Color);
        }
        h.flag.setVisibility(e0.scheduled && err == null ? View.VISIBLE : View.GONE);
    }

    private void setSmallPrimary(H h, String text) {
        h.primary.setText(text);
        h.primary.setTextSize(compact ? 12f : 13f);
        h.primary.setMaxWidth(compact ? Ui.dpi(c, 78) : Ui.dpi(c, 108));
    }

    /** Called once per second: re-binds only what changes, and only for visible rows. */
    void updateVisible() {
        for (int i = 0; i < list.getChildCount(); i++) {
            View v = list.getChildAt(i);
            Object tag = v.getTag();
            if (tag instanceof H) {
                bindTimes((H) tag);
            }
        }
    }

    int operatorOf(int position) {
        return pins.get(position).op;
    }

    /** Only used by the stop detail screen to show a compact operator suffix. */
    static String opSuffix(Context c, int op) {
        return op == SeedFormat.OP_CTB ? "CTB" : "KMB";
    }
}
