package hk.busnow.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.ui.L;

/** Nearby stops, nearest first. */
final class NearbyRow extends BaseAdapter {

    private final Context c;
    private final SeedFormat seed;
    private final int lang;
    private final double lat;
    private final double lon;
    private int[] stops = new int[0];

    NearbyRow(Context c, SeedFormat seed, int lang, double lat, double lon) {
        this.c = c;
        this.seed = seed;
        this.lang = lang;
        this.lat = lat;
        this.lon = lon;
    }

    void setData(int[] stops) {
        this.stops = stops == null ? new int[0] : stops;
        notifyDataSetChanged();
    }

    int stopAt(int position) {
        return stops[position];
    }

    @Override
    public int getCount() {
        return stops.length;
    }

    @Override
    public Object getItem(int position) {
        return Integer.valueOf(stops[position]);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(c).inflate(R.layout.item_nearby, parent, false);
            H h = new H();
            h.title = (TextView) v.findViewById(R.id.title);
            h.subtitle = (TextView) v.findViewById(R.id.subtitle);
            h.distance = (TextView) v.findViewById(R.id.distance);
            v.setTag(h);
        }
        H h = (H) v.getTag();
        int si = stops[position];
        h.title.setText(seed.stopName(si, lang));
        h.subtitle.setText(L.opName(c, seed.stopOp[si]));
        h.distance.setText(L.distance(c, seed.distanceTo(si, lat, lon)));
        return v;
    }

    private static final class H {
        TextView title;
        TextView subtitle;
        TextView distance;
    }
}
