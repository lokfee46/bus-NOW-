'use strict';
/*
 * Pack classes.dex into the base APK produced by aapt2 and keep stored (uncompressed) entries
 * 4-byte aligned. Every entry is copied verbatim (compression method preserved), so resources.arsc
 * stays stored + aligned as required by targetSdk 30+.
 *
 * usage: node pack.js <base.apk> <classes.dex> <out.apk>
 */
const fs = require('fs');
const zlib = require('zlib');

function die(msg) {
  console.error('pack: ' + msg);
  process.exit(1);
}

const [, , baseApk, dexFile, outApk] = process.argv;
if (!baseApk || !dexFile || !outApk) {
  die('usage: node pack.js <base.apk> <classes.dex> <out.apk>');
}

const src = fs.readFileSync(baseApk);

let eocd = -1;
const minPos = Math.max(0, src.length - 22 - 65536);
for (let i = src.length - 22; i >= minPos; i--) {
  if (src.readUInt32LE(i) === 0x06054b50) {
    eocd = i;
    break;
  }
}
if (eocd < 0) {
  die('EOCD not found');
}
const total = src.readUInt16LE(eocd + 10);
const cdOff = src.readUInt32LE(eocd + 16);
if (cdOff === 0xffffffff) {
  die('zip64 is not supported');
}

const entries = [];
let p = cdOff;
for (let i = 0; i < total; i++) {
  if (src.readUInt32LE(p) !== 0x02014b50) {
    die('bad central directory signature at ' + p);
  }
  const e = {
    versionMadeBy: src.readUInt16LE(p + 4),
    versionNeeded: src.readUInt16LE(p + 6),
    flags: src.readUInt16LE(p + 8),
    method: src.readUInt16LE(p + 10),
    time: src.readUInt16LE(p + 12),
    date: src.readUInt16LE(p + 14),
    crc: src.readUInt32LE(p + 16),
    csize: src.readUInt32LE(p + 20),
    usize: src.readUInt32LE(p + 24),
    internal: src.readUInt16LE(p + 36),
    external: src.readUInt32LE(p + 38),
    localOff: src.readUInt32LE(p + 42),
  };
  const nameLen = src.readUInt16LE(p + 28);
  const extraLen = src.readUInt16LE(p + 30);
  const cmtLen = src.readUInt16LE(p + 32);
  e.nameBuf = Buffer.from(src.subarray(p + 46, p + 46 + nameLen));
  e.name = e.nameBuf.toString('utf8');
  if (e.flags & 0x08) {
    die('data descriptor flag not supported: ' + e.name);
  }
  if (e.method !== 0 && e.method !== 8) {
    die('unsupported method ' + e.method + ' for ' + e.name);
  }

  const lo = e.localOff;
  if (src.readUInt32LE(lo) !== 0x04034b50) {
    die('bad local header for ' + e.name);
  }
  const lNameLen = src.readUInt16LE(lo + 26);
  const lExtraLen = src.readUInt16LE(lo + 28);
  const dataOff = lo + 30 + lNameLen + lExtraLen;
  e.data = Buffer.from(src.subarray(dataOff, dataOff + e.csize));
  e.localExtra = Buffer.from(src.subarray(lo + 30 + lNameLen, dataOff));
  entries.push(e);
  p += 46 + nameLen + extraLen + cmtLen;
}

const dex = fs.readFileSync(dexFile);
const deflated = zlib.deflateRawSync(dex, { level: 9 });
const now = new Date();
const dosTime = ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)) & 0xffff;
const dosDate = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) & 0xffff;
entries.push({
  versionMadeBy: 20,
  versionNeeded: 20,
  flags: 0,
  method: 8,
  time: dosTime,
  date: dosDate,
  crc: zlib.crc32(dex) >>> 0,
  csize: deflated.length,
  usize: dex.length,
  internal: 0,
  external: 0x81A40000,
  nameBuf: Buffer.from('classes.dex', 'utf8'),
  name: 'classes.dex',
  data: deflated,
  localExtra: Buffer.alloc(0),
  isDex: true,
});

const out = [];
let offset = 0;
const put = (b) => {
  out.push(b);
  offset += b.length;
};
const written = [];

for (const e of entries) {
  let localExtra;
  if (e.method === 0) {
    const base = offset + 30 + e.nameBuf.length;
    const pad = (4 - (base % 4)) % 4;
    if (pad > 0) {
      const f = Buffer.alloc(pad + 4);
      f.writeUInt16LE(0xD935, 0);
      f.writeUInt16LE(pad, 2);
      localExtra = f;
    } else {
      localExtra = Buffer.alloc(0);
    }
  } else {
    localExtra = e.localExtra;
  }

  const lh = Buffer.alloc(30);
  lh.writeUInt32LE(0x04034b50, 0);
  lh.writeUInt16LE(e.versionNeeded, 4);
  lh.writeUInt16LE(e.flags & ~0x08, 6);
  lh.writeUInt16LE(e.method, 8);
  lh.writeUInt16LE(e.time, 10);
  lh.writeUInt16LE(e.date, 12);
  lh.writeUInt32LE(e.crc, 14);
  lh.writeUInt32LE(e.csize, 18);
  lh.writeUInt32LE(e.usize, 22);
  lh.writeUInt16LE(e.nameBuf.length, 26);
  lh.writeUInt16LE(localExtra.length, 28);

  const localOff = offset;
  put(lh);
  put(e.nameBuf);
  put(localExtra);
  put(e.data);

  const dataOffset = localOff + 30 + e.nameBuf.length + localExtra.length;
  if (e.method === 0 && dataOffset % 4 !== 0) {
    die('alignment failed for ' + e.name);
  }
  written.push({ e, localOff, localExtra });
}

const cdStart = offset;
for (const w of written) {
  const e = w.e;
  const ch = Buffer.alloc(46);
  ch.writeUInt32LE(0x02014b50, 0);
  ch.writeUInt16LE(e.versionMadeBy || 20, 4);
  ch.writeUInt16LE(e.versionNeeded, 6);
  ch.writeUInt16LE(e.flags & ~0x08, 8);
  ch.writeUInt16LE(e.method, 10);
  ch.writeUInt16LE(e.time, 12);
  ch.writeUInt16LE(e.date, 14);
  ch.writeUInt32LE(e.crc, 16);
  ch.writeUInt32LE(e.csize, 20);
  ch.writeUInt32LE(e.usize, 24);
  ch.writeUInt16LE(e.nameBuf.length, 28);
  ch.writeUInt16LE(w.localExtra.length, 30);
  ch.writeUInt16LE(0, 32);
  ch.writeUInt16LE(0, 34);
  ch.writeUInt16LE(e.internal || 0, 36);
  ch.writeUInt32LE(e.external || 0, 38);
  ch.writeUInt32LE(w.localOff, 42);
  put(ch);
  put(e.nameBuf);
  put(w.localExtra);
}
const cdSize = offset - cdStart;

const end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50, 0);
end.writeUInt16LE(0, 4);
end.writeUInt16LE(0, 6);
end.writeUInt16LE(entries.length, 8);
end.writeUInt16LE(entries.length, 10);
end.writeUInt32LE(cdSize, 12);
end.writeUInt32LE(cdStart, 16);
end.writeUInt16LE(0, 20);
put(end);

fs.writeFileSync(outApk, Buffer.concat(out));

const arsc = written.find((w) => w.e.name === 'resources.arsc');
if (!arsc) {
  die('resources.arsc missing');
}
console.log('packed ' + entries.length + ' entries -> ' + outApk);
console.log('  classes.dex: ' + (deflated.length / 1024).toFixed(1) + ' KB deflated / ' +
  (dex.length / 1024).toFixed(1) + ' KB raw');
console.log('  resources.arsc: method=' + arsc.e.method +
  ' dataOffset%4=' + ((arsc.localOff + 30 + arsc.e.nameBuf.length + arsc.localExtra.length) % 4));
