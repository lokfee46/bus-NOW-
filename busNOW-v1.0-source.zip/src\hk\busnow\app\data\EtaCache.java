package hk.busnow.app.data;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Eta;

/**
 * Last known arrivals per pin, written after every successful refresh. This is what makes the app
 * show real numbers on the very first frame after a cold start, before any network call finishes.
 */
public final class EtaCache {

    private static final String FILE = "eta-cache.json";
    private static final int MAX_PINS = 48;

    private EtaCache() {
    }

    public static Map<String, Arrivals> load(Context c) {
        Map<String, Arrivals> out = new HashMap<String, Arrivals>();
        File f = new File(c.getFilesDir(), FILE);
        if (!f.exists()) {
            return out;
        }
        try {
            String raw = read(f);
            JSONObject root = new JSONObject(raw);
            JSONArray items = root.optJSONArray("items");
            if (items == null) {
                return out;
            }
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.getJSONObject(i);
                String key = o.optString("k");
                long fetchedAt = o.optLong("f");
                long dataTs = o.optLong("d");
                JSONArray a = o.optJSONArray("a");
                Eta[] list = new Eta[a == null ? 0 : a.length()];
                for (int j = 0; j < list.length; j++) {
                    JSONArray e = a.getJSONArray(j);
                    list[j] = new Eta(e.optLong(0), e.optInt(1), e.optBoolean(2),
                            e.optString(3), e.optString(4), e.optString(5), e.optString(6));
                }
                out.put(key, new Arrivals(list, fetchedAt, dataTs, null));
            }
        } catch (JSONException e) {
            out.clear();
        } catch (IOException e) {
            out.clear();
        }
        return out;
    }

    public static void save(Context c, Map<String, Arrivals> map) {
        JSONArray items = new JSONArray();
        int n = 0;
        for (Map.Entry<String, Arrivals> en : map.entrySet()) {
            if (n++ >= MAX_PINS) {
                break;
            }
            Arrivals a = en.getValue();
            if (a == null || !a.ok()) {
                continue;
            }
            JSONObject o = new JSONObject();
            try {
                o.put("k", en.getKey());
                o.put("f", a.fetchedAt);
                o.put("d", a.dataTs);
                JSONArray list = new JSONArray();
                for (Eta e : a.list) {
                    JSONArray row = new JSONArray();
                    row.put(e.etaMs);
                    row.put(e.seq);
                    row.put(e.scheduled);
                    row.put(e.remark);
                    row.put(e.destTc);
                    row.put(e.destSc);
                    row.put(e.destEn);
                    list.put(row);
                }
                o.put("a", list);
                items.put(o);
            } catch (JSONException ignored) {
                // primitives only
            }
        }
        JSONObject root = new JSONObject();
        try {
            root.put("v", 1);
            root.put("items", items);
        } catch (JSONException ignored) {
            return;
        }
        File tmp = new File(c.getFilesDir(), FILE + ".tmp");
        try {
            FileOutputStream fos = new FileOutputStream(tmp);
            fos.write(root.toString().getBytes("UTF-8"));
            fos.close();
            File dst = new File(c.getFilesDir(), FILE);
            if (!tmp.renameTo(dst)) {
                dst.delete();
                tmp.renameTo(dst);
            }
        } catch (IOException ignored) {
            tmp.delete();
        }
    }

    private static String read(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream(4096);
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            return new String(bos.toByteArray(), "UTF-8");
        } finally {
            in.close();
        }
    }
}
