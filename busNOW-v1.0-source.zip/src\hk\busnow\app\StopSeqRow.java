package hk.busnow.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.ui.Ui;

/** Stop sequence of one route/direction. */
final class StopSeqRow extends BaseAdapter {

    private final Context c;
    private final SeedFormat seed;
    private final int routeIdx;
    private final int lang;
    private final int ink3;

    StopSeqRow(Context c, SeedFormat seed, int routeIdx, int lang) {
        this.c = c;
        this.seed = seed;
        this.routeIdx = routeIdx;
        this.lang = lang;
        this.ink3 = c.getResources().getColor(R.color.ink3);
    }

    int stopAt(int position) {
        return seed.refs[seed.routeRefStart[routeIdx] + position];
    }

    @Override
    public int getCount() {
        return seed.routeRefCount[routeIdx];
    }

    @Override
    public Object getItem(int position) {
        return Integer.valueOf(stopAt(position));
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(c).inflate(R.layout.item_seq, parent, false);
            Holder h = new Holder();
            h.seq = (TextView) v.findViewById(R.id.seq);
            h.name = (TextView) v.findViewById(R.id.name);
            h.chevron = (ImageView) v.findViewById(R.id.chevron);
            h.chevron.setColorFilter(ink3);
            v.setTag(h);
        }
        Holder h = (Holder) v.getTag();
        int si = stopAt(position);
        h.seq.setText(String.valueOf(position + 1));
        h.name.setText(seed.stopName(si, lang));
        return v;
    }

    private static final class Holder {
        TextView seq;
        TextView name;
        ImageView chevron;
    }
}
