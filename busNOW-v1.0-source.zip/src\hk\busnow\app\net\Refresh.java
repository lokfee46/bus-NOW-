package hk.busnow.app.net;

import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Eta;
import hk.busnow.app.model.Pin;

/**
 * Refreshes pinned arrivals and stop boards off the main thread.
 *
 * Requests are grouped by stop so a stop with several pins costs one call, Citybus stops always
 * cost exactly one call, and every screen gets a generation number: results from a cancelled
 * generation are dropped instead of racing the UI.
 */
public final class Refresh {

    public interface Listener {
        void onArrivals(String pinKey, Arrivals arrivals);

        void onDone();
    }

    public interface StopListener {
        void onRouteArrivals(int routeIdx, Arrivals arrivals);

        void onDone();
    }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(4, new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "eta-net");
            t.setDaemon(true);
            return t;
        }
    });

    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicInteger generation = new AtomicInteger();

    public void cancel() {
        generation.incrementAndGet();
    }

    // ------------------------------------------------------------------- pins

    public void pins(final List<Pin> pins, final int lang, final Listener listener) {
        final int gen = generation.incrementAndGet();
        Map<String, List<Pin>> jobs = new LinkedHashMap<String, List<Pin>>();
        for (Pin p : pins) {
            String key = p.op == SeedFormat.OP_CTB
                    ? "C|" + p.stopId
                    : "K|" + p.stopId + "|" + p.route + "|" + p.svc + "|" + p.bound;
            List<Pin> group = jobs.get(key);
            if (group == null) {
                group = new ArrayList<Pin>(1);
                jobs.put(key, group);
            }
            group.add(p);
        }
        if (jobs.isEmpty()) {
            main.post(new Runnable() {
                @Override
                public void run() {
                    listener.onDone();
                }
            });
            return;
        }
        final AtomicInteger remaining = new AtomicInteger(jobs.size());
        for (Map.Entry<String, List<Pin>> en : jobs.entrySet()) {
            final List<Pin> group = en.getValue();
            POOL.execute(new Runnable() {
                @Override
                public void run() {
                    if (generation.get() != gen) {
                        finish(remaining, gen, listener);
                        return;
                    }
                    Pin first = group.get(0);
                    if (first.op == SeedFormat.OP_CTB) {
                        CtbApi.StopEta se = CtbApi.stopEta(first.stopId, lang, 3);
                        for (final Pin p : group) {
                            Arrivals a = se.byRoute.get(CtbApi.key(p.route, p.bound));
                            if (a == null) {
                                a = new Arrivals(new Eta[0], se.fetchedAt, 0, se.error);
                            }
                            post(gen, p.key(), a, listener);
                        }
                    } else {
                        Arrivals a = KmbApi.eta(first.stopId, first.route, first.svc, first.bound, lang, 3);
                        post(gen, first.key(), a, listener);
                    }
                    finish(remaining, gen, listener);
                }
            });
        }
    }

    private void post(final int gen, final String key, final Arrivals a, final Listener l) {
        if (generation.get() != gen) {
            return;
        }
        main.post(new Runnable() {
            @Override
            public void run() {
                if (generation.get() == gen) {
                    l.onArrivals(key, a);
                }
            }
        });
    }

    private void finish(AtomicInteger remaining, final int gen, final Listener l) {
        if (remaining.decrementAndGet() == 0) {
            main.post(new Runnable() {
                @Override
                public void run() {
                    if (generation.get() == gen) {
                        l.onDone();
                    }
                }
            });
        }
    }

    // ------------------------------------------------------------- stop board

    /** All routes at one stop, with duplicate service types collapsed. */
    public static int[] boardRoutes(SeedFormat seed, int stopIdx) {
        int[] all = seed.routesAtStop(stopIdx);
        LinkedHashMap<String, Integer> keep = new LinkedHashMap<String, Integer>();
        for (int r : all) {
            String key = seed.routeName(r) + "|" + seed.routeBound[r];
            Integer prev = keep.get(key);
            if (prev == null) {
                keep.put(key, r);
            } else if (seed.routeSvc[prev] != 1 && seed.routeSvc[r] == 1) {
                keep.put(key, r);
            }
        }
        int[] out = new int[keep.size()];
        int i = 0;
        for (Integer v : keep.values()) {
            out[i++] = v;
        }
        return out;
    }

    public void stopBoard(final SeedFormat seed, final int stopIdx, final int lang, final StopListener l) {
        final int gen = generation.incrementAndGet();
        final int[] routes = boardRoutes(seed, stopIdx);
        final AtomicInteger remaining = new AtomicInteger(routes.length);
        if (routes.length == 0) {
            main.post(new Runnable() {
                @Override
                public void run() {
                    l.onDone();
                }
            });
            return;
        }
        boolean ctbScheduled = false;
        for (final int r : routes) {
            if (seed.routeOp[r] == SeedFormat.OP_CTB) {
                if (!ctbScheduled) {
                    ctbScheduled = true;
                    POOL.execute(new Runnable() {
                        @Override
                        public void run() {
                            CtbApi.StopEta se = CtbApi.stopEta(seed.stopId(stopIdx), lang, 3);
                            for (int ri : routes) {
                                if (seed.routeOp[ri] != SeedFormat.OP_CTB) {
                                    continue;
                                }
                                Arrivals a = se.byRoute.get(CtbApi.key(seed.routeName(ri), seed.routeBound[ri]));
                                if (a == null) {
                                    a = new Arrivals(new Eta[0], se.fetchedAt, 0, se.error);
                                }
                                deliverStop(gen, ri, a, l);
                                tick(remaining, gen, l);
                            }
                        }
                    });
                }
                continue;
            }
            POOL.execute(new Runnable() {
                @Override
                public void run() {
                    if (generation.get() != gen) {
                        tick(remaining, gen, l);
                        return;
                    }
                    Arrivals a = KmbApi.eta(seed.stopId(stopIdx), seed.routeName(r),
                            seed.routeSvc[r], seed.routeBound[r], lang, 3);
                    deliverStop(gen, r, a, l);
                    tick(remaining, gen, l);
                }
            });
        }
    }

    private void deliverStop(final int gen, final int routeIdx, final Arrivals a, final StopListener l) {
        if (generation.get() != gen) {
            return;
        }
        main.post(new Runnable() {
            @Override
            public void run() {
                if (generation.get() == gen) {
                    l.onRouteArrivals(routeIdx, a);
                }
            }
        });
    }

    private void tick(AtomicInteger remaining, final int gen, final StopListener l) {
        if (remaining.decrementAndGet() == 0) {
            main.post(new Runnable() {
                @Override
                public void run() {
                    if (generation.get() == gen) {
                        l.onDone();
                    }
                }
            });
        }
    }
}
