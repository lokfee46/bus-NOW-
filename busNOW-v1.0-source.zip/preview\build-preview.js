'use strict';
/*
 * Generates preview/preview.html: a 1:1 replica of the real screens using the same dp values,
 * colours and glass recipe as the Java code (translucent gradient + 1px highlight border + soft
 * shadow + sheen; no backdrop blur, because the app does not blur either).
 *
 * Then preview/shot.cmd renders it with headless Chrome at 2x.
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

const C = {
  ink: '#0B1220',
  ink2: '#5A6478',
  ink3: '#8C96AB',
  accent: '#0A66FF',
  kmb: '#E2231A',
  ctb: '#FFD100',
  lwb: '#F7941D',
};

function aurora() {
  return '<div class="aurora"></div>';
}

function badge(route, bg, fg) {
  return `<div class="badge" style="background:${bg};color:${fg}">${route}</div>`;
}

function card(opts) {
  const {
    route, opColor, opText, dest, stop, primary, unit, secondary, age, chip, compact, primarySmall,
  } = opts;
  const sz = compact ? 'compact' : '';
  return `
  <div class="row ${sz}">
    <div class="glass card ${sz}">
      ${badge(route, opColor, opText)}
      <div class="mid">
        <div class="dest">${dest}</div>
        <div class="stop">${stop}</div>
        <div class="meta">
          <span class="age">${age}</span>
          ${chip ? `<span class="chip">${chip}</span>` : ''}
        </div>
      </div>
      <div class="right">
        <div class="eta-line">
          <span class="eta ${primarySmall ? 'small' : ''}">${primary}</span>
          ${unit ? `<span class="unit">${unit}</span>` : ''}
        </div>
        <div class="next">${secondary}</div>
      </div>
    </div>
  </div>`;
}

function dock(selected) {
  const items = [
    ['NOW', 'home'],
    ['搜尋', 'search'],
    ['附近', 'pin'],
    ['設定', 'sliders'],
  ];
  return `<div class="glass dock">
    ${items.map(([label, kind], i) => {
    const on = i === selected;
    return `<div class="dock-item ${on ? 'on' : ''}">
        <div class="ico ${kind} ${on ? 'on' : ''}"></div>
        <div class="dock-label ${on ? 'on' : ''}">${label}</div>
      </div>`;
  }).join('')}
  </div>`;
}

function homeScreen() {
  return `
  <div class="frame">
    <div class="phone">
      ${aurora()}
      <div class="content">
        <div class="topbar">
          <div>
            <div class="brand">bus NOW</div>
            <div class="tagline">香港巴士即時到站</div>
          </div>
          <div class="circle-btn"><div class="ico refresh"></div></div>
        </div>
        <div class="glass search-pill">
          <div class="ico search"></div>
          <span>搜尋路線 / 車站</span>
        </div>
        <div class="section">
          <span>我的路線</span>
          <span class="updated">資料 12 秒前</span>
        </div>
        <div class="list">
          ${card({
    route: '1A', opColor: C.kmb, opText: '#fff',
    dest: '尖沙咀碼頭', stop: '九巴 · 中秀茂坪 (KT975)',
    primary: '3', unit: '分', secondary: '8 · 12',
    age: '08:57 · 12 秒前', chip: '',
  })}
          ${card({
    route: '968', opColor: C.kmb, opText: '#fff',
    dest: '銅鑼灣 (天后)', stop: '九巴 · 元朗 (西) 總站',
    primary: '7', unit: '分', secondary: '15 · 22',
    age: '09:01 · 12 秒前', chip: '班次表',
  })}
          ${card({
    route: 'A31', opColor: C.lwb, opText: '#fff',
    dest: '機場 (地面運輸中心)', stop: '龍運 · 荃灣 (如心廣場)',
    primary: '即將到站', unit: '', secondary: '9 · 18',
    age: '08:54 · 8 秒前', chip: '', primarySmall: true,
  })}
          ${card({
    route: '1', opColor: C.ctb, opText: '#201800',
    dest: '跑馬地 (上)', stop: '城巴 · 中環 (港澳碼頭)',
    primary: '2', unit: '分', secondary: '6 · 11',
    age: '08:56 · 12 秒前', chip: '',
  })}
          ${card({
    route: 'E33', opColor: C.lwb, opText: '#fff',
    dest: '機場 (地面運輸中心)', stop: '龍運 · 屯門市中心',
    primary: '12', unit: '分', secondary: '26 · 40',
    age: '09:06 · 12 秒前', chip: '',
  })}
        </div>
        ${dock(0)}
      </div>
    </div>
    <div class="caption">主界面 · 釘選的路線</div>
  </div>`;
}

function boardScreen() {
  const rows = [
    ['1', C.ctb, '#201800', '往 跑馬地 (上)', '2 分 · 6 分 · 11 分'],
    ['5B', C.ctb, '#201800', '往 堅尼地城', '4 分 · 12 分 · 19 分'],
    ['10', C.ctb, '#201800', '往 北角碼頭', '7 分 · 16 分'],
    ['101', C.kmb, '#fff', '往 觀塘 (裕民坊)', '8 分 · 14 分 · 21 分'],
    ['111', C.kmb, '#fff', '往 坪石', '11 分 · 18 分'],
    ['115', C.kmb, '#fff', '往 九龍城碼頭', '15 分 · 27 分'],
    ['641', C.kmb, '#fff', '往 啟德 (沐虹街)', '22 分'],
  ];
  return `
  <div class="frame">
    <div class="phone">
      ${aurora()}
      <div class="content">
        <div class="topbar">
          <div class="circle-btn small"><div class="ico back"></div></div>
          <div class="grow">
            <div class="title">中環 (港澳碼頭)</div>
            <div class="subtitle">城巴 · 7 條路線</div>
          </div>
          <div class="circle-btn"><div class="ico refresh"></div></div>
        </div>
        <div class="section"><span>本站路線</span><span></span></div>
        <div class="list">
          ${rows.map(([route, bg, fg, dest, eta]) => `
            <div class="row">
              <div class="glass card board">
                ${badge(route, bg, fg)}
                <div class="mid">
                  <div class="dest">${dest}</div>
                  <div class="stop">${eta}</div>
                </div>
                <div class="plus"><div class="ico plus"></div></div>
              </div>
            </div>`).join('')}
        </div>
      </div>
    </div>
    <div class="caption">車站 · 全部路線即時到站</div>
  </div>`;
}

function searchScreen() {
  const results = [
    ['1A', C.kmb, '#fff', '往 尖沙咀碼頭', '九巴'],
    ['1A', C.kmb, '#fff', '往 中秀茂坪', '九巴'],
    ['A11', C.ctb, '#201800', '往 北角碼頭', '城巴'],
    ['11', C.kmb, '#fff', '往 鑽石山站', '九巴 · 服務類型 2'],
    ['11K', C.kmb, '#fff', '往 竹園邨', '九巴'],
    ['11X', C.kmb, '#fff', '往 上水', '九巴'],
  ];
  return `
  <div class="frame">
    <div class="phone">
      ${aurora()}
      <div class="content">
        <div class="topbar">
          <div class="circle-btn small"><div class="ico back"></div></div>
          <div class="glass input">1A</div>
        </div>
        <div class="glass segmented">
          <div class="seg on">路線</div>
          <div class="seg">車站</div>
        </div>
        <div class="list search-list">
          ${results.map(([route, bg, fg, dest, sub]) => `
            <div class="row">
              <div class="glass card route-row">
                ${badge(route, bg, fg)}
                <div class="mid">
                  <div class="dest">${dest}</div>
                  <div class="stop">${sub}</div>
                </div>
                <div class="ico chevron"></div>
              </div>
            </div>`).join('')}
        </div>
      </div>
    </div>
    <div class="caption">搜尋 · 路線與車站都離線可搜</div>
  </div>`;
}

function watchScreen() {
  return `
  <div class="frame watch-frame">
    <div class="watch">
      ${aurora()}
      <div class="content watch-content">
        <div class="watch-top">
          <div class="brand tiny">bus NOW</div>
          <div class="ico refresh tiny-ico"></div>
        </div>
        <div class="glass watch-search">
          <div class="ico search tiny-ico"></div>
          <span>搜尋</span>
        </div>
        ${card({
    route: '1A', opColor: C.kmb, opText: '#fff',
    dest: '尖沙咀碼頭', stop: '中秀茂坪',
    primary: '3', unit: '分', secondary: '8 · 12',
    age: '08:57', chip: '', compact: true,
  })}
        <div class="glass dock watch-dock">
          <div class="ico home on"></div>
          <div class="ico search"></div>
          <div class="ico pin"></div>
          <div class="ico sliders"></div>
        </div>
      </div>
    </div>
    <div class="caption">240 × 240 手錶（精簡模式）</div>
  </div>`;
}

const html = `<!doctype html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<title>bus NOW UI preview</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#E9EDF6;font-family:"Microsoft YaHei","PingFang HK","Noto Sans CJK TC",system-ui,sans-serif;
       padding:24px;display:flex;flex-wrap:wrap;gap:24px;align-items:flex-start;width:1176px}
  .frame{display:flex;flex-direction:column;gap:8px}
  .phone{position:relative;width:360px;height:780px;border-radius:34px;overflow:hidden;
         box-shadow:0 24px 60px rgba(20,34,74,.18);flex:0 0 auto}
  .watch{position:relative;width:240px;height:240px;border-radius:44px;overflow:hidden;
         box-shadow:0 18px 40px rgba(20,34,74,.22);flex:0 0 auto}
  .aurora{position:absolute;inset:0;background:
    radial-gradient(120% 90% at 10% 0%, rgba(120,160,255,.62), rgba(120,160,255,0) 62%),
    radial-gradient(90% 70% at 95% 14%, rgba(186,160,255,.55), rgba(186,160,255,0) 64%),
    radial-gradient(100% 80% at 70% 98%, rgba(140,240,225,.42), rgba(140,240,225,0) 66%),
    radial-gradient(80% 70% at 25% 62%, rgba(110,150,255,.34), rgba(110,150,255,0) 70%),
    linear-gradient(180deg,#F3F7FF 0%,#E9F0FD 46%,#F5F8FE 100%)}
  .aurora:after{content:"";position:absolute;inset:0;background:linear-gradient(160deg,rgba(255,255,255,.16),rgba(255,255,255,0) 44%)}
  .content{position:relative;display:flex;flex-direction:column;height:100%;padding:16px 0 10px}
  .topbar{display:flex;align-items:center;gap:10px;padding:0 18px 12px}
  .grow{flex:1}
  .brand{font-size:22px;font-weight:300;color:${C.ink};letter-spacing:.2px}
  .brand.tiny{font-size:12px}
  .tagline{font-size:11px;color:${C.ink2};margin-top:1px}
  .title{font-size:16px;font-weight:600;color:${C.ink}}
  .subtitle{font-size:11px;color:${C.ink2};margin-top:2px}
  .circle-btn{width:42px;height:42px;border-radius:21px;display:flex;align-items:center;justify-content:center;
    background:rgba(255,255,255,.62);border:1px solid rgba(255,255,255,.92);margin-left:auto}
  .circle-btn.small{width:40px;height:40px;margin-left:0;flex:0 0 auto}
  .glass{background:linear-gradient(180deg,rgba(255,255,255,.80),rgba(255,255,255,.56));
    border:1px solid rgba(255,255,255,.95);
    box-shadow:0 7px 18px rgba(21,38,74,.10), inset 0 1px 0 rgba(255,255,255,.92);
    position:relative;overflow:hidden}
  .glass:before{content:"";position:absolute;inset:0;pointer-events:none;
    background:linear-gradient(124deg,rgba(255,255,255,.18),rgba(255,255,255,0) 56%)}
  .search-pill{height:52px;border-radius:18px;margin:0 18px;display:flex;align-items:center;gap:10px;padding:0 14px;
    color:${C.ink2};font-size:14px}
  .section{display:flex;justify-content:space-between;align-items:center;padding:16px 18px 4px;
    font-size:12.5px;font-weight:600;color:${C.ink2}}
  .updated{font-size:11px;font-weight:400;color:${C.ink3}}
  .list{flex:1;overflow:hidden;padding-top:2px}
  .row{padding:5px 14px}
  .card{border-radius:22px;display:flex;align-items:center;padding:12px 14px;gap:12px}
  .card.compact{border-radius:18px;padding:8px 9px;gap:7px}
  .badge{min-width:42px;height:26px;border-radius:11px;display:flex;align-items:center;justify-content:center;
    font-size:14px;font-weight:600;padding:0 9px;flex:0 0 auto}
  .compact .badge{min-width:30px;height:20px;font-size:11px;border-radius:8px;padding:0 6px}
  .mid{flex:1;min-width:0}
  .dest{font-size:15px;font-weight:600;color:${C.ink};white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .stop{font-size:11.5px;color:${C.ink2};margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .compact .dest{font-size:12px}
  .compact .stop{font-size:9px}
  .meta{display:flex;align-items:center;gap:6px;margin-top:4px}
  .age{font-size:10.5px;color:${C.ink3};white-space:nowrap}
  .compact .meta{display:none}
  .chip{font-size:10px;padding:2px 6px;border-radius:8px;color:${C.accent};background:rgba(10,102,255,.12)}
  .right{text-align:right;flex:0 0 auto}
  .eta-line{display:flex;align-items:flex-end;justify-content:flex-end;gap:2px}
  .eta{font-size:30px;font-weight:600;color:${C.ink};line-height:1.05;font-variant-numeric:tabular-nums}
  .eta.small{font-size:16px;letter-spacing:.5px}
  .compact .eta{font-size:20px}
  .compact .eta.small{font-size:11px}
  .unit{font-size:12px;color:${C.ink2};margin-bottom:4px}
  .next{font-size:12px;color:${C.ink2};margin-top:1px;font-variant-numeric:tabular-nums}
  .compact .next{font-size:9px}
  .board{padding:11px 6px 11px 12px}
  .plus{width:38px;height:38px;border-radius:19px;background:rgba(10,102,255,.10);
    display:flex;align-items:center;justify-content:center}
  .dock{height:58px;border-radius:26px;margin:6px 16px 0;display:flex;align-items:center;flex:0 0 auto}
  .dock-item{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;height:100%}
  .dock-item.on{background:rgba(10,102,255,.14);border-radius:15px;margin:0 2px}
  .dock-label{font-size:9.5px;font-weight:600;color:${C.ink3}}
  .dock-label.on{color:${C.accent}}
  .input{height:46px;border-radius:23px;flex:1;display:flex;align-items:center;padding:0 16px;
    font-size:14px;color:${C.ink}}
  .segmented{height:40px;border-radius:20px;margin:12px 16px 0;display:flex;padding:4px}
  .seg{flex:1;display:flex;align-items:center;justify-content:center;font-size:12.5px;font-weight:600;color:${C.ink2};border-radius:16px}
  .seg.on{color:${C.accent};background:rgba(10,102,255,.14)}
  .search-list{padding-top:8px}
  .route-row{padding:10px 12px}
  .watch-content{padding:8px 8px 6px;gap:5px}
  .watch-top{display:flex;align-items:center;justify-content:space-between;padding:0 2px}
  .watch-search{height:32px;border-radius:16px;display:flex;align-items:center;gap:6px;padding:0 10px;
    font-size:11px;color:${C.ink2}}
  .tiny-ico{width:12px;height:12px}
  .watch .row{padding:0}
  .watch-dock{height:40px;border-radius:18px;margin-top:auto;display:flex;align-items:center;justify-content:space-around;padding:0 6px}
  .watch-dock .ico{width:15px;height:15px}
  .dot{width:7px;height:7px;border-radius:4px;background:${C.ink3};opacity:.5}
  .dot.on{background:${C.accent};opacity:1;width:18px;border-radius:4px}
  .caption{text-align:center;font-size:12px;color:#6C7791}
  .ico{width:18px;height:18px;position:relative;flex:0 0 auto}
  .ico.search:before{content:"";position:absolute;left:1px;top:1px;width:10px;height:10px;border:2px solid ${C.ink2};border-radius:50%}
  .ico.search:after{content:"";position:absolute;left:11px;top:11px;width:6px;height:2px;background:${C.ink2};transform:rotate(45deg);border-radius:1px}
  .ico.refresh:before{content:"";position:absolute;inset:2px;border:2px solid ${C.ink2};border-radius:50%;border-top-color:transparent;transform:rotate(-35deg)}
  .ico.back:before{content:"";position:absolute;left:4px;top:3px;width:8px;height:8px;border-left:2px solid ${C.ink2};border-bottom:2px solid ${C.ink2};transform:rotate(45deg)}
  .ico.chevron:before{content:"";position:absolute;left:3px;top:4px;width:7px;height:7px;border-right:2px solid ${C.ink3};border-top:2px solid ${C.ink3};transform:rotate(45deg)}
  .ico.plus:before,.ico.plus:after{content:"";position:absolute;background:${C.accent};border-radius:1px}
  .ico.plus:before{left:8px;top:3px;width:2px;height:12px}
  .ico.plus:after{left:3px;top:8px;width:12px;height:2px}
  .ico.home:before{content:"";position:absolute;left:3px;top:7px;width:12px;height:9px;border:2px solid ${C.ink3};border-top:none;border-radius:2px}
  .ico.home:after{content:"";position:absolute;left:3px;top:3px;width:9px;height:9px;border-left:2px solid ${C.ink3};border-top:2px solid ${C.ink3};transform:rotate(45deg)}
  .ico.pin:before{content:"";position:absolute;left:4px;top:2px;width:10px;height:10px;border:2px solid ${C.ink3};border-radius:50% 50% 50% 0;transform:rotate(-45deg)}
  .ico.sliders:before{content:"";position:absolute;left:2px;top:5px;width:14px;height:2px;background:${C.ink3};
    box-shadow:0 5px 0 ${C.ink3},0 10px 0 ${C.ink3}}
  .ico.on.home:before{border-color:${C.accent}}
  .ico.on.home:after{border-color:${C.accent}}
  .ico.on.pin:before{border-color:${C.accent}}
  .ico.on.search:before{border-color:${C.accent}}
  .ico.on.search:after{background:${C.accent}}
  .ico.on.sliders:before{background:${C.accent};box-shadow:0 5px 0 ${C.accent},0 10px 0 ${C.accent}}
</style>
</head>
<body>
  ${homeScreen()}
  ${boardScreen()}
  ${searchScreen()}
  ${watchScreen()}
</body>
</html>`;

fs.writeFileSync(path.join(ROOT, 'preview', 'preview.html'), html, 'utf8');
console.log('preview.html written (' + (html.length / 1024).toFixed(1) + ' KB)');
