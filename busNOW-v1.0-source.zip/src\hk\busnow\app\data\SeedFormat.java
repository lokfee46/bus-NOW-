package hk.busnow.app.data;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.CRC32;

/**
 * The offline route/stop index, parsed from the bundled seed.bin.gz.
 *
 * <p>Everything is stored in primitive arrays: no per-row objects, no SQLite, no JSON. The binary
 * layout is documented in docs/05 and produced by tools/build-seed.js. This class has no Android
 * imports on purpose, so the same code can be exercised by the desktop self-test.
 */
public final class SeedFormat {

    public static final int OP_KMB = 0;
    public static final int OP_CTB = 1;

    public static final int TC = 0;
    public static final int SC = 1;
    public static final int EN = 2;

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final byte[] ZERO4 = new byte[4];

    private static final int STOP_RECORD = 32;
    private static final int ROUTE_RECORD = 40;
    private static final int HEADER = 64;

    public long generatedAt;
    public int stopCount;
    public int routeCount;
    public int refCount;

    public long[] stopKey;
    public byte[] stopOp;
    public int[] stopLat;
    public int[] stopLon;
    public int[] stopTcOff;
    public int[] stopScOff;
    public int[] stopEnOff;

    public byte[] routeOp;
    public byte[] routeBound;
    public byte[] routeSvc;
    public int[] routeNameOff;
    public int[] routeOrigTc;
    public int[] routeOrigSc;
    public int[] routeOrigEn;
    public int[] routeDestTc;
    public int[] routeDestSc;
    public int[] routeDestEn;
    public int[] routeRefStart;
    public char[] routeRefCount;
    public char[] refs;

    public int[] stopIndex;
    public int[] routeIndex;
    public byte[] pool;

    private final Map<Integer, int[]> routesAtStopCache = new HashMap<Integer, int[]>();

    private SeedFormat() {
    }

    public static SeedFormat parse(byte[] data) throws IOException {
        if (data == null || data.length < HEADER) {
            throw new IOException("seed too short");
        }
        if (data[0] != 'B' || data[1] != 'N' || data[2] != 'O' || data[3] != 'W') {
            throw new IOException("bad seed magic");
        }
        ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        int version = b.getShort(4) & 0xFFFF;
        if (version != 1) {
            throw new IOException("unsupported seed version " + version);
        }
        SeedFormat s = new SeedFormat();
        s.generatedAt = b.getInt(8) & 0xFFFFFFFFL;
        s.stopCount = b.getInt(12);
        s.routeCount = b.getInt(16);
        s.refCount = b.getInt(20);
        int poolBytes = b.getInt(24);
        int poolOff = b.getInt(28);
        int stopsOff = b.getInt(32);
        int routesOff = b.getInt(36);
        int refsOff = b.getInt(40);
        int stopIndexOff = b.getInt(44);
        int routeIndexOff = b.getInt(48);
        long crcStored = b.getInt(52) & 0xFFFFFFFFL;

        if (s.stopCount <= 0 || s.routeCount <= 0 || s.refCount <= 0 || poolBytes <= 0) {
            throw new IOException("empty seed");
        }
        if (s.stopCount > 100000 || s.routeCount > 100000 || s.refCount > 2000000
                || poolBytes > (1 << 23)) {
            throw new IOException("implausible seed counts");
        }
        checkRange(stopsOff, s.stopCount * STOP_RECORD, data.length);
        checkRange(routesOff, s.routeCount * ROUTE_RECORD, data.length);
        checkRange(refsOff, s.refCount * 2, data.length);
        checkRange(stopIndexOff, s.stopCount * 4, data.length);
        checkRange(routeIndexOff, s.routeCount * 4, data.length);
        checkRange(poolOff, poolBytes, data.length);

        CRC32 crc = new CRC32();
        crc.update(data, 0, 52);
        crc.update(ZERO4, 0, 4);
        crc.update(data, 56, data.length - 56);
        if (crc.getValue() != crcStored) {
            throw new IOException("seed checksum mismatch");
        }

        // Strings: copy just the pool so the (larger) whole file can be collected.
        s.pool = Arrays.copyOfRange(data, poolOff, poolOff + poolBytes);

        s.stopKey = new long[s.stopCount];
        s.stopOp = new byte[s.stopCount];
        s.stopLat = new int[s.stopCount];
        s.stopLon = new int[s.stopCount];
        s.stopTcOff = new int[s.stopCount];
        s.stopScOff = new int[s.stopCount];
        s.stopEnOff = new int[s.stopCount];
        for (int i = 0; i < s.stopCount; i++) {
            int o = stopsOff + i * STOP_RECORD;
            s.stopKey[i] = b.getLong(o);
            s.stopOp[i] = b.get(o + 8);
            s.stopLat[i] = b.getInt(o + 12);
            s.stopLon[i] = b.getInt(o + 16);
            s.stopTcOff[i] = b.getInt(o + 20);
            s.stopScOff[i] = b.getInt(o + 24);
            s.stopEnOff[i] = b.getInt(o + 28);
        }

        s.routeOp = new byte[s.routeCount];
        s.routeBound = new byte[s.routeCount];
        s.routeSvc = new byte[s.routeCount];
        s.routeNameOff = new int[s.routeCount];
        s.routeOrigTc = new int[s.routeCount];
        s.routeOrigSc = new int[s.routeCount];
        s.routeOrigEn = new int[s.routeCount];
        s.routeDestTc = new int[s.routeCount];
        s.routeDestSc = new int[s.routeCount];
        s.routeDestEn = new int[s.routeCount];
        s.routeRefStart = new int[s.routeCount];
        s.routeRefCount = new char[s.routeCount];
        for (int i = 0; i < s.routeCount; i++) {
            int o = routesOff + i * ROUTE_RECORD;
            s.routeOp[i] = b.get(o);
            s.routeBound[i] = b.get(o + 1);
            s.routeSvc[i] = b.get(o + 2);
            s.routeNameOff[i] = b.getInt(o + 4);
            s.routeOrigTc[i] = b.getInt(o + 8);
            s.routeOrigSc[i] = b.getInt(o + 12);
            s.routeOrigEn[i] = b.getInt(o + 16);
            s.routeDestTc[i] = b.getInt(o + 20);
            s.routeDestSc[i] = b.getInt(o + 24);
            s.routeDestEn[i] = b.getInt(o + 28);
            s.routeRefStart[i] = b.getInt(o + 32);
            s.routeRefCount[i] = (char) (b.getShort(o + 36) & 0xFFFF);
        }

        s.refs = new char[s.refCount];
        for (int i = 0; i < s.refCount; i++) {
            s.refs[i] = (char) (b.getShort(refsOff + i * 2) & 0xFFFF);
        }

        s.stopIndex = new int[s.stopCount];
        for (int i = 0; i < s.stopCount; i++) {
            s.stopIndex[i] = b.getInt(stopIndexOff + i * 4);
        }
        s.routeIndex = new int[s.routeCount];
        for (int i = 0; i < s.routeCount; i++) {
            s.routeIndex[i] = b.getInt(routeIndexOff + i * 4);
        }
        return s;
    }

    private static void checkRange(int off, int len, int total) throws IOException {
        if (off < HEADER || len < 0 || off > total || len > total - off) {
            throw new IOException("seed section out of range");
        }
    }

    // ------------------------------------------------------------------ strings

    public String str(int off) {
        if (off < 0 || off >= pool.length) {
            return "";
        }
        int end = off;
        while (end < pool.length && pool[end] != 0) {
            end++;
        }
        return new String(pool, off, end - off, UTF8);
    }

    public String stopName(int idx, int lang) {
        int off = lang == SC ? stopScOff[idx] : lang == EN ? stopEnOff[idx] : stopTcOff[idx];
        return str(off);
    }

    public String routeName(int idx) {
        return str(routeNameOff[idx]);
    }

    public String routeOrig(int idx, int lang) {
        return str(lang == SC ? routeOrigSc[idx] : lang == EN ? routeOrigEn[idx] : routeOrigTc[idx]);
    }

    public String routeDest(int idx, int lang) {
        return str(lang == SC ? routeDestSc[idx] : lang == EN ? routeDestEn[idx] : routeDestTc[idx]);
    }

    /** Rebuild the operator's own stop id (KMB: 16 hex chars, Citybus: 6 digits). */
    public String stopId(int idx) {
        long key = stopKey[idx];
        if (stopOp[idx] == OP_CTB) {
            String d = Long.toString(key);
            StringBuilder sb = new StringBuilder(6);
            for (int i = d.length(); i < 6; i++) {
                sb.append('0');
            }
            return sb.append(d).toString();
        }
        String hex = Long.toHexString(key).toUpperCase();
        StringBuilder sb = new StringBuilder(16);
        for (int i = hex.length(); i < 16; i++) {
            sb.append('0');
        }
        return sb.append(hex).toString();
    }

    // ------------------------------------------------------------------ lookups

    public int findStop(int op, long key) {
        int lo = 0;
        int hi = stopIndex.length - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            int si = stopIndex[mid];
            int c;
            if (stopOp[si] != (byte) op) {
                c = (stopOp[si] & 0xFF) < op ? -1 : 1;
            } else {
                c = Long.compareUnsigned(stopKey[si], key);
            }
            if (c < 0) {
                lo = mid + 1;
            } else if (c > 0) {
                hi = mid - 1;
            } else {
                return si;
            }
        }
        return -1;
    }

    /** Route indices whose number starts with [q] (case-insensitive), capped at [limit]. */
    public int[] searchRoutes(String q, int limit) {
        q = q == null ? "" : q.trim();
        int n = q.length();
        if (n == 0) {
            return new int[0];
        }
        int lo = 0;
        int hi = routeIndex.length;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (compareName(routeName(routeIndex[mid]), q) < 0) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        int[] out = new int[Math.min(limit, routeIndex.length - lo)];
        int count = 0;
        for (int i = lo; i < routeIndex.length && count < out.length; i++) {
            int ri = routeIndex[i];
            String name = routeName(ri);
            if (name.length() < n || !name.regionMatches(true, 0, q, 0, n)) {
                break;
            }
            out[count++] = ri;
        }
        return count == out.length ? out : Arrays.copyOf(out, count);
    }

    /** Stop indices whose name contains [q] in any language; prefix hits are listed first. */
    public int[] searchStops(String q, int limit) {
        q = q == null ? "" : q.trim();
        if (q.length() == 0) {
            return new int[0];
        }
        int[] out = new int[Math.min(limit, stopCount)];
        int count = 0;
        for (int pass = 0; pass < 2 && count < out.length; pass++) {
            for (int i = 0; i < stopCount && count < out.length; i++) {
                String tc = stopName(i, TC);
                String sc = stopName(i, SC);
                String en = stopName(i, EN);
                boolean prefix = startsWithIgnoreCase(tc, q) || startsWithIgnoreCase(en, q)
                        || startsWithIgnoreCase(sc, q);
                if ((pass == 0) != prefix) {
                    continue;
                }
                if (containsIgnoreCase(tc, q) || containsIgnoreCase(sc, q) || containsIgnoreCase(en, q)) {
                    out[count++] = i;
                }
            }
        }
        return count == out.length ? out : Arrays.copyOf(out, count);
    }

    private static boolean startsWithIgnoreCase(String hay, String needle) {
        return hay.length() >= needle.length() && hay.regionMatches(true, 0, needle, 0, needle.length());
    }

    /** All route indices that call at [stopIdx], ordered by route number. */
    public int[] routesAtStop(int stopIdx) {
        Integer key = Integer.valueOf(stopIdx);
        int[] hit = routesAtStopCache.get(key);
        if (hit != null) {
            return hit;
        }
        int[] tmp = new int[24];
        int n = 0;
        for (int r = 0; r < routeCount; r++) {
            int start = routeRefStart[r];
            int cnt = routeRefCount[r];
            for (int k = 0; k < cnt; k++) {
                if (refs[start + k] == stopIdx) {
                    if (n == tmp.length) {
                        tmp = Arrays.copyOf(tmp, n * 2);
                    }
                    tmp[n++] = r;
                    break;
                }
            }
        }
        final SeedFormat self = this;
        Integer[] boxed = new Integer[n];
        for (int i = 0; i < n; i++) {
            boxed[i] = tmp[i];
        }
        Arrays.sort(boxed, new java.util.Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                int c = compareName(self.routeName(a), self.routeName(b));
                if (c != 0) {
                    return c;
                }
                return self.routeBound[a] - self.routeBound[b];
            }
        });
        int[] res = new int[n];
        for (int i = 0; i < n; i++) {
            res[i] = boxed[i];
        }
        if (routesAtStopCache.size() > 48) {
            routesAtStopCache.clear();
        }
        routesAtStopCache.put(key, res);
        return res;
    }

    /**
     * Nearest stops to a coordinate, by squared metric distance. [limit] is small (<= 24), so a
     * repeated minimum scan beats sorting and allocates nothing.
     */
    public int[] nearby(double lat, double lon, int limit) {
        double cos = Math.cos(Math.toRadians(lat));
        float[] d = new float[stopCount];
        for (int i = 0; i < stopCount; i++) {
            double dy = (stopLat[i] / 1e6 - lat);
            double dx = (stopLon[i] / 1e6 - lon) * cos;
            d[i] = (float) (dx * dx + dy * dy);
        }
        int[] out = new int[Math.min(limit, stopCount)];
        for (int k = 0; k < out.length; k++) {
            int best = -1;
            float bd = Float.MAX_VALUE;
            for (int i = 0; i < stopCount; i++) {
                if (d[i] < bd) {
                    bd = d[i];
                    best = i;
                }
            }
            out[k] = best;
            d[best] = Float.MAX_VALUE;
        }
        return out;
    }

    /** Distance in metres between a stop and a coordinate. */
    public int distanceTo(int stopIdx, double lat, double lon) {
        double dy = (stopLat[stopIdx] / 1e6 - lat) * 111320.0;
        double dx = (stopLon[stopIdx] / 1e6 - lon) * 111320.0 * Math.cos(Math.toRadians(lat));
        return (int) Math.round(Math.sqrt(dx * dx + dy * dy));
    }

    // ------------------------------------------------------------------ helpers

    private static int compareName(String a, String b) {
        int n = Math.min(a.length(), b.length());
        for (int i = 0; i < n; i++) {
            char ca = lower(a.charAt(i));
            char cb = lower(b.charAt(i));
            if (ca != cb) {
                return ca - cb;
            }
        }
        return a.length() - b.length();
    }

    private static boolean containsIgnoreCase(String hay, String needle) {
        int hn = hay.length();
        int nn = needle.length();
        if (nn == 0) {
            return true;
        }
        if (nn > hn) {
            return false;
        }
        char l0 = lower(needle.charAt(0));
        outer:
        for (int i = 0; i <= hn - nn; i++) {
            if (lower(hay.charAt(i)) != l0) {
                continue;
            }
            for (int j = 1; j < nn; j++) {
                if (lower(hay.charAt(i + j)) != lower(needle.charAt(j))) {
                    continue outer;
                }
            }
            return true;
        }
        return false;
    }

    private static char lower(char c) {
        return (c >= 'A' && c <= 'Z') ? (char) (c + 32) : c;
    }
}
