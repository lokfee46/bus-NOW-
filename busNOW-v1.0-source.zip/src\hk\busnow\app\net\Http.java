package hk.busnow.app.net;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;

import hk.busnow.app.util.Clock;

/**
 * Minimal HTTP GET on top of the platform stack (no OkHttp, no AndroidX). Sends the headers the
 * open-data gateways expect, disables intermediary caching for real-time calls, and feeds the
 * response Date header into {@link Clock}.
 */
public final class Http {

    private static final String UA = "Mozilla/5.0 (Linux; Android 13) busNOW/1.0";

    private Http() {
    }

    public static final class Result {
        public final int code;
        public final String body;
        public final long dateMs;

        Result(int code, String body, long dateMs) {
            this.code = code;
            this.body = body;
            this.dateMs = dateMs;
        }
    }

    public static Result get(String url) throws IOException {
        long sent = System.currentTimeMillis();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) java.net.URI.create(url).toURL().openConnection();
            c.setConnectTimeout(4500);
            c.setReadTimeout(9000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("Accept-Language", "zh-HK,zh;q=0.9,en;q=0.8");
            c.setRequestProperty("Referer", "https://data.gov.hk/");
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Cache-Control", "no-cache");
            c.setRequestProperty("Pragma", "no-cache");
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = in == null ? "" : read(in);
            long date = c.getHeaderFieldDate("Date", 0L);
            Clock.observe(date, sent, System.currentTimeMillis());
            return new Result(code, body, date);
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
    }

    /** GET with retries on transport errors and on 403/429/5xx (the gateways throttle bursts). */
    public static Result getRetry(String url, int tries) throws IOException {
        IOException last = null;
        int code = 0;
        for (int i = 0; i < tries; i++) {
            try {
                Result r = get(url);
                code = r.code;
                if (r.code == 200) {
                    return r;
                }
                if (r.code != 403 && r.code != 429 && r.code < 500) {
                    throw new IOException("HTTP " + r.code);
                }
            } catch (IOException e) {
                last = e;
            }
            sleep(i == 0 ? 500L : i == 1 ? 1600L : 3500L);
        }
        if (last != null) {
            throw last;
        }
        throw new IOException("HTTP " + code);
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static String read(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream(4096);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            return new String(bos.toByteArray(), "UTF-8");
        } finally {
            try {
                in.close();
            } catch (IOException ignored) {
                // nothing useful to do
            }
        }
    }
}
