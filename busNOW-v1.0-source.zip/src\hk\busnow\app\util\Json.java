package hk.busnow.app.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Tiny JSON reader for the open-data payloads (objects/arrays of strings, numbers, booleans, null).
 * Android ships org.json, but keeping the parser here makes the whole network layer runnable by the
 * desktop self-test, and it avoids reflection/prototype-style overhead on very small payloads.
 */
public final class Json {

    private Json() {
    }

    public static Object parse(String text) {
        Parser p = new Parser(text);
        Object v = p.value();
        p.ws();
        if (p.i != p.s.length()) {
            throw new IllegalArgumentException("trailing data at " + p.i);
        }
        return v;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Object v) {
        return (Map<String, Object>) v;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> arr(Object v) {
        return (List<Object>) v;
    }

    public static String str(Map<String, Object> o, String k) {
        Object v = o == null ? null : o.get(k);
        return v == null ? null : String.valueOf(v);
    }

    public static long lng(Map<String, Object> o, String k, long def) {
        Object v = o == null ? null : o.get(k);
        if (v instanceof Number) {
            return ((Number) v).longValue();
        }
        if (v instanceof String) {
            try {
                return Long.parseLong((String) v);
            } catch (NumberFormatException ignored) {
                return def;
            }
        }
        return def;
    }

    public static int integer(Map<String, Object> o, String k, int def) {
        return (int) lng(o, k, def);
    }

    public static boolean bool(Map<String, Object> o, String k) {
        Object v = o == null ? null : o.get(k);
        return v instanceof Boolean && (Boolean) v;
    }

    private static final class Parser {
        private final String s;
        private int i;

        Parser(String s) {
            this.s = s;
        }

        void ws() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') {
                    i++;
                } else {
                    break;
                }
            }
        }

        Object value() {
            ws();
            if (i >= s.length()) {
                throw new IllegalArgumentException("unexpected end of json");
            }
            char c = s.charAt(i);
            switch (c) {
                case '{':
                    return object();
                case '[':
                    return array();
                case '"':
                    return string();
                case 't':
                    expect("true");
                    return Boolean.TRUE;
                case 'f':
                    expect("false");
                    return Boolean.FALSE;
                case 'n':
                    expect("null");
                    return null;
                default:
                    return number();
            }
        }

        private void expect(String lit) {
            if (!s.startsWith(lit, i)) {
                throw new IllegalArgumentException("expected " + lit + " at " + i);
            }
            i += lit.length();
        }

        private Map<String, Object> object() {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            i++; // {
            ws();
            if (i < s.length() && s.charAt(i) == '}') {
                i++;
                return m;
            }
            for (;;) {
                ws();
                String k = string();
                ws();
                if (i >= s.length() || s.charAt(i) != ':') {
                    throw new IllegalArgumentException("expected : at " + i);
                }
                i++;
                m.put(k, value());
                ws();
                if (i >= s.length()) {
                    throw new IllegalArgumentException("unterminated object");
                }
                char c = s.charAt(i++);
                if (c == '}') {
                    return m;
                }
                if (c != ',') {
                    throw new IllegalArgumentException("expected , or } at " + (i - 1));
                }
            }
        }

        private List<Object> array() {
            List<Object> list = new ArrayList<Object>();
            i++; // [
            ws();
            if (i < s.length() && s.charAt(i) == ']') {
                i++;
                return list;
            }
            for (;;) {
                list.add(value());
                ws();
                if (i >= s.length()) {
                    throw new IllegalArgumentException("unterminated array");
                }
                char c = s.charAt(i++);
                if (c == ']') {
                    return list;
                }
                if (c != ',') {
                    throw new IllegalArgumentException("expected , or ] at " + (i - 1));
                }
            }
        }

        private String string() {
            if (i >= s.length() || s.charAt(i) != '"') {
                throw new IllegalArgumentException("expected string at " + i);
            }
            i++;
            StringBuilder sb = new StringBuilder(24);
            for (;;) {
                if (i >= s.length()) {
                    throw new IllegalArgumentException("unterminated string");
                }
                char c = s.charAt(i++);
                if (c == '"') {
                    return sb.toString();
                }
                if (c != '\\') {
                    sb.append(c);
                    continue;
                }
                if (i >= s.length()) {
                    throw new IllegalArgumentException("bad escape");
                }
                char e = s.charAt(i++);
                switch (e) {
                    case '"':
                        sb.append('"');
                        break;
                    case '\\':
                        sb.append('\\');
                        break;
                    case '/':
                        sb.append('/');
                        break;
                    case 'b':
                        sb.append('\b');
                        break;
                    case 'f':
                        sb.append('\f');
                        break;
                    case 'n':
                        sb.append('\n');
                        break;
                    case 'r':
                        sb.append('\r');
                        break;
                    case 't':
                        sb.append('\t');
                        break;
                    case 'u':
                        if (i + 4 > s.length()) {
                            throw new IllegalArgumentException("bad \\u escape");
                        }
                        sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        i += 4;
                        break;
                    default:
                        sb.append(e);
                }
            }
        }

        private Object number() {
            int start = i;
            boolean fp = false;
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == '-' || c == '+' || (c >= '0' && c <= '9')) {
                    i++;
                } else if (c == '.' || c == 'e' || c == 'E') {
                    fp = true;
                    i++;
                } else {
                    break;
                }
            }
            String num = s.substring(start, i);
            try {
                return fp ? (Object) Double.valueOf(num) : (Object) Long.valueOf(num);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("bad number '" + num + "'");
            }
        }
    }
}
