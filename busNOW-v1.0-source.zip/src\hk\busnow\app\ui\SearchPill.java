package hk.busnow.app.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import hk.busnow.app.R;

/** The "search route / stop" glass capsule on the home screen (a button, not an input). */
public class SearchPill extends GlassCard {

    private final TextView hint;

    public SearchPill(Context c, AttributeSet attrs) {
        super(c, attrs);
        setRadius(18);
        setClickable(true);
        setFocusable(true);
        int pad = Ui.dpi(c, 14);

        ImageView icon = new ImageView(c);
        icon.setImageResource(R.drawable.ic_search);
        icon.setImageTintList(ColorStateList.valueOf(
                c.getResources().getColor(R.color.ink2)));
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(
                Ui.dpi(c, 18), Ui.dpi(c, 18));
        ilp.gravity = Gravity.CENTER_VERTICAL | Gravity.START;
        ilp.leftMargin = pad;
        addView(icon, ilp);

        hint = new TextView(c);
        hint.setText(R.string.search_hint);
        hint.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f);
        hint.setTextColor(c.getResources().getColor(R.color.ink2));
        hint.setTypeface(Ui.regular());
        hint.setIncludeFontPadding(false);
        hint.setSingleLine(true);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.CENTER_VERTICAL;
        tlp.leftMargin = pad + Ui.dpi(c, 28);
        tlp.rightMargin = pad;
        addView(hint, tlp);
    }

    public void setHint(CharSequence text) {
        hint.setText(text);
    }
}
