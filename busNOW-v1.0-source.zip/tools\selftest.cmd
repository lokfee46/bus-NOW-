@echo off
rem Desktop self-test for the pure-Java core (seed format, json, time, arrival parsers).
rem Uses the plain JDK only: no Android, no emulator, no network.
setlocal enabledelayedexpansion
chcp 65001 >nul
set "ROOT=%~dp0.."
pushd "%ROOT%"
set "ROOT=%CD%"
popd

set "JBR=C:\Program Files\Android\Android Studio\jbr"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" set "JBR=%JAVA_HOME%"
if not exist "%JBR%\bin\javac.exe" (
  echo [selftest] JDK not found. Set JAVA_HOME.
  exit /b 1
)

set "SRC=%ROOT%\src\hk\busnow\app"
set "OUT=%ROOT%\build\selftest"
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"

"%JBR%\bin\javac.exe" -encoding UTF-8 -nowarn -d "%OUT%" ^
  "%SRC%\data\SeedFormat.java" ^
  "%SRC%\util\Json.java" ^
  "%SRC%\util\TimeUtil.java" ^
  "%SRC%\util\Clock.java" ^
  "%SRC%\net\Http.java" ^
  "%SRC%\net\KmbApi.java" ^
  "%SRC%\net\CtbApi.java" ^
  "%SRC%\model\Eta.java" ^
  "%SRC%\model\Arrivals.java" ^
  "%ROOT%\tools\selftest\SelfTest.java"
if errorlevel 1 (
  echo [selftest] compile failed
  exit /b 1
)

"%JBR%\bin\java.exe" -cp "%OUT%" SelfTest "%ROOT%"
if errorlevel 1 (
  echo [selftest] FAILED
  exit /b 1
)
echo [selftest] ok
