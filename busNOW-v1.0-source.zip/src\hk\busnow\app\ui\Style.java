package hk.busnow.app.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.TextView;

import hk.busnow.app.R;
import hk.busnow.app.data.SeedFormat;

/** Shared small visual recipes: pills, icon buttons, operator badges. */
public final class Style {

    private Style() {
    }

    public static GradientDrawable rounded(Context c, int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setCornerRadius(Ui.dp(c, radiusDp));
        d.setColor(color);
        return d;
    }

    public static GradientDrawable strokeRounded(Context c, int fill, int stroke, float radiusDp, float widthDp) {
        GradientDrawable d = rounded(c, fill, radiusDp);
        d.setStroke(Math.max(1, Ui.dpi(c, widthDp)), stroke);
        return d;
    }

    public static int operatorColor(Context c, int op) {
        return c.getResources().getColor(op == SeedFormat.OP_CTB ? R.color.ctb : R.color.kmb);
    }

    public static int operatorTextColor(Context c, int op) {
        return op == SeedFormat.OP_CTB ? 0xFF201800 : Color.WHITE;
    }

    public static void routeBadge(TextView t, int op) {
        Context c = t.getContext();
        t.setBackground(rounded(c, operatorColor(c, op), 11));
        t.setTextColor(operatorTextColor(c, op));
        t.setTypeface(Ui.medium());
        t.setGravity(android.view.Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setPadding(Ui.dpi(c, 9), 0, Ui.dpi(c, 9), 0);
    }

    public static void chip(TextView t, int textColor, int bgColor) {
        Context c = t.getContext();
        t.setBackground(rounded(c, bgColor, 8));
        t.setTextColor(textColor);
        t.setIncludeFontPadding(false);
        t.setPadding(Ui.dpi(c, 6), Ui.dpi(c, 2), Ui.dpi(c, 6), Ui.dpi(c, 2));
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10);
    }

    /** Circular translucent button used for back / refresh / close. */
    public static void iconButton(View v, int tint) {
        Context c = v.getContext();
        v.setBackground(strokeRounded(c, c.getResources().getColor(R.color.pill_fill),
                c.getResources().getColor(R.color.pill_stroke), 22, 1));
        if (v instanceof android.widget.ImageView) {
            ((android.widget.ImageView) v).setImageTintList(ColorStateList.valueOf(tint));
        }
    }
}
