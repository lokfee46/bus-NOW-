# bus NOW

香港巴士即時到站 App。**646 KB 安裝包、0 個第三方依賴、離線優先、按秒倒數**，
在九巴／龍運／城巴的官方開放數據上做一件很窄的事：打開就看到下一班車。

> 📄 想要一段現成的專案介紹／商店文案（繁中、简中、English）：
> [docs/07-專案介紹與商店描述.md](docs/07-專案介紹與商店描述.md)

| 指標 | 實測值 |
| --- | --- |
| APK 大小 | **662,083 字節 = 646.6 KB** |
| 其中 dex | 113.2 KB（壓縮後 56.5 KB，36 個文件 / 4,572 行 Java） |
| 其中離線路線索引 | 503.7 KB gzip（9,365 個站、2,298 條路線、53,815 個站序） |
| 其中資源 | resources.arsc 19.8 KB + 圖標 35.6 KB |
| 第三方依賴 | **0**（沒有 AndroidX、沒有 Compose、沒有 OkHttp、沒有 Gradle） |
| 最低系統 | Android 5.0（API 21），含刷機手錶 |
| 目標系統 | Android 16（API 36） |
| 資料來源 | DATA.GOV.HK：九巴／龍運 ETA API、城巴 ETA API + OGCIO 批量站點 API |

![真機截圖：主界面 / 搜尋 / 車站到站板](dist/screens.png)

> 上圖是 **Redmi 2409BRN2CY（Android 16）真機截圖**，繁體中文 + 深色主題。
> `dist/ui-preview.png` 另有一份無頭 Chrome 渲染的設計復刻圖（含 240×240 手錶版），
> 但請以真機截圖為準。

---

## 一、功能

**首頁 · NOW**
- 常搭路線卡片：路線號徽章（九巴紅／龍運橙／城巴黃）、目的地、站名、**大字倒數**、
  之後兩班的剩餘分鐘、預計到站時鐘、資料新鮮度
- 「班次表」標記：九巴標明「原定班次」時，會與 GPS 預測區分開，不假裝是實時
- 每 15 秒自動刷新（可調 10/15/30/60 秒），前台才刷新，退到背景立刻停
- 長按卡片：置頂／移除
- 冷啟動先畫上次的資料，再無聲更新——**第一幀就有數字**

**搜尋**
- 路線號、中文站名（繁／簡）、英文站名都可搜，全部走內建索引，離線可用
- 路線 → 方向 → 站序 → 該站即時到站板

**車站**
- 一次看到該站**所有路線**的下一至三班
- 九巴逐條並發查詢（4 併發，失敗退避），城巴**一次批量請求**拿到全站
- 點「＋」把「路線 × 方向 × 這個站」加進首頁

**附近**
- 定位權限可選；拒絕了就用搜尋，不會卡住
- 用內建座標算距離，不需要任何地圖 SDK

**設定**
- 語言：跟隨系統／繁體／简体／English
- 主題：跟隨系統／淺色／深色（深色有真正的深色玻璃，不是把白卡調暗）
- 背景動效：自動（低內存機自動關閉）／開／關
- 自動刷新間隔
- 資料日期、資料來源與授權、版本、**上次冷啟動耗時**、安裝包大小、伺服器時鐘校正量

---

## 二、為什麼它「準」

官方 ETA 就是上限，能做的只有不要把它弄髒。這版做了四件事：

1. **繞過 CDN 的 5 分鐘快取**
   九巴 ETA 響應頭是 `Cache-Control: max-age=300`。如果照單全收，中間層可能給你
   **五分鐘前**的班次。App 每次請求都帶 `_=<epoch>` 與 `Cache-Control: no-cache`，
   強制回源（實測 `X-Cache: TCP_MISS`）。
2. **雙方向過濾**
   九巴 `eta/{stop}/{route}/{service_type}` 會把該站**兩個方向**的班次一起返回。
   不按 `dir` + `service_type` 過濾，就會把反方向的車顯示出來。這條有真實響應的回歸測試
   （`tools/selftest` 會斷言 O 方向只出現尖沙咀碼頭、I 方向只出現中秀茂坪）。
3. **伺服器時間校正**
   用響應的 `Date` 頭 + 半程 RTT 算出與伺服器的時差，所有倒數用校正後的「現在」。
   手錶或刷機機時鐘偏幾分鐘，倒數依然是對的。
4. **新鮮度與來源都攤開講**
   每張卡顯示「資料 X 秒前」；超過 90 秒變色、180 秒轉橙；失敗時保留上次數字並標「離線」。

---

## 三、為什麼它「快」與「小」

| 手法 | 效果 |
| --- | --- |
| 不用 Gradle／AndroidX／Compose／Kotlin 標準庫 | APK 少 5–15 MB，冷啟動少幾百毫秒 |
| 自製二進制路線索引（見 `docs/05`）+ gzip 資源 | 9,365 個站只用 504 KB；解析成基本類型數組，不建每行對象 |
| 首屏讀上次 ETA 快取（幾 KB） | 開 App 第一幀就有數字，不等網絡 |
| 主線程零 I/O、零網絡 | 種子解析、快取讀寫、HTTP 全部在自帶小線程池 |
| 玻璃卡用緩存的漸變 shader 畫 | 沒有 Bitmap、沒有實時模糊、沒有軟件層，GPU 一次合成 |
| 倒數每秒只改可見行的文字 | 不做整屏重繪，120 Hz 機上每秒只有一次 `setText` |
| 背景極光 = 一張半解像度 Bitmap + 慢速平移 | 低內存機／手錶自動靜止 |

**可自證**：設定頁會顯示「上次冷啟動 XXX ms」——那是 App 用
`Process.getStartUptimeMillis()` 到第一幀之間的實測值，你自己裝上就能看，不用信 README。

---

## 四、安裝

```bat
:: 方式 1：adb
adb install -r dist\busNOW-1.0.apk

:: 方式 2：把 APK 傳到手機，點擊安裝（需允許「未知來源」）
```

簽名用工程自帶的**臨時密鑰** `keystore\busnow.keystore`（口令 `busnow2026`，
別名 `busnow`）。它只是為了讓你能覆蓋升級，**不要拿去上架**；要公開發布請自己重新生成密鑰。

---

## 五、重新編譯

需要：JDK 17+（Android Studio 自帶的 JBR 就行）、Android SDK（build-tools 36、platform android-36）、Node.js。

```bat
build.cmd
```

流水線（不用 Gradle，全部命令行）：

```
aapt2 compile  →  aapt2 link  →  javac  →  d8  →  node tools\pack.js
               →  zipalign -c  →  apksigner  →  node tools\verify-apk.js
```

- 版本號在 `version.txt`（`name=` / `code=`），會自動生成 `Version.java`
- 圖標由 `tools\make-icons.js` 程序化生成（純 JS PNG 編碼，無素材）
- 構建結束會打印 dex / 資源 / 種子 / APK 各自大小，**APK 超過 800 KB 直接失敗**（體積紅線）

### 其他命令

```bat
tools\selftest.cmd        :: 桌面 JVM 自測：種子解析、JSON、時間、兩個 ETA 解析器（真實響應快照）
preview\shot.cmd          :: 用無頭 Chrome 重出 dist\ui-preview.png
node tools\build-seed.js  :: 重新抓官方數據生成 assets\seed.bin.gz（有斷點緩存，可續跑）
```

`build.cmd`、`build.sh` 之外的腳本都在 `tools\`。

---

## 六、目錄

```
busNOW/
├─ AndroidManifest.xml          6 個 Activity、2 個權限、定位權限可選
├─ build.cmd / build.sh         構建入口（Windows / Unix）
├─ version.txt                  版本號唯一來源
├─ assets/
│  ├─ seed.bin.gz               離線路線索引（9,365 站 / 2,298 路線）
│  └─ seed-manifest.json        計數、sha256、CRC32
├─ src/hk/busnow/app/
│  ├─ MainActivity              首頁：常搭卡片、倒數、刷新
│  ├─ SearchActivity / RouteActivity / StopActivity / NearbyActivity / SettingsActivity
│  ├─ BaseActivity             語言與深淺色覆蓋（不用 AndroidX）
│  ├─ SeedActivity             等索引就緒再渲染的基類
│  ├─ data/                    SeedFormat(二進制)、Seed、Pins、EtaCache、Prefs
│  ├─ net/                     Http、KmbApi、CtbApi、Refresh
│  ├─ model/                   Eta、Arrivals、Pin
│  ├─ ui/                      AuroraBackground、GlassCard、Dock、SearchPill、Segmented、Style、L…
│  └─ util/                    Json(自寫)、TimeUtil、Clock
├─ res/                        佈局／矢量圖標／三語字串／深色配色
├─ tools/
│  ├─ build-seed.js            官方數據 → 二進制索引
│  ├─ make-icons.js            程序化圖標
│  ├─ pack.js                  把 dex 塞進 APK 並保持 4 字節對齊
│  ├─ verify-apk.js            靜態驗收：zip CRC、dex 字串、資源表對齊、種子 magic
│  ├─ selftest.cmd + selftest/ 桌面 JVM 自測
│  └─ fixtures/                真實 API 響應快照（測試用）
├─ preview/                    無頭 Chrome UI 復刻流水線
├─ docs/                       01 架構 · 02 數據源與準確性 · 03 性能與體積 · 04 構建與驗證
│                              05 種子格式 · 06 真機驗證清單 · 07 專案介紹與商店描述
└─ dist/                       APK + UI 預覽圖
```

---

## 七、驗證狀態

**真機驗證（Redmi 2409BRN2CY / Android 16 / 720×1640 / 90 Hz）**

| 項目 | 結果 |
| --- | --- |
| 冷啟動到第一幀 | **372 ms**（App 自測，設定頁可看；你的機器上會是另一個數字） |
| 九巴 ETA | ✅ 拿到（`1A` 中秀茂坪：5/12/19 分，與 API 返回的 10:35/10:42/10:49 一致） |
| 城巴批量 ETA | ✅ 一次請求返回 3 條路線（905P / 914 / 914X） |
| 九巴 WAF 會不會攔 Android | **不會**。同一台機器用 Node 會被 403，這台手機上的 App 正常拿到數據 |
| 釘選 → 首頁倒數 | ✅ 加入後即時出現在首頁，15 秒自動刷新，`資料 剛剛` |
| 「班次表」標記 | ✅ 與官方 `rmk_tc=原定班次` 逐條對得上（已用同時刻 API 響應核對） |
| 深色 / 淺色 | ✅ 兩套玻璃配色都正常 |
| 繁體 / 简体 / English | ✅ 三語切換即時生效（設備 zh-CN 時默認简体） |
| 附近車站 | ✅ 定位授權後按距離排序（86 m、93 m、101 m…），實測位置在深水埗 |
| 搜尋（大小寫無關） | ✅ 輸入 `1a` 命中 `1A` 兩個方向 |
| 崩潰 | 修完下列兩個 bug 後，全流程 `logcat -b crash` 為空 |

**真機上發現並修掉的兩個致命 bug**（這兩個靜態檢查都看不出來，感謝你的手機）：

1. `AuroraBackground` 只有 `(Context)` 構造器，XML inflate 需要 `(Context, AttributeSet)`
   → **一進主界面就 `InflateException` 閃退**（就是你遇到的那個）。
2. 改語言／主題後 Activity 重建，`applyOverrideConfiguration()` 拋
   `IllegalStateException: getResources() or getAssets() has already been called`
   → 切主題即閃退。改成在 `attachBaseContext()` 裡 `createConfigurationContext()`。
3. 附帶修掉：卡片用了 `setElevation` 導致內容區被畫成硬邊色塊；背景高光漸變在 42% 處留橫向接縫；
   `Timetable` 標籤換行；已開走的班次佔據主位顯示 `Departed`。

**靜態驗證（構建機上可做的全部）**

- [x] `aapt2 dump badging`：包名 `hk.busnow.app`、minSdk 21、targetSdk 36、啟動 Activity 正確
- [x] `apksigner verify`：v1 + v2 + v3 簽名有效
- [x] `zipalign -c -p 4`：對齊正確；`resources.arsc` 未壓縮且 4 字節對齊
- [x] `tools/verify-apk.js`：36 個 zip 條目逐條 CRC 通過、dex 內含入口類、種子 magic 正確
- [x] `tools/selftest.cmd`：**56,268 項斷言通過**（種子 CRC／站點查找／路線搜尋／方向過濾／
      時間解析／時鐘校正／城巴批量解析）

**仍未覆蓋**

- [ ] 240×240 手錶實機（本機只有手機；精簡模式是用 240dp 佈局邏輯寫的，未在真錶上看過）
- [ ] Android 5.0–10 的舊機（minSdk 21，但只在 Android 16 上跑過）
- [ ] `build.sh` 與 GitHub Actions（本機沒有 bash，只在 Windows 上驗證過 `build.cmd`）
- [ ] 城巴站名是構建時抓的（耗時 589 秒），站名更新要重新生成種子

裝上後如果有任何不對，把「哪個畫面 + 什麼機型 + Android 版本」發我，我直接改。

---

## 八、資料來源與授權

- 九巴／龍運：`https://data.etabus.gov.hk/v1/transport/kmb/…`（路線、站點、班次）
- 城巴：`https://rt.data.gov.hk/v2/transport/citybus/…` 與 OGCIO 批量接口
  `https://rt.data.gov.hk/v1/transport/batch/stop-eta/CTB/{stopId}`
- 使用條款：DATA.GOV.HK（[data.gov.hk](https://data.gov.hk/)）免費開放數據，
  需註明來源。App 內「設定 → 資料來源與授權」與本 README 均已註明。
- **本程式與九巴、龍運、城巴無任何關係**，只做顯示；班次以營辦商公佈為準。
- 程式碼：[MIT](LICENSE)。圖標與介面全部由代碼繪製，不含第三方素材。

---

## 九、已知取捨

1. **不做桌面小工具與到站通知**：兩者都要後台刷新與額外權限，會破壞「零後台」的省電前提。
   列在 v1.1。
2. **不支援新大嶼山巴士、專線小巴、港鐵巴士**：接口形態不同，先把三巴做紮實。
3. **種子數據跟版本走**：站名／路線變動很慢；App 會顯示資料日期，重新生成見 `docs/05`。
4. **液態玻璃是「模擬折射」**：用多層半透明漸變 + 1px 高光邊 + 柔和投影，
   **不是**實時背景模糊。真做實時模糊在低端機與手錶上一定掉幀，這是刻意的取捨。
5. **沒有 RecyclerView／ViewPager**：用框架自帶 `ListView`，行數少、複用足夠，
   省下一個依賴和一個 dex。

## 十、Roadmap

- [x] 真機驗證與修正（Redmi / Android 16 全流程通過）
- [ ] 240×240 手錶真機驗證
- [ ] 舊機（Android 5–10）驗證
- [ ] 桌面小工具（4×1，只顯示釘選路線的下一班）
- [ ] 到站提醒（本地通知，不聯網）
- [ ] 新大嶼山巴士
- [ ] 種子數據在線更新（只重下變更部分）
- [ ] 附近車站把同一地點的九巴／城巴站合併成一行
