package hk.busnow.app.util;

/**
 * Estimated "server now". The bus APIs answer with a Date header; we blend that with the round-trip
 * time so countdowns stay right even on a device whose clock is minutes off (common on cheap
 * watches and freshly flashed phones).
 */
public final class Clock {

    private static volatile long offsetMs;
    private static volatile boolean synced;

    private Clock() {
    }

    public static long now() {
        return System.currentTimeMillis() + offsetMs;
    }

    public static long offset() {
        return offsetMs;
    }

    public static boolean synced() {
        return synced;
    }

    public static void observe(long serverDateMs, long sentAtMs, long recvAtMs) {
        if (serverDateMs <= 0 || recvAtMs < sentAtMs) {
            return;
        }
        long rtt = recvAtMs - sentAtMs;
        long sample = serverDateMs + rtt / 2 - recvAtMs;
        if (Math.abs(sample) > 24L * 3600L * 1000L) {
            return;
        }
        synchronized (Clock.class) {
            if (!synced) {
                offsetMs = sample;
                synced = true;
            } else {
                offsetMs = (offsetMs * 3 + sample) / 4;
            }
        }
    }

    /** Only for diagnostics / tests. */
    public static void reset() {
        offsetMs = 0;
        synced = false;
    }
}
