package hk.busnow.app.model;

/** A pinned route/direction/stop, with everything the home screen needs to render offline. */
public final class Pin {

    public int op;
    public String route = "";
    public int bound;
    public int svc;
    public long stopKey;
    public String stopId = "";
    public int stopIdx = -1;
    public String stopTc = "";
    public String stopSc = "";
    public String stopEn = "";
    public String destTc = "";
    public String destSc = "";
    public String destEn = "";
    public long addedAt;

    public String key() {
        return op + "|" + route + "|" + bound + "|" + svc + "|" + stopId;
    }

    public String stopName(int lang) {
        if (lang == 1) {
            return first(stopSc, stopTc, stopEn);
        }
        if (lang == 2) {
            return first(stopEn, stopTc, stopSc);
        }
        return first(stopTc, stopEn, stopSc);
    }

    public String dest(int lang) {
        if (lang == 1) {
            return first(destSc, destTc, destEn);
        }
        if (lang == 2) {
            return first(destEn, destTc, destSc);
        }
        return first(destTc, destEn, destSc);
    }

    private static String first(String a, String b, String c) {
        if (a != null && a.length() > 0) {
            return a;
        }
        if (b != null && b.length() > 0) {
            return b;
        }
        return c == null ? "" : c;
    }
}
