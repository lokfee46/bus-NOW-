package hk.busnow.app.model;

/** One predicted arrival, already localised to the language that was requested. */
public final class Eta implements Comparable<Eta> {

    public final long etaMs;
    public final int seq;
    /**
     * True when the operator is publishing a timetable slot rather than a GPS-based prediction
     * (KMB marks those with "原定班次" / "Scheduled Bus"). Shown differently on purpose: it is
     * honest about how accurate that particular number is.
     */
    public final boolean scheduled;
    public final String remark;
    public final String destTc;
    public final String destSc;
    public final String destEn;

    public Eta(long etaMs, int seq, boolean scheduled, String remark,
               String destTc, String destSc, String destEn) {
        this.etaMs = etaMs;
        this.seq = seq;
        this.scheduled = scheduled;
        this.remark = remark == null ? "" : remark;
        this.destTc = destTc == null ? "" : destTc;
        this.destSc = destSc == null ? "" : destSc;
        this.destEn = destEn == null ? "" : destEn;
    }

    public String dest(int lang) {
        if (lang == 1) {
            return destSc.length() > 0 ? destSc : destTc.length() > 0 ? destTc : destEn;
        }
        if (lang == 2) {
            return destEn.length() > 0 ? destEn : destTc;
        }
        return destTc.length() > 0 ? destTc : destEn;
    }

    @Override
    public int compareTo(Eta o) {
        return etaMs < o.etaMs ? -1 : etaMs > o.etaMs ? 1 : 0;
    }
}
