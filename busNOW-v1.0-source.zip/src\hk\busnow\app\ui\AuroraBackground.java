package hk.busnow.app.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

/**
 * Static aurora backdrop, rendered once into a half-resolution bitmap and up-scaled with bilinear
 * filtering (cheap "blur"). An optional slow drift only re-draws that one bitmap, so it costs a single
 * textured quad per frame and is skipped entirely on low-end devices or when the user turns it off.
 */
public class AuroraBackground extends View {

    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final Matrix matrix = new Matrix();
    private Bitmap cache;
    private boolean animate;
    private long start = SystemClock.uptimeMillis();
    private long lastTick;

    public AuroraBackground(Context c) {
        this(c, null);
    }

    /** Required for XML inflation (layout files reference this view by class name). */
    public AuroraBackground(Context c, AttributeSet attrs) {
        super(c, attrs);
        setLayerType(LAYER_TYPE_NONE, null);
        paint.setFilterBitmap(true);
    }

    public void setAnimate(boolean on) {
        animate = on;
        if (on) {
            start = SystemClock.uptimeMillis();
            postInvalidateOnAnimation();
        } else {
            invalidate();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        build(w, h);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (cache != null) {
            cache.recycle();
            cache = null;
        }
    }

    private void build(int w, int h) {
        if (w <= 0 || h <= 0) {
            return;
        }
        int bw = Math.max(1, w / 2);
        int bh = Math.max(1, h / 2);
        if (cache != null && cache.getWidth() == bw && cache.getHeight() == bh) {
            return;
        }
        if (cache != null) {
            cache.recycle();
        }
        cache = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(cache);
        boolean night = Ui.isNight(getContext());

        int top = night ? 0xFF070B18 : 0xFFF5F8FF;
        int mid = night ? 0xFF0A1226 : 0xFFEDF2FC;
        int bottom = night ? 0xFF04060D : 0xFFF7F9FE;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, bh, new int[]{top, mid, bottom}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, bw, bh, p);

        int[] colors = night
                ? new int[]{0x46325BFF, 0x3A8A3BFF, 0x2C00C2A8, 0x220A66FF}
                : new int[]{0x8C9DBBFF, 0x7AD3C4FF, 0x5CB8F5EA, 0x4A8FB6FF};
        float[][] spots = {
                {0.10f, 0.02f, 0.85f},
                {0.95f, 0.14f, 0.70f},
                {0.70f, 0.98f, 0.75f},
                {0.25f, 0.62f, 0.60f},
        };
        for (int i = 0; i < spots.length; i++) {
            float cx = spots[i][0] * bw;
            float cy = spots[i][1] * bh;
            float r = spots[i][2] * Math.max(bw, bh);
            int col = colors[i];
            p.setShader(new RadialGradient(cx, cy, r,
                    new int[]{col, (col & 0x00FFFFFF)}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
        }

        // A soft glass sheen over the top third. The gradient must reach zero alpha exactly at the
        // edge of the rect, otherwise it leaves a visible horizontal seam (a diagonal gradient over
        // a clipped rect does: its bottom edge is still ~half alpha).
        float sheenH = bh * 0.55f;
        p.setShader(new LinearGradient(0, 0, 0, sheenH,
                new int[]{0x26FFFFFF, 0x00FFFFFF}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, bw, sheenH, p);
        p.setShader(null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (cache == null || cache.isRecycled()) {
            return;
        }
        float sx = (float) getWidth() / cache.getWidth();
        float sy = (float) getHeight() / cache.getHeight();
        matrix.reset();
        if (animate) {
            long t = SystemClock.uptimeMillis() - start;
            float dx = (float) Math.sin(t / 9000.0) * Ui.dp(getContext(), 14);
            float dy = (float) Math.cos(t / 13000.0) * Ui.dp(getContext(), 9);
            matrix.postScale(sx * 1.10f, sy * 1.10f);
            matrix.postTranslate(-0.05f * getWidth() + dx, -0.05f * getHeight() + dy);
        } else {
            matrix.postScale(sx, sy);
        }
        canvas.drawBitmap(cache, matrix, paint);
        if (animate) {
            long now = SystemClock.uptimeMillis();
            long since = now - lastTick;
            if (since >= 33) {
                lastTick = now;
                postInvalidateOnAnimation();
            } else {
                postInvalidateDelayed(33 - since);
            }
        }
    }
}
