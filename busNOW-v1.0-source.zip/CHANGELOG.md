# Changelog

## v1.0 — 2026-11-01

首個版本（已在一台 Redmi 2409BRN2CY / Android 16 上全流程驗證）。

### 真機上發現並修復

- **閃退（主界面）**：`AuroraBackground` 缺少 `(Context, AttributeSet)` 構造器，
  XML inflate 時 `InflateException`。
- **閃退（切換主題／語言）**：`applyOverrideConfiguration()` 在 Activity 重建時拋
  `IllegalStateException: getResources() or getAssets() has already been called`；
  改為 `attachBaseContext()` + `createConfigurationContext()`。
- 卡片 `setElevation` 在 Android 16 上把內容區畫成硬邊色塊 → 去掉 elevation，改用邊框＋內陰影。
- 背景高光漸變在 42% 高度留下橫向接縫 → 改為豎直漸變並在邊緣降到零 alpha。
- 英文 `Timetable` 標籤換行 → 縮短為 `Sched` 並限制單行。
- 已開走的班次佔據主位顯示 `Departed` → 主位改為「第一個未開走」的班次。

### 功能

- 首頁常搭卡片：大字分鐘倒數、後兩班、預計到站時鐘、資料新鮮度、班次表/實時標記
- 搜尋（路線號／繁簡英站名，離線）、路線站序、車站全部路線即時到站、附近車站
- 九巴／龍運 + 城巴；城巴走 OGCIO 批量接口，一次請求覆蓋全站
- 內建離線索引：9,365 站 / 2,298 路線 / 53,815 站序（504 KB gzip）
- 準確性：繞過九巴 ETA 的 `max-age=300` CDN 快取、雙方向過濾、伺服器時鐘校正、
  資料新鮮度顯示、403/429 退避
- 體積：646.6 KB，零第三方依賴，不用 Gradle／AndroidX／Compose
- 性能：主線程零 I/O、玻璃卡零 Bitmap、每秒只更新可見行；實測冷啟動 372 ms
- 繁中／简体／English，深淺色，240×240 手錶精簡模式
- 驗證：apksigner、zipalign、zip CRC、dex 內容、種子 CRC、桌面 JVM 自測 56,268 項斷言
- **未做**：手錶真機、舊機（Android 5–10）、桌面小工具、到站通知、NLB／小巴／港鐵
