package hk.busnow.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import hk.busnow.app.data.Pins;
import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Pin;
import hk.busnow.app.net.Refresh;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Style;
import hk.busnow.app.ui.Ui;

/** Live board for one stop: every route serving it, with a pin button on each row. */
public class StopActivity extends SeedActivity implements Refresh.StopListener {

    private static final String EXTRA_STOP = "stopIdx";

    private final Handler main = new Handler(Looper.getMainLooper());
    private SeedFormat seed;
    private int stopIdx;
    private int lang;
    private BoardRow adapter;
    private ListView board;
    private ImageView refreshButton;
    private Refresh refresh;
    private boolean resumed;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (adapter != null) {
                adapter.updateVisible();
            }
            main.postDelayed(this, 1000L);
        }
    };

    public static void start(Context c, int stopIdx) {
        Intent i = new Intent(c, StopActivity.class);
        i.putExtra(EXTRA_STOP, stopIdx);
        c.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stop);
        Ui.edgeToEdge(this, findViewById(R.id.content));
        lang = L.lang(this);
        board = (ListView) findViewById(R.id.board);
        board.setDivider(null);
        board.setSelector(android.R.color.transparent);
        board.setCacheColorHint(0);

        View back = findViewById(R.id.back);
        Style.iconButton(back, getResources().getColor(R.color.ink2));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        refreshButton = (ImageView) findViewById(R.id.refresh);
        Style.iconButton(refreshButton, getResources().getColor(R.color.ink2));
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshBoard();
            }
        });
    }

    @Override
    protected void onSeedReady(SeedFormat seed) {
        this.seed = seed;
        stopIdx = getIntent().getIntExtra(EXTRA_STOP, -1);
        if (stopIdx < 0 || stopIdx >= seed.stopCount) {
            finish();
            return;
        }
        ((TextView) findViewById(R.id.title)).setText(seed.stopName(stopIdx, lang));
        final int[] routes = Refresh.boardRoutes(seed, stopIdx);
        ((TextView) findViewById(R.id.subtitle)).setText(
                L.opName(this, seed.stopOp[stopIdx]) + " · "
                        + getString(R.string.routes_count, routes.length));
        adapter = new BoardRow(this, seed, stopIdx, lang, routes, board, new BoardRow.OnAdd() {
            @Override
            public void onAdd(int routeIdx) {
                pin(routeIdx);
            }
        });
        board.setAdapter(adapter);
        board.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                RouteActivity.start(StopActivity.this, adapter.routeAt(position));
            }
        });
        refreshBoard();
        startTicker();
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (adapter != null) {
            refreshBoard();
            startTicker();
        }
    }

    @Override
    protected void onPause() {
        resumed = false;
        main.removeCallbacks(ticker);
        if (refresh != null) {
            refresh.cancel();
        }
        super.onPause();
    }

    private void startTicker() {
        main.removeCallbacks(ticker);
        main.post(ticker);
    }

    private void refreshBoard() {
        if (adapter == null || seed == null) {
            return;
        }
        if (refresh == null) {
            refresh = new Refresh();
        }
        refreshButton.setAlpha(0.45f);
        adapter.setDone();
        refresh.stopBoard(seed, stopIdx, lang, this);
    }

    @Override
    public void onRouteArrivals(int routeIdx, Arrivals arrivals) {
        if (adapter == null) {
            return;
        }
        adapter.put(routeIdx, arrivals);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onDone() {
        refreshButton.setAlpha(1f);
    }

    private void pin(int routeIdx) {
        Pin p = new Pin();
        p.op = seed.routeOp[routeIdx];
        p.route = seed.routeName(routeIdx);
        p.bound = seed.routeBound[routeIdx];
        p.svc = seed.routeSvc[routeIdx];
        p.stopIdx = stopIdx;
        p.stopKey = seed.stopKey[stopIdx];
        p.stopId = seed.stopId(stopIdx);
        p.stopTc = seed.stopName(stopIdx, SeedFormat.TC);
        p.stopSc = seed.stopName(stopIdx, SeedFormat.SC);
        p.stopEn = seed.stopName(stopIdx, SeedFormat.EN);
        p.destTc = seed.routeDest(routeIdx, SeedFormat.TC);
        p.destSc = seed.routeDest(routeIdx, SeedFormat.SC);
        p.destEn = seed.routeDest(routeIdx, SeedFormat.EN);
        p.addedAt = System.currentTimeMillis();

        List<Pin> pins = Pins.load(this);
        boolean added = Pins.add(pins, p);
        if (added) {
            Pins.save(this, pins);
        }
        Toast.makeText(this, added ? R.string.added : R.string.duplicate, Toast.LENGTH_SHORT).show();
    }
}
