package hk.busnow.app.ui;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import hk.busnow.app.R;

/** Two-to-four option segmented control drawn with a moving highlight (no AndroidX). */
public class Segmented extends LinearLayout {

    public interface OnChange {
        void onChange(int index);
    }

    private String[] labels = new String[0];
    private int selected;
    private OnChange listener;

    public Segmented(Context c, AttributeSet attrs) {
        super(c, attrs);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setPadding(Ui.dpi(c, 4), Ui.dpi(c, 4), Ui.dpi(c, 4), Ui.dpi(c, 4));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(Ui.dp(c, 20));
        bg.setColor(c.getResources().getColor(R.color.pill_fill));
        bg.setStroke(Math.max(1, Ui.dpi(c, 1)), c.getResources().getColor(R.color.pill_stroke));
        setBackground(bg);
    }

    public void setLabels(String[] labels) {
        this.labels = labels;
        removeAllViews();
        for (int i = 0; i < labels.length; i++) {
            TextView t = new TextView(getContext());
            t.setText(labels[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12.5f);
            t.setTypeface(Ui.medium());
            t.setIncludeFontPadding(false);
            t.setClickable(true);
            t.setFocusable(true);
            t.setLayoutParams(new LayoutParams(0, LayoutParams.MATCH_PARENT, 1f));
            final int index = i;
            t.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (selected != index) {
                        select(index, true);
                    }
                }
            });
            addView(t);
        }
        select(Math.min(selected, Math.max(0, labels.length - 1)), false);
    }

    public void setOnChange(OnChange l) {
        listener = l;
    }

    public void select(int index) {
        select(index, false);
    }

    private void select(int index, boolean notify) {
        selected = index;
        int accent = getResources().getColor(R.color.accent);
        int ink = getResources().getColor(R.color.ink2);
        for (int i = 0; i < getChildCount(); i++) {
            TextView t = (TextView) getChildAt(i);
            boolean on = i == index;
            t.setTextColor(on ? accent : ink);
            if (on) {
                GradientDrawable bg = new GradientDrawable();
                bg.setCornerRadius(Ui.dp(getContext(), 16));
                bg.setColor(Ui.alpha(accent, 0x22));
                t.setBackground(bg);
            } else {
                t.setBackground(null);
            }
        }
        if (notify && listener != null) {
            listener.onChange(index);
        }
    }

    public int selected() {
        return selected;
    }
}
