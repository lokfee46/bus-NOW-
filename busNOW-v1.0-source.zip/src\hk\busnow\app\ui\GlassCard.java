package hk.busnow.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import hk.busnow.app.R;

/**
 * The frosted panel used everywhere. Drawn with a handful of cached gradient shaders (no bitmaps,
 * no blur layers, no software rendering), so a screen full of them still composites on the GPU at
 * 120 Hz, and there is no per-card bitmap eating memory on a 512 MB device.
 */
public class GlassCard extends FrameLayout {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path clip = new Path();

    private float radius;
    private int fillTop;
    private int fillBottom;
    private int edgeColor;
    private int shadeColor;

    public GlassCard(Context c) {
        this(c, null);
    }

    public GlassCard(Context c, AttributeSet attrs) {
        super(c, attrs);
        fillTop = getResources().getColor(R.color.glass_fill);
        fillBottom = getResources().getColor(R.color.glass_fill2);
        edgeColor = getResources().getColor(R.color.glass_edge);
        shadeColor = getResources().getColor(R.color.glass_shade);
        radius = Ui.dp(c, 22);
        setWillNotDraw(false);
        pressPaint.setColor(0x12FFFFFF);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(Math.max(1f, Ui.dp(c, 1f)));

        // No View.setElevation: on Android 16 an elevated custom-drawn view is composited through a
        // RenderNode and its content area showed up as a hard-edged lighter rectangle. Depth comes
        // from the border plus the inner bottom shade instead.
        setElevation(0);
    }

    public void setRadius(float dp) {
        radius = Ui.dp(getContext(), dp);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) {
            return;
        }
        rect.set(0, 0, w, h);
        fill.setShader(new LinearGradient(0, 0, 0, h, fillTop, fillBottom, Shader.TileMode.CLAMP));
        sheen.setShader(new LinearGradient(0, 0, w * 0.72f, h * 0.55f,
                0x1AFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        shade.setShader(new LinearGradient(0, h * 0.55f, 0, h,
                0x00000000, shadeColor, Shader.TileMode.CLAMP));
        edge.setShader(new LinearGradient(0, 0, w, h, edgeColor,
                Ui.alpha(edgeColor, 0x1A), Shader.TileMode.CLAMP));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (getWidth() <= 0 || getHeight() <= 0) {
            return;
        }
        c.drawRoundRect(rect, radius, radius, fill);
        int save = c.save();
        clip.reset();
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW);
        c.clipPath(clip);
        c.drawRect(0, 0, getWidth(), getHeight(), sheen);
        c.drawRect(0, getHeight() * 0.55f, getWidth(), getHeight(), shade);
        c.restoreToCount(save);
        c.drawRoundRect(rect, radius, radius, edge);
        if (isPressed()) {
            c.drawRoundRect(rect, radius, radius, pressPaint);
        }
    }
}
