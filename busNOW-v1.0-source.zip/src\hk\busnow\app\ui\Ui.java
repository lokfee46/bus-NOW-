package hk.busnow.app.ui;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Build;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;

/** Small, dependency-free UI helpers: dp/sp, typefaces, edge-to-edge insets, system bar tint. */
public final class Ui {

    private static Typeface REGULAR, MEDIUM, LIGHT;

    private Ui() {
    }

    public static float dp(Context c, float v) {
        return v * c.getResources().getDisplayMetrics().density;
    }

    public static int dpi(Context c, float v) {
        return Math.round(dp(c, v));
    }

    public static float sp(Context c, float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, c.getResources().getDisplayMetrics());
    }

    public static Typeface regular() {
        if (REGULAR == null) {
            REGULAR = Typeface.create("sans-serif", Typeface.NORMAL);
        }
        return REGULAR;
    }

    public static Typeface medium() {
        if (MEDIUM == null) {
            MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
        }
        return MEDIUM;
    }

    public static Typeface light() {
        if (LIGHT == null) {
            LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);
        }
        return LIGHT;
    }

    public static int alpha(int color, int a) {
        if (a < 0) {
            a = 0;
        }
        if (a > 255) {
            a = 255;
        }
        return (color & 0x00FFFFFF) | (a << 24);
    }

    public static boolean isNight(Context c) {
        int mode = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    /** Draw under the status/navigation bars and pad [v] so its content stays clear of them. */
    public static void edgeToEdge(Activity a, final View v) {
        Window w = a.getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.setStatusBarColor(0x00000000);
            w.setNavigationBarColor(0x00000000);
        }
        final int padL = v.getPaddingLeft();
        final int padT = v.getPaddingTop();
        final int padR = v.getPaddingRight();
        final int padB = v.getPaddingBottom();
        v.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                view.setPadding(
                        padL + insets.getSystemWindowInsetLeft(),
                        padT + insets.getSystemWindowInsetTop(),
                        padR + insets.getSystemWindowInsetRight(),
                        padB + insets.getSystemWindowInsetBottom());
                return insets;
            }
        });
    }

    /** Force light/dark status-bar icons to match the backdrop. */
    public static void systemBarIcons(Activity a, boolean lightBackground) {
        Window w = a.getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View d = w.getDecorView();
            int f = d.getSystemUiVisibility();
            if (lightBackground) {
                f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (lightBackground) {
                    f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                } else {
                    f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
            }
            d.setSystemUiVisibility(f);
        }
    }
}
