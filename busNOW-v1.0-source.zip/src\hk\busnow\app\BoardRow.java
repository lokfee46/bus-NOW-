package hk.busnow.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Eta;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Style;
import hk.busnow.app.ui.Ui;
import hk.busnow.app.util.Clock;

/** Live board of every route calling at one stop. Rows fill in as their requests land. */
final class BoardRow extends BaseAdapter {

    interface OnAdd {
        void onAdd(int routeIdx);
    }

    static final class H {
        TextView badge;
        TextView dest;
        TextView eta;
        ImageView add;
        int routeIdx;
    }

    private final Context c;
    private final SeedFormat seed;
    private final int stopIdx;
    private final int lang;
    private final int[] routes;
    private final Map<Integer, Arrivals> arrivals = new HashMap<Integer, Arrivals>();
    private final ListView list;
    private final OnAdd onAdd;
    private final int ink2;
    private final int ink3;
    private boolean done;

    BoardRow(Context c, SeedFormat seed, int stopIdx, int lang, int[] routes, ListView list, OnAdd onAdd) {
        this.c = c;
        this.seed = seed;
        this.stopIdx = stopIdx;
        this.lang = lang;
        this.routes = routes;
        this.list = list;
        this.onAdd = onAdd;
        this.ink2 = c.getResources().getColor(R.color.ink2);
        this.ink3 = c.getResources().getColor(R.color.ink3);
    }

    void put(int routeIdx, Arrivals a) {
        arrivals.put(Integer.valueOf(routeIdx), a);
    }

    void setDone() {
        done = true;
    }

    boolean isDone() {
        return done;
    }

    @Override
    public int getCount() {
        return routes.length;
    }

    @Override
    public Object getItem(int position) {
        return Integer.valueOf(routes[position]);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    int routeAt(int position) {
        return routes[position];
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(c).inflate(R.layout.item_board, parent, false);
            H h = new H();
            h.badge = (TextView) v.findViewById(R.id.badge);
            h.dest = (TextView) v.findViewById(R.id.dest);
            h.eta = (TextView) v.findViewById(R.id.eta);
            h.add = (ImageView) v.findViewById(R.id.add);
            h.add.setColorFilter(c.getResources().getColor(R.color.accent));
            h.add.setBackground(Style.rounded(c,
                    Ui.alpha(c.getResources().getColor(R.color.accent), 0x1A), 19));
            final H holder = h;
            h.add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (onAdd != null) {
                        onAdd.onAdd(holder.routeIdx);
                    }
                }
            });
            v.setTag(h);
        }
        H h = (H) v.getTag();
        int ri = routes[position];
        h.routeIdx = ri;
        Style.routeBadge(h.badge, seed.routeOp[ri]);
        h.badge.setText(seed.routeName(ri));
        h.dest.setText(c.getString(R.string.direction_to, seed.routeDest(ri, lang)));
        bindEta(h, ri);
        return v;
    }

    private void bindEta(H h, int ri) {
        Arrivals a = arrivals.get(Integer.valueOf(ri));
        if (a == null) {
            h.eta.setText(done ? "—" : c.getString(R.string.eta_loading));
            h.eta.setTextColor(done ? ink3 : ink2);
            return;
        }
        if (!a.ok()) {
            h.eta.setText(R.string.eta_failed);
            h.eta.setTextColor(c.getResources().getColor(R.color.warn));
            return;
        }
        if (a.list.length == 0) {
            h.eta.setText(R.string.no_arrivals);
            h.eta.setTextColor(ink3);
            return;
        }
        long now = Clock.now();
        int start = L.firstUpcoming(a.list, now);
        if (start < 0) {
            h.eta.setText(R.string.departed);
            h.eta.setTextColor(ink3);
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < a.list.length && i < start + 3; i++) {
            Eta e = a.list[i];
            int m = L.etaMinutes(e.etaMs, now);
            if (sb.length() > 0) {
                sb.append(" · ");
            }
            if (m >= 0) {
                sb.append(m).append(' ').append(c.getString(R.string.minute_unit));
            } else if (m == L.ARRIVING) {
                sb.append(c.getString(R.string.arriving));
            } else {
                sb.append('—');
            }
        }
        h.eta.setText(sb);
        h.eta.setTextColor(ink2);
    }

    void updateVisible() {
        for (int i = 0; i < list.getChildCount(); i++) {
            View v = list.getChildAt(i);
            Object tag = v.getTag();
            if (tag instanceof H) {
                H h = (H) tag;
                bindEta(h, h.routeIdx);
            }
        }
    }

    String keyFor(int routeIdx) {
        return seed.routeName(routeIdx) + "|" + seed.routeBound[routeIdx];
    }
}
