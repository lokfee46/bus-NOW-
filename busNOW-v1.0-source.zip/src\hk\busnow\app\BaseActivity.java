package hk.busnow.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;

import java.util.Locale;

import hk.busnow.app.data.Prefs;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Ui;

/**
 * Applies the user's language / theme overrides to the activity's base context.
 *
 * <p>Done in {@link #attachBaseContext} rather than with {@code applyOverrideConfiguration()}:
 * the latter throws "getResources() or getAssets() has already been called" as soon as the activity
 * is recreated (reproduced on Android 16 when switching the theme), because the framework has
 * already touched resources for the new instance.
 */
public abstract class BaseActivity extends Activity {

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(withOverrides(newBase));
    }

    private static Context withOverrides(Context base) {
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        boolean changed = false;
        int lang = Prefs.lang(base);
        if (lang >= 0) {
            Locale locale = L.locale(lang);
            cfg.setLocale(locale);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cfg.setLocales(new LocaleList(locale));
            }
            changed = true;
        }
        int theme = Prefs.theme(base);
        if (theme >= 0) {
            cfg.uiMode = (cfg.uiMode & ~Configuration.UI_MODE_NIGHT_MASK)
                    | (theme == 1 ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO);
            changed = true;
        }
        return changed ? base.createConfigurationContext(cfg) : base;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(isNightMode() ? R.style.Theme_BusNow_Dark : R.style.Theme_BusNow);
        super.onCreate(savedInstanceState);
        Ui.systemBarIcons(this, !isNightMode());
    }

    protected boolean isNightMode() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }
}
