package hk.busnow.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.Arrays;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Style;
import hk.busnow.app.ui.Ui;

/** One route: direction chips plus its stop sequence. */
public class RouteActivity extends SeedActivity {

    private static final String EXTRA_IDX = "routeIdx";

    private SeedFormat seed;
    private int lang;
    private int currentIdx;
    private LinearLayout dirs;
    private ListView stops;
    private TextView title;
    private TextView subtitle;
    private TextView badge;

    public static void start(Context c, int routeIdx) {
        Intent i = new Intent(c, RouteActivity.class);
        i.putExtra(EXTRA_IDX, routeIdx);
        c.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route);
        Ui.edgeToEdge(this, findViewById(R.id.content));
        lang = L.lang(this);
        title = (TextView) findViewById(R.id.title);
        subtitle = (TextView) findViewById(R.id.subtitle);
        badge = (TextView) findViewById(R.id.badge);
        dirs = (LinearLayout) findViewById(R.id.dirs);
        stops = (ListView) findViewById(R.id.stops);
        stops.setDivider(null);
        stops.setSelector(android.R.color.transparent);
        stops.setCacheColorHint(0);

        View back = findViewById(R.id.back);
        Style.iconButton(back, getResources().getColor(R.color.ink2));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        stops.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                StopSeqRow a = (StopSeqRow) stops.getAdapter();
                StopActivity.start(RouteActivity.this, a.stopAt(position));
            }
        });
    }

    @Override
    protected void onSeedReady(SeedFormat seed) {
        this.seed = seed;
        currentIdx = getIntent().getIntExtra(EXTRA_IDX, -1);
        if (currentIdx < 0 || currentIdx >= seed.routeCount) {
            finish();
            return;
        }
        buildDirections();
        showRoute(currentIdx);
    }

    private int[] variants() {
        String name = seed.routeName(currentIdx);
        int op = seed.routeOp[currentIdx];
        int[] tmp = new int[8];
        int n = 0;
        for (int i = 0; i < seed.routeCount; i++) {
            if (seed.routeOp[i] == op && seed.routeName(i).equalsIgnoreCase(name)) {
                if (n == tmp.length) {
                    tmp = Arrays.copyOf(tmp, n * 2);
                }
                tmp[n++] = i;
            }
        }
        final SeedFormat s = seed;
        Integer[] boxed = new Integer[n];
        for (int i = 0; i < n; i++) {
            boxed[i] = tmp[i];
        }
        Arrays.sort(boxed, new java.util.Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                if (s.routeBound[a] != s.routeBound[b]) {
                    return s.routeBound[a] - s.routeBound[b];
                }
                return s.routeSvc[a] - s.routeSvc[b];
            }
        });
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            out[i] = boxed[i];
        }
        return out;
    }

    private void buildDirections() {
        int[] vs = variants();
        dirs.removeAllViews();
        int accent = getResources().getColor(R.color.accent);
        int ink2 = getResources().getColor(R.color.ink2);
        for (int i = 0; i < vs.length; i++) {
            final int idx = vs[i];
            boolean on = idx == currentIdx;
            TextView chip = new TextView(this);
            String label = getString(R.string.direction_to, seed.routeDest(idx, lang));
            if (seed.routeSvc[idx] != 1) {
                label = label + " · " + seed.routeSvc[idx];
            }
            chip.setText(label);
            chip.setTextSize(12f);
            chip.setTypeface(Ui.medium());
            chip.setGravity(Gravity.CENTER);
            chip.setIncludeFontPadding(false);
            chip.setPadding(Ui.dpi(this, 14), Ui.dpi(this, 9), Ui.dpi(this, 14), Ui.dpi(this, 9));
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(Ui.dp(this, 16));
            bg.setColor(on ? Ui.alpha(accent, 0x26) : getResources().getColor(R.color.pill_fill));
            bg.setStroke(Math.max(1, Ui.dpi(this, 1)),
                    on ? Ui.alpha(accent, 0x66) : getResources().getColor(R.color.pill_stroke));
            chip.setBackground(bg);
            chip.setTextColor(on ? accent : ink2);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dpi(this, 8);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (idx != currentIdx) {
                        currentIdx = idx;
                        buildDirections();
                        showRoute(idx);
                    }
                }
            });
            dirs.addView(chip);
        }
    }

    private void showRoute(int idx) {
        Style.routeBadge(badge, seed.routeOp[idx]);
        badge.setText(seed.routeName(idx));
        title.setText(getString(R.string.direction_to, seed.routeDest(idx, lang)));
        String sub = L.opName(this, seed.routeOp[idx]) + " · "
                + getString(R.string.stops_count, (int) seed.routeRefCount[idx]);
        if (seed.routeSvc[idx] != 1) {
            sub = sub + " · " + getString(R.string.service_type, seed.routeSvc[idx]);
        }
        subtitle.setText(sub);
        stops.setAdapter(new StopSeqRow(this, seed, idx, lang));
        stops.setSelection(0);
    }
}
