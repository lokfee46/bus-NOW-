@echo off
rem ============================================================================
rem  bus NOW - command line Android build.
rem  No Gradle, no AndroidX, no third-party dependencies.
rem
rem    build.cmd
rem
rem  Needs: a JDK (JAVA_HOME or Android Studio JBR), Android SDK with
rem         build-tools 36 / platform android-36, Node.js.
rem  Output: dist\busNOW-<version>.apk
rem
rem  This file is intentionally ASCII-only (cmd codepage safety).
rem ============================================================================
setlocal enabledelayedexpansion
chcp 65001 >nul
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"

rem --- toolchain --------------------------------------------------------------
set "JBR=C:\Program Files\Android\Android Studio\jbr"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" set "JBR=%JAVA_HOME%"
if not exist "%JBR%\bin\javac.exe" (
  echo [busNOW] JDK not found. Set JAVA_HOME to a JDK 17+ ^(Android Studio JBR is fine^).
  exit /b 1
)

if defined ANDROID_SDK_ROOT (set "SDK=%ANDROID_SDK_ROOT%") else (set "SDK=%LOCALAPPDATA%\Android\Sdk")
if not exist "%SDK%\build-tools" (
  echo [busNOW] Android SDK not found at "%SDK%". Set ANDROID_SDK_ROOT.
  exit /b 1
)

set "BT=%SDK%\build-tools\36.0.0"
if not exist "%BT%\aapt2.exe" (
  for /f "delims=" %%d in ('dir /b /ad /o-n "%SDK%\build-tools" 2^>nul') do (
    if not exist "%BT%\aapt2.exe" set "BT=%SDK%\build-tools\%%d"
  )
)

set "PLAT=%SDK%\platforms\android-36\android.jar"
if not exist "%PLAT%" set "PLAT=%SDK%\platforms\android-37.0\android.jar"
if not exist "%PLAT%" set "PLAT=%SDK%\platforms\android-35\android.jar"
if not exist "%PLAT%" (
  echo [busNOW] android.jar not found under "%SDK%\platforms".
  exit /b 1
)

set "AAPT2=%BT%\aapt2.exe"
set "D8=%BT%\d8.bat"
set "ZIPALIGN=%BT%\zipalign.exe"
set "APKSIGNER=%BT%\apksigner.bat"
set "JAVAC=%JBR%\bin\javac.exe"
set "KEYTOOL=%JBR%\bin\keytool.exe"
set "JAVA_HOME=%JBR%"
set "PATH=%JBR%\bin;%BT%;%PATH%"

where node >nul 2>nul
if errorlevel 1 (
  echo [busNOW] Node.js not found in PATH ^(needed for icon + APK packing^).
  exit /b 1
)

rem --- version ----------------------------------------------------------------
set "VERSION=1.0"
set "VERCODE=1"
for /f "usebackq tokens=1,2 delims==" %%a in ("%ROOT%\version.txt") do (
  if /i "%%a"=="name" set "VERSION=%%b"
  if /i "%%a"=="code" set "VERCODE=%%b"
)

set "BUILD=%ROOT%\build"
set "GEN=%BUILD%\gen"
set "CLS=%BUILD%\classes"
set "DEX=%BUILD%\dex"
set "OUT=%ROOT%\dist"
set "LOG=%BUILD%\log.txt"
set "KS=%ROOT%\keystore\busnow.keystore"
set "KSPASS=busnow2026"
set "APK=%OUT%\busNOW-%VERSION%.apk"

echo.
echo [busNOW] version %VERSION% (%VERCODE%)
echo [busNOW] jdk      %JBR%
echo [busNOW] build    %BT%
echo [busNOW] platform %PLAT%
echo.

rem --- clean ------------------------------------------------------------------
if exist "%BUILD%" rmdir /s /q "%BUILD%"
mkdir "%GEN%" 2>nul
mkdir "%CLS%" 2>nul
mkdir "%DEX%" 2>nul
mkdir "%OUT%" 2>nul
mkdir "%ROOT%\keystore" 2>nul

rem --- icons ------------------------------------------------------------------
echo ==^> icons
node "%ROOT%\tools\make-icons.js"
if errorlevel 1 (echo [fail] icon generation & exit /b 1)

rem --- resources --------------------------------------------------------------
echo ==^> aapt2 compile
"%AAPT2%" compile --dir "%ROOT%\res" -o "%BUILD%\res.zip" --no-crunch > "%LOG%" 2>&1
if errorlevel 1 (type "%LOG%" & echo [fail] aapt2 compile & exit /b 1)

echo ==^> aapt2 link
"%AAPT2%" link -o "%BUILD%\base.apk" -I "%PLAT%" --manifest "%ROOT%\AndroidManifest.xml" ^
  -R "%BUILD%\res.zip" -A "%ROOT%\assets" --java "%GEN%" ^
  --min-sdk-version 21 --target-sdk-version 36 ^
  --version-code %VERCODE% --version-name %VERSION% --auto-add-overlay > "%LOG%" 2>&1
if errorlevel 1 (type "%LOG%" & echo [fail] aapt2 link & exit /b 1)

rem --- generated version class -----------------------------------------------
mkdir "%GEN%\hk\busnow\app" 2>nul
> "%GEN%\hk\busnow\app\Version.java" echo package hk.busnow.app;
>>"%GEN%\hk\busnow\app\Version.java" echo.
>>"%GEN%\hk\busnow\app\Version.java" echo public final class Version {
>>"%GEN%\hk\busnow\app\Version.java" echo     public static final String NAME = "!VERSION!";
>>"%GEN%\hk\busnow\app\Version.java" echo     public static final int CODE = !VERCODE!;
>>"%GEN%\hk\busnow\app\Version.java" echo     private Version() {}
>>"%GEN%\hk\busnow\app\Version.java" echo }

rem --- compile ----------------------------------------------------------------
echo ==^> javac
if exist "%BUILD%\sources.txt" del "%BUILD%\sources.txt"
for /r "%ROOT%\src" %%f in (*.java) do (
  set "P=%%f"
  echo "!P:\=/!">>"%BUILD%\sources.txt"
)
for /r "%GEN%" %%f in (*.java) do (
  set "P=%%f"
  echo "!P:\=/!">>"%BUILD%\sources.txt"
)
"%JAVAC%" -encoding UTF-8 -source 8 -target 8 -bootclasspath "%PLAT%" -classpath "%PLAT%" ^
  -d "%CLS%" -nowarn -Xlint:none "@%BUILD%\sources.txt" > "%LOG%" 2>&1
if errorlevel 1 (type "%LOG%" & echo [fail] javac & exit /b 1)

rem --- dex --------------------------------------------------------------------
echo ==^> d8
if exist "%BUILD%\classes.txt" del "%BUILD%\classes.txt"
for /r "%CLS%" %%f in (*.class) do (
  set "P=%%f"
  echo !P:\=/!>>"%BUILD%\classes.txt"
)
call "%D8%" --release --min-api 21 --lib "%PLAT%" --output "%DEX%" "@%BUILD%\classes.txt" > "%LOG%" 2>&1
if errorlevel 1 (type "%LOG%" & echo [fail] d8 & exit /b 1)
if not exist "%DEX%\classes.dex" (echo [fail] classes.dex not produced & exit /b 1)

rem --- pack -------------------------------------------------------------------
echo ==^> pack
node "%ROOT%\tools\pack.js" "%BUILD%\base.apk" "%DEX%\classes.dex" "%BUILD%\unsigned.apk"
if errorlevel 1 (echo [fail] pack & exit /b 1)

echo ==^> zipalign check
"%ZIPALIGN%" -c -p -v 4 "%BUILD%\unsigned.apk" > "%LOG%" 2>&1
if errorlevel 1 (type "%LOG%" & echo [fail] zipalign & exit /b 1)

rem --- sign -------------------------------------------------------------------
echo ==^> sign
if not exist "%KS%" (
  "%KEYTOOL%" -genkeypair -keystore "%KS%" -alias busnow -keyalg RSA -keysize 2048 ^
    -validity 10950 -storepass %KSPASS% -keypass %KSPASS% ^
    -dname "CN=bus NOW, OU=hk.busnow, O=busnow, L=Hong Kong, C=HK" > "%LOG%" 2>&1
  if errorlevel 1 (type "%LOG%" & echo [fail] keytool & exit /b 1)
)
call "%APKSIGNER%" sign --ks "%KS%" --ks-key-alias busnow ^
  --ks-pass pass:%KSPASS% --key-pass pass:%KSPASS% ^
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true ^
  --out "%APK%" "%BUILD%\unsigned.apk" > "%LOG%" 2>&1
if errorlevel 1 (type "%LOG%" & echo [fail] apksigner & exit /b 1)

call "%APKSIGNER%" verify --print-certs "%APK%" > "%BUILD%\verify.txt" 2>&1
if errorlevel 1 (type "%BUILD%\verify.txt" & echo [fail] signature verify & exit /b 1)

rem --- static verification + size gate --------------------------------------
echo ==^> verify
"%AAPT2%" dump badging "%APK%" > "%BUILD%\badging.txt" 2>&1
findstr /c:"package:" /c:"application-label:" /c:"sdkVersion" /c:"targetSdkVersion" /c:"launchable-activity" "%BUILD%\badging.txt"

node "%ROOT%\tools\verify-apk.js" "%APK%" --require "Lhk/busnow/app/MainActivity;"
if errorlevel 1 exit /b 1

for %%A in ("%APK%") do set "SIZE=%%~zA"
set /a SIZEKB=%SIZE%/1024
echo.
echo output: %APK%
echo size:   %SIZE% bytes / %SIZEKB% KB
if %SIZE% GTR 819200 (
  echo [fail] APK is larger than the 800 KB budget
  exit /b 1
)
echo.
echo [busNOW] build ok
endlocal
