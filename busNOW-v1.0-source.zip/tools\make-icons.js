'use strict';
/* Procedural launcher icon (no image assets): glass tile + white bus. Pure JS PNG encoder. */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const t = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(zlib.crc32(Buffer.concat([t, data])) >>> 0, 0);
  return Buffer.concat([len, t, data, crc]);
}

function encodePNG(w, h, rgba) {
  const stride = w * 4;
  const raw = Buffer.alloc((stride + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (stride + 1)] = 0;
    rgba.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const idat = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', idat),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

const lerp = (a, b, t) => a + (b - a) * t;
const clamp01 = (t) => (t < 0 ? 0 : t > 1 ? 1 : t);

function roundRectContains(u, v, x0, x1, y0, y1, r) {
  const cx = Math.min(Math.max(u, x0 + r), x1 - r);
  const cy = Math.min(Math.max(v, y0 + r), y1 - r);
  const dx = u - cx;
  const dy = v - cy;
  return dx * dx + dy * dy <= r * r;
}

function sample(x, y, S) {
  const u = x / S;
  const v = y / S;
  const r = 0.225;
  const cx = Math.min(Math.max(u, r), 1 - r);
  const cy = Math.min(Math.max(v, r), 1 - r);
  const dx = u - cx;
  const dy = v - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);
  if (dist > r) {
    return [0, 0, 0, 0];
  }
  const edge = Math.min(Math.min(u, 1 - u), Math.min(v, 1 - v), r - dist);
  let alpha = 255;
  if (edge < 0.006) {
    alpha = 0;
  } else if (edge < 0.02) {
    alpha = Math.round((255 * (edge - 0.006)) / 0.014);
  }

  // deep indigo -> violet gradient with a teal hint
  const t = clamp01((u + v) / 2);
  let R = lerp(13, 42, t);
  let G = lerp(23, 26, t);
  let B = lerp(74, 108, t);
  const w1 = Math.max(0, 1 - Math.hypot(u - 0.86, v - 0.92) / 0.62);
  R += 34 * w1;
  G += 4 * w1;
  B += 16 * w1;
  const w2 = Math.max(0, 1 - Math.hypot(u - 0.96, v - 0.04) / 0.5) * 0.4;
  G += 44 * w2;
  B += 30 * w2;

  // glass sheen
  const ex = (u - 0.26) / 0.55;
  const ey = (v - 0.12) / 0.42;
  const ep = Math.max(0, 1 - Math.sqrt(ex * ex + ey * ey));
  R = lerp(R, 255, ep * 0.10);
  G = lerp(G, 255, ep * 0.12);
  B = lerp(B, 255, ep * 0.16);

  let col = [R, G, B];

  // bus body
  if (roundRectContains(u, v, 0.155, 0.845, 0.325, 0.665, 0.075)) {
    col = [246, 249, 255];
  }
  // windows
  if (roundRectContains(u, v, 0.21, 0.79, 0.372, 0.487, 0.028)) {
    col = [11, 18, 32];
  }
  if (u >= 0.488 && u <= 0.512 && v >= 0.372 && v <= 0.487) {
    col = [246, 249, 255];
  }
  // skirt line
  if (u >= 0.21 && u <= 0.79 && v >= 0.522 && v <= 0.538) {
    col = [64, 124, 255];
  }
  // wheels
  if (Math.hypot(u - 0.30, v - 0.70) <= 0.062 || Math.hypot(u - 0.70, v - 0.70) <= 0.062) {
    col = [9, 14, 26];
  }
  if (Math.hypot(u - 0.30, v - 0.70) <= 0.024 || Math.hypot(u - 0.70, v - 0.70) <= 0.024) {
    col = [246, 249, 255];
  }
  // headlight
  if (Math.hypot(u - 0.822, v - 0.588) <= 0.018) {
    col = [255, 214, 74];
  }

  return [Math.round(col[0]), Math.round(col[1]), Math.round(col[2]), alpha];
}

function render(size, ss) {
  const S = size * ss;
  const buf = Buffer.alloc(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let r = 0;
      let g = 0;
      let b = 0;
      let a = 0;
      for (let sy = 0; sy < ss; sy++) {
        for (let sx = 0; sx < ss; sx++) {
          const p = sample(x * ss + sx + 0.5, y * ss + sy + 0.5, S);
          const pa = p[3] / 255;
          r += p[0] * pa;
          g += p[1] * pa;
          b += p[2] * pa;
          a += pa;
        }
      }
      const n = ss * ss;
      const i = (y * size + x) * 4;
      if (a > 0) {
        buf[i] = Math.round(r / a);
        buf[i + 1] = Math.round(g / a);
        buf[i + 2] = Math.round(b / a);
        buf[i + 3] = Math.round((a / n) * 255);
      }
    }
  }
  return encodePNG(size, size, buf);
}

const root = path.resolve(__dirname, '..');
const targets = [
  ['mipmap-mdpi', 48],
  ['mipmap-hdpi', 72],
  ['mipmap-xhdpi', 96],
  ['mipmap-xxhdpi', 144],
  ['mipmap-xxxhdpi', 192],
];

const ss = 3;
let bytes = 0;
for (const [dir, size] of targets) {
  const outDir = path.join(root, 'res', dir);
  fs.mkdirSync(outDir, { recursive: true });
  const png = render(size, ss);
  fs.writeFileSync(path.join(outDir, 'ic_launcher.png'), png);
  bytes += png.length;
}
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist', 'icon-preview.png'), render(192, ss));
console.log('icons done, total ' + (bytes / 1024).toFixed(1) + ' KB');
