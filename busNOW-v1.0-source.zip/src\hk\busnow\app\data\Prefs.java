package hk.busnow.app.data;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

/** User settings plus a couple of self-diagnostics. One tiny SharedPreferences file. */
public final class Prefs {

    private static final String FILE = "busnow";
    private static final String K_LANG = "lang";          // -1 system, 0 tc, 1 sc, 2 en
    private static final String K_THEME = "theme";        // -1 system, 0 light, 1 dark
    private static final String K_FX = "fx";              // 0 auto, 1 on, 2 off
    private static final String K_INTERVAL = "interval";  // seconds
    private static final String K_COLD = "coldStartMs";

    private Prefs() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static int lang(Context c) {
        return sp(c).getInt(K_LANG, -1);
    }

    public static void setLang(Context c, int v) {
        sp(c).edit().putInt(K_LANG, v).apply();
    }

    public static int theme(Context c) {
        return sp(c).getInt(K_THEME, -1);
    }

    public static void setTheme(Context c, int v) {
        sp(c).edit().putInt(K_THEME, v).apply();
    }

    public static int fx(Context c) {
        return sp(c).getInt(K_FX, 0);
    }

    public static void setFx(Context c, int v) {
        sp(c).edit().putInt(K_FX, v).apply();
    }

    public static int interval(Context c) {
        return sp(c).getInt(K_INTERVAL, 15);
    }

    public static void setInterval(Context c, int seconds) {
        sp(c).edit().putInt(K_INTERVAL, seconds).apply();
    }

    public static long coldStartMs(Context c) {
        return sp(c).getLong(K_COLD, 0L);
    }

    public static void setColdStartMs(Context c, long ms) {
        sp(c).edit().putLong(K_COLD, ms).apply();
    }

    /** Honours the user choice, otherwise decides from the device class. */
    public static boolean animationsEnabled(Context c) {
        int mode = fx(c);
        if (mode == 1) {
            return true;
        }
        if (mode == 2) {
            return false;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return false;
        }
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null && am.isLowRamDevice()) {
            return false;
        }
        return Runtime.getRuntime().availableProcessors() >= 4;
    }
}
