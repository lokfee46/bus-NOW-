#!/usr/bin/env bash
# Desktop self-test for the pure-Java core. Mirrors tools/selftest.cmd.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

: "${JAVA_HOME:?set JAVA_HOME to a JDK 17+}"
SRC="$ROOT/src/hk/busnow/app"
OUT="$ROOT/build/selftest"

rm -rf "$OUT"
mkdir -p "$OUT"

"$JAVA_HOME/bin/javac" -encoding UTF-8 -nowarn -d "$OUT" \
  "$SRC/data/SeedFormat.java" \
  "$SRC/util/Json.java" \
  "$SRC/util/TimeUtil.java" \
  "$SRC/util/Clock.java" \
  "$SRC/net/Http.java" \
  "$SRC/net/KmbApi.java" \
  "$SRC/net/CtbApi.java" \
  "$SRC/model/Eta.java" \
  "$SRC/model/Arrivals.java" \
  "$ROOT/tools/selftest/SelfTest.java"

"$JAVA_HOME/bin/java" -cp "$OUT" SelfTest "$ROOT"
