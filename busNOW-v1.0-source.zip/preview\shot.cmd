@echo off
rem Regenerate dist\ui-preview.png from preview\preview.html with headless Chrome.
setlocal
set "ROOT=%~dp0.."
set "CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not exist "%CHROME%" (echo no Chrome/Edge found & exit /b 1)

node "%ROOT%\preview\build-preview.js" || exit /b 1
if not exist "%ROOT%\dist" mkdir "%ROOT%\dist"
"%CHROME%" --headless=new --disable-gpu --hide-scrollbars --force-device-scale-factor=2 ^
  --window-size=1176,1128 --user-data-dir="%ROOT%\build\chrome" ^
  --screenshot="%ROOT%\dist\ui-preview.png" ^
  "file:///%ROOT:\=/%/preview/preview.html"
if errorlevel 1 (echo chrome screenshot failed & exit /b 1)
echo done: %ROOT%\dist\ui-preview.png
endlocal
