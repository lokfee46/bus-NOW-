package hk.busnow.app;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Style;
import hk.busnow.app.ui.Ui;

/** Stops sorted by distance from the device. Location is optional: search always works. */
public class NearbyActivity extends SeedActivity {

    private static final int REQ_LOCATION = 71;
    private static final int NEARBY_LIMIT = 15;

    private final Handler main = new Handler(Looper.getMainLooper());
    private SeedFormat seed;
    private int lang;
    private ListView list;
    private LinearLayout card;
    private TextView cardText;
    private TextView cardAction;
    private NearbyRow adapter;
    private Location pending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby);
        Ui.edgeToEdge(this, findViewById(R.id.content));
        lang = L.lang(this);
        list = (ListView) findViewById(R.id.stops);
        list.setDivider(null);
        list.setSelector(android.R.color.transparent);
        list.setCacheColorHint(0);
        card = (LinearLayout) findViewById(R.id.card);
        cardText = (TextView) findViewById(R.id.cardText);
        cardAction = (TextView) findViewById(R.id.cardAction);

        View back = findViewById(R.id.back);
        Style.iconButton(back, getResources().getColor(R.color.ink2));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        cardAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasPermission()) {
                    locate();
                } else {
                    requestPermission();
                }
            }
        });
        if (hasPermission()) {
            locate();
        } else {
            requestPermission();
        }
    }

    @Override
    protected void onSeedReady(SeedFormat seed) {
        this.seed = seed;
        if (pending != null) {
            applyLocation(pending);
        }
    }

    private boolean hasPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                locate();
            } else {
                showDenied();
            }
        }
    }

    private void showCard(int textRes, int actionRes) {
        cardText.setText(textRes);
        cardAction.setText(actionRes);
        card.setVisibility(View.VISIBLE);
        list.setVisibility(View.GONE);
    }

    private void showDenied() {
        showCard(R.string.nearby_denied, R.string.open_settings);
        cardAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                try {
                    startActivity(i);
                } catch (RuntimeException ignored) {
                    // no settings app on this device
                }
            }
        });
    }

    private void locate() {
        showCard(R.string.nearby_locating, R.string.retry);
        final LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) {
            showCard(R.string.nearby_timeout, R.string.retry);
            return;
        }
        Location best = null;
        String[] providers = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER,
                LocationManager.PASSIVE_PROVIDER};
        for (String p : providers) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) {
                    best = l;
                }
            } catch (SecurityException ignored) {
                // permission revoked between check and call
            } catch (IllegalArgumentException ignored) {
                // provider not present
            }
        }
        if (best != null && System.currentTimeMillis() - best.getTime() < 10 * 60 * 1000L) {
            applyLocation(best);
            return;
        }

        final boolean[] delivered = {false};
        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (!delivered[0]) {
                    delivered[0] = true;
                    applyLocation(location);
                }
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };
        boolean asked = false;
        for (String p : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER}) {
            try {
                lm.requestSingleUpdate(p, listener, Looper.getMainLooper());
                asked = true;
            } catch (SecurityException ignored) {
                // handled by the timeout below
            } catch (IllegalArgumentException ignored) {
                // provider missing
            }
        }
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!delivered[0]) {
                    showCard(R.string.nearby_timeout, R.string.retry);
                }
            }
        }, asked ? 9000L : 200L);
    }

    private void applyLocation(Location l) {
        pending = l;
        if (seed == null) {
            return;
        }
        final double lat = l.getLatitude();
        final double lon = l.getLongitude();
        adapter = new NearbyRow(this, seed, lang, lat, lon);
        adapter.setData(seed.nearby(lat, lon, NEARBY_LIMIT));
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                StopActivity.start(NearbyActivity.this, adapter.stopAt(position));
            }
        });
        card.setVisibility(View.GONE);
        list.setVisibility(View.VISIBLE);
    }
}
