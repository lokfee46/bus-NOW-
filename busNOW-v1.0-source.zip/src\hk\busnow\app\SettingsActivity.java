package hk.busnow.app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.Calendar;
import java.util.TimeZone;

import hk.busnow.app.data.Prefs;
import hk.busnow.app.data.Seed;
import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.ui.GlassCard;
import hk.busnow.app.ui.Style;
import hk.busnow.app.ui.Ui;
import hk.busnow.app.util.Clock;

/** Settings, data attribution and the self-diagnostics that back the performance claims. */
public class SettingsActivity extends BaseActivity {

    private interface Picked {
        void onPick(int value);
    }

    private LinearLayout sections;
    private int ink;
    private int ink2;
    private int ink3;
    private int accent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Ui.edgeToEdge(this, findViewById(R.id.content));
        sections = (LinearLayout) findViewById(R.id.sections);
        ink = getResources().getColor(R.color.ink);
        ink2 = getResources().getColor(R.color.ink2);
        ink3 = getResources().getColor(R.color.ink3);
        accent = getResources().getColor(R.color.accent);

        View back = findViewById(R.id.back);
        Style.iconButton(back, ink2);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Seed.preload(this);
        build();
    }

    private void build() {
        sections.removeAllViews();
        addChoice(R.string.settings_language,
                new String[]{getString(R.string.lang_system), getString(R.string.lang_tc),
                        getString(R.string.lang_sc), getString(R.string.lang_en)},
                new int[]{-1, 0, 1, 2}, Prefs.lang(this), new Picked() {
                    @Override
                    public void onPick(int value) {
                        Prefs.setLang(SettingsActivity.this, value);
                        recreate();
                    }
                });
        addChoice(R.string.settings_theme,
                new String[]{getString(R.string.theme_system), getString(R.string.theme_light),
                        getString(R.string.theme_dark)},
                new int[]{-1, 0, 1}, Prefs.theme(this), new Picked() {
                    @Override
                    public void onPick(int value) {
                        Prefs.setTheme(SettingsActivity.this, value);
                        recreate();
                    }
                });
        addChoice(R.string.settings_fx,
                new String[]{getString(R.string.fx_auto), getString(R.string.fx_on),
                        getString(R.string.fx_off)},
                new int[]{0, 1, 2}, Prefs.fx(this), new Picked() {
                    @Override
                    public void onPick(int value) {
                        Prefs.setFx(SettingsActivity.this, value);
                        build();
                    }
                });
        addChoice(R.string.settings_refresh,
                new String[]{getString(R.string.every_seconds, 10), getString(R.string.every_seconds, 15),
                        getString(R.string.every_seconds, 30), getString(R.string.every_seconds, 60)},
                new int[]{10, 15, 30, 60}, Prefs.interval(this), new Picked() {
                    @Override
                    public void onPick(int value) {
                        Prefs.setInterval(SettingsActivity.this, value);
                        build();
                    }
                });
        addInfo(dataText());
        addInfo(aboutText());
    }

    private String dataText() {
        SeedFormat s = Seed.peek();
        String date = s == null ? "—" : date(s.generatedAt * 1000L);
        return getString(R.string.settings_data_date, date) + "\n"
                + getString(R.string.settings_attribution);
    }

    private String aboutText() {
        StringBuilder sb = new StringBuilder(220);
        sb.append(getString(R.string.settings_version, Version.NAME, Version.CODE));
        long cold = Prefs.coldStartMs(this);
        if (cold > 0) {
            sb.append('\n').append(getString(R.string.settings_cold_start, cold));
        }
        sb.append('\n').append(getString(R.string.settings_apk_size, apkSize()));
        long offset = Math.abs(Clock.offset()) / 1000L;
        sb.append('\n').append(getString(R.string.settings_server_time, (int) offset));
        sb.append('\n').append(getString(R.string.settings_licence));
        return sb.toString();
    }

    private String apkSize() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            long bytes = new File(pi.applicationInfo.sourceDir).length();
            if (bytes >= 1024L * 1024L) {
                return String.format(java.util.Locale.US, "%.2f MB", bytes / 1048576.0);
            }
            return (bytes / 1024L) + " KB";
        } catch (PackageManager.NameNotFoundException e) {
            return "—";
        }
    }

    private static String date(long ms) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
        c.setTimeInMillis(ms);
        StringBuilder sb = new StringBuilder(10);
        sb.append(c.get(Calendar.YEAR)).append('-');
        int m = c.get(Calendar.MONTH) + 1;
        if (m < 10) {
            sb.append('0');
        }
        sb.append(m).append('-');
        int d = c.get(Calendar.DAY_OF_MONTH);
        if (d < 10) {
            sb.append('0');
        }
        sb.append(d);
        return sb.toString();
    }

    private String labelFor(String[] labels, int[] values, int current) {
        for (int i = 0; i < values.length && i < labels.length; i++) {
            if (values[i] == current) {
                return labels[i];
            }
        }
        return "";
    }

    private void addChoice(int titleRes, final String[] labels, final int[] values,
                           final int current, final Picked picked) {
        GlassCard card = new GlassCard(this);
        card.setRadius(16);
        card.setClickable(true);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dpi(this, 16), Ui.dpi(this, 14), Ui.dpi(this, 12), Ui.dpi(this, 14));

        TextView title = new TextView(this);
        title.setText(titleRes);
        title.setTextSize(14f);
        title.setTypeface(Ui.medium());
        title.setTextColor(ink);
        row.addView(title, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView value = new TextView(this);
        value.setText(labelFor(labels, values, current));
        value.setTextSize(12.5f);
        value.setTextColor(accent);
        row.addView(value);

        ImageView chevron = new ImageView(this);
        chevron.setImageResource(R.drawable.ic_chevron);
        chevron.setColorFilter(ink3);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                Ui.dpi(this, 16), Ui.dpi(this, 16));
        clp.leftMargin = Ui.dpi(this, 6);
        row.addView(chevron, clp);

        card.addView(row);
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index = 0;
                for (int i = 0; i < values.length; i++) {
                    if (values[i] == current) {
                        index = i;
                    }
                }
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle(titleRes)
                        .setSingleChoiceItems(labels, index, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                picked.onPick(values[which]);
                            }
                        })
                        .show();
            }
        });
        addCard(card);
    }

    private void addInfo(CharSequence text) {
        GlassCard card = new GlassCard(this);
        card.setRadius(16);
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(12f);
        t.setTextColor(ink2);
        t.setLineSpacing(Ui.dp(this, 2), 1f);
        int pad = Ui.dpi(this, 16);
        t.setPadding(pad, pad, pad, pad);
        card.addView(t);
        addCard(card);
    }

    private void addCard(View card) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dpi(this, 10);
        card.setLayoutParams(lp);
        sections.addView(card);
    }
}
