package hk.busnow.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import hk.busnow.app.data.Seed;
import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Segmented;
import hk.busnow.app.ui.Style;
import hk.busnow.app.ui.Ui;

/** Route/stop search over the bundled index. Everything is a binary search or a linear scan of
 *  primitive arrays, so results are ready well before the keyboard finishes animating in. */
public class SearchActivity extends BaseActivity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "busnow-search");
            t.setDaemon(true);
            return t;
        }
    });

    private EditText field;
    private Segmented seg;
    private SearchRow adapter;
    private TextView hint;
    private int lang;
    private int searchSeq;
    private int seedWaits;

    private final Runnable pendingSearch = new Runnable() {
        @Override
        public void run() {
            runSearch(field.getText().toString());
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Ui.edgeToEdge(this, findViewById(R.id.content));
        lang = L.lang(this);
        Seed.preload(this);

        View back = findViewById(R.id.back);
        Style.iconButton(back, getResources().getColor(R.color.ink2));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        field = (EditText) findViewById(R.id.q);
        field.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                main.removeCallbacks(pendingSearch);
                main.postDelayed(pendingSearch, 120L);
            }
        });
        field.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    main.removeCallbacks(pendingSearch);
                    runSearch(field.getText().toString());
                    hideKeyboard();
                    return true;
                }
                return false;
            }
        });

        seg = (Segmented) findViewById(R.id.seg);
        seg.setLabels(new String[]{getString(R.string.tab_routes), getString(R.string.tab_stops)});
        seg.setOnChange(new Segmented.OnChange() {
            @Override
            public void onChange(int index) {
                runSearch(field.getText().toString());
            }
        });

        hint = (TextView) findViewById(R.id.hint);
        hint.setText(R.string.search_empty_hint);

        ListView results = (ListView) findViewById(R.id.results);
        results.setDivider(null);
        results.setSelector(android.R.color.transparent);
        results.setCacheColorHint(0);
        adapter = new SearchRow(this, Seed.peek(), lang);
        results.setAdapter(adapter);
        results.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (adapter.mode() == SearchRow.MODE_ROUTE) {
                    RouteActivity.start(SearchActivity.this, adapter.routeAt(position));
                } else {
                    StopActivity.start(SearchActivity.this, adapter.stopAt(position));
                }
            }
        });

        field.requestFocus();
        field.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT);
                }
            }
        }, 120L);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(field.getWindowToken(), 0);
        }
    }

    private void runSearch(String query) {
        if (isFinishing() || io.isShutdown()) {
            return;
        }
        final String text = query == null ? "" : query.trim();
        if (text.length() == 0) {
            adapter.setData(seg.selected(), new int[0], new int[0]);
            hint.setText(R.string.search_empty_hint);
            hint.setVisibility(View.VISIBLE);
            return;
        }
        final SeedFormat seed = Seed.peek();
        if (seed == null) {
            hint.setText(R.string.loading_seed);
            hint.setVisibility(View.VISIBLE);
            waitForSeed(text);
            return;
        }
        if (adapter.seed() != seed) {
            adapter = new SearchRow(this, seed, lang);
            ((ListView) findViewById(R.id.results)).setAdapter(adapter);
        }
        final int mode = seg.selected();
        final int mySeq = ++searchSeq;
        try {
            io.execute(new Runnable() {
                @Override
                public void run() {
                    final int[] routes = mode == SearchRow.MODE_ROUTE ? seed.searchRoutes(text, 40) : new int[0];
                    final int[] stops = mode == SearchRow.MODE_STOP ? seed.searchStops(text, 40) : new int[0];
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            if (mySeq != searchSeq || isFinishing()) {
                                return;
                            }
                            adapter.setData(mode, routes, stops);
                            int count = routes.length + stops.length;
                            if (count == 0) {
                                hint.setText(R.string.no_results);
                                hint.setVisibility(View.VISIBLE);
                            } else {
                                hint.setVisibility(View.GONE);
                            }
                        }
                    });
                }
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) {
            // screen is going away
        }
    }

    private void waitForSeed(final String text) {
        if (seedWaits++ > 60) {
            hint.setText(R.string.seed_missing);
            return;
        }
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }
                if (Seed.peek() != null) {
                    seedWaits = 0;
                    runSearch(text);
                } else {
                    waitForSeed(text);
                }
            }
        }, 150L);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }

    public static void open(Context c) {
        c.startActivity(new Intent(c, SearchActivity.class));
    }
}
