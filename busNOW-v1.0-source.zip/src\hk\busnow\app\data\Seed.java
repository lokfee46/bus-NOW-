package hk.busnow.app.data;

import android.content.Context;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/** Loads the bundled offline index once, off the main thread. */
public final class Seed {

    private static final String TAG = "busNOW";
    private static volatile SeedFormat value;
    private static volatile String error;
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "seed-loader");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1);
            return t;
        }
    });

    private Seed() {
    }

    public static void preload(final Context c) {
        if (value != null) {
            return;
        }
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    get(c);
                } catch (IOException e) {
                    error = e.getMessage();
                    Log.w(TAG, "seed load failed: " + e.getMessage());
                }
            }
        });
    }

    public static SeedFormat get(Context c) throws IOException {
        SeedFormat local = value;
        if (local != null) {
            return local;
        }
        synchronized (Seed.class) {
            if (value == null) {
                long t0 = System.currentTimeMillis();
                value = read(c);
                Log.i(TAG, "seed loaded in " + (System.currentTimeMillis() - t0) + " ms: "
                        + value.stopCount + " stops, " + value.routeCount + " routes");
            }
            return value;
        }
    }

    public static SeedFormat peek() {
        return value;
    }

    public static String lastError() {
        return error;
    }

    private static SeedFormat read(Context c) throws IOException {
        InputStream in = null;
        try {
            in = c.getAssets().open("seed.bin.gz");
            java.util.zip.GZIPInputStream gz = new java.util.zip.GZIPInputStream(in, 32768);
            ByteArrayOutputStream bos = new ByteArrayOutputStream(640 * 1024);
            byte[] buf = new byte[32768];
            int n;
            while ((n = gz.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            gz.close();
            return SeedFormat.parse(bos.toByteArray());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignored) {
                    // ignore
                }
            }
        }
    }
}
