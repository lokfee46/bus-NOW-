'use strict';
/*
 * Static verifier for the built APK. There is no device on the build machine, so this is the
 * closest thing to an install test:
 *   - walks the zip central directory, inflates every entry and checks its CRC
 *   - asserts resources.arsc is STORED and 4-byte aligned (targetSdk 30+ requirement)
 *   - parses classes.dex and asserts the entry-point classes really are in it
 *   - checks the bundled seed asset (gzip magic) if present
 *   - prints the size ledger
 *
 * usage: node verify-apk.js <apk> [--require Lhk/busnow/app/MainActivity;]
 */
const fs = require('fs');
const zlib = require('zlib');

function fail(msg) {
  console.error('verify: FAIL ' + msg);
  process.exit(1);
}

const args = process.argv.slice(2);
const apk = args[0];
if (!apk) {
  fail('usage: node verify-apk.js <apk> [--require <dex-string>]');
}
const required = ['Lhk/busnow/app/MainActivity;'];
for (let i = 1; i < args.length; i++) {
  if (args[i] === '--require' && args[i + 1]) {
    required.push(args[++i]);
  }
}

const buf = fs.readFileSync(apk);

let eocd = -1;
for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65536); i--) {
  if (buf.readUInt32LE(i) === 0x06054b50) {
    eocd = i;
    break;
  }
}
if (eocd < 0) {
  fail('EOCD not found');
}
const total = buf.readUInt16LE(eocd + 10);
const cdOff = buf.readUInt32LE(eocd + 16);

const entries = [];
let p = cdOff;
for (let i = 0; i < total; i++) {
  if (buf.readUInt32LE(p) !== 0x02014b50) {
    fail('bad central directory at ' + p);
  }
  const method = buf.readUInt16LE(p + 10);
  const crc = buf.readUInt32LE(p + 16);
  const csize = buf.readUInt32LE(p + 20);
  const usize = buf.readUInt32LE(p + 24);
  const nameLen = buf.readUInt16LE(p + 28);
  const extraLen = buf.readUInt16LE(p + 30);
  const cmtLen = buf.readUInt16LE(p + 32);
  const localOff = buf.readUInt32LE(p + 42);
  const name = buf.toString('utf8', p + 46, p + 46 + nameLen);
  if (buf.readUInt32LE(localOff) !== 0x04034b50) {
    fail('bad local header for ' + name);
  }
  const lNameLen = buf.readUInt16LE(localOff + 26);
  const lExtraLen = buf.readUInt16LE(localOff + 28);
  const dataOff = localOff + 30 + lNameLen + lExtraLen;
  const raw = buf.subarray(dataOff, dataOff + csize);
  let data;
  if (method === 0) {
    data = raw;
  } else if (method === 8) {
    data = zlib.inflateRawSync(raw);
  } else {
    fail('unsupported method ' + method + ' for ' + name);
  }
  if (data.length !== usize) {
    fail('size mismatch for ' + name + ': ' + data.length + ' != ' + usize);
  }
  const got = zlib.crc32(data) >>> 0;
  if (got !== crc) {
    fail('CRC mismatch for ' + name);
  }
  entries.push({ name, method, crc, csize, usize, dataOff, data });
  p += 46 + nameLen + extraLen + cmtLen;
}

const byName = new Map(entries.map((e) => [e.name, e]));
if (!byName.has('AndroidManifest.xml')) {
  fail('AndroidManifest.xml missing');
}
if (!byName.has('classes.dex')) {
  fail('classes.dex missing');
}
const arsc = byName.get('resources.arsc');
if (!arsc) {
  fail('resources.arsc missing');
}
if (arsc.method !== 0) {
  fail('resources.arsc must be stored (uncompressed), got method ' + arsc.method);
}
if (arsc.dataOff % 4 !== 0) {
  fail('resources.arsc is not 4-byte aligned (offset ' + arsc.dataOff + ')');
}

// --- dex string table ---
function dexStrings(d) {
  if (d.readUInt32BE(0) !== 0x6465780a) {
    fail('classes.dex has a bad magic');
  }
  const size = d.readUInt32LE(0x38);
  const off = d.readUInt32LE(0x3c);
  const out = new Set();
  for (let i = 0; i < size; i++) {
    let so = d.readUInt32LE(off + i * 4);
    let p = so;
    while (d[p] & 0x80) {
      p++;
    }
    p++; // utf16 length (uleb128, 1-2 bytes is all we need for class names)
    let e = p;
    while (d[e] !== 0) {
      e++;
    }
    out.add(d.toString('utf8', p, e));
  }
  return out;
}

const dex = byName.get('classes.dex').data;
const strings = dexStrings(dex);
const missing = required.filter((r) => !strings.has(r));
if (missing.length) {
  fail('dex is missing required strings: ' + missing.join(', '));
}

// --- bundled seed ---
let seedInfo = 'none';
const seed = byName.get('assets/seed.bin.gz');
if (seed) {
  let raw;
  try {
    raw = zlib.gunzipSync(seed.data);
  } catch (e) {
    fail('assets/seed.bin.gz is not valid gzip: ' + e.message);
  }
  if (raw.slice(0, 4).toString('ascii') !== 'BNOW') {
    fail('seed magic is not BNOW');
  }
  seedInfo = (seed.usize / 1024).toFixed(0) + ' KB gz -> ' + (raw.length / 1024).toFixed(0) + ' KB raw';
} else {
  console.log('verify: WARN assets/seed.bin.gz not bundled (search will need the network)');
}

const size = (n) => (n / 1024).toFixed(1) + ' KB';
const rows = entries.slice().sort((a, b) => b.usize - a.usize).slice(0, 8);
console.log('verify: ' + entries.length + ' zip entries, all CRC ok');
console.log('verify: dex ' + size(dex.length) + ', resources.arsc ' + size(arsc.usize) +
  ' (stored, aligned @' + arsc.dataOff + '), seed ' + seedInfo);
console.log('verify: largest entries');
for (const r of rows) {
  console.log('  ' + r.name.padEnd(34) + size(r.usize).padStart(9) + '  -> ' + size(r.csize).padStart(9));
}
console.log('verify: APK ' + size(buf.length) + ' (' + buf.length + ' bytes)');
console.log('verify: PASS');
