package hk.busnow.app.util;

/** Hong Kong time helpers. Fixed UTC+8 (no DST), no Calendar / TimeZone / java.time allocations. */
public final class TimeUtil {

    private static final long HKT = 8L * 3600L * 1000L;
    public static final long MINUTE = 60000L;

    private TimeUtil() {
    }

    /**
     * Parses an ISO-8601 timestamp from the bus APIs, e.g. {@code 2026-11-01T08:50:00+08:00},
     * {@code 2026-11-01T08:50:00.123+08:00} or with a trailing {@code Z}. Returns 0 on failure.
     */
    public static long parseIso(String s) {
        if (s == null || s.length() < 19) {
            return 0L;
        }
        try {
            int year = num(s, 0, 4);
            int month = num(s, 5, 2);
            int day = num(s, 8, 2);
            int hour = num(s, 11, 2);
            int minute = num(s, 14, 2);
            int second = num(s, 17, 2);
            int tzMinutes = 0;
            long fractionMs = 0;
            int i = 19;
            if (i < s.length() && s.charAt(i) == '.') {
                i++;
                int digits = 0;
                long frac = 0;
                while (i < s.length() && Character.isDigit(s.charAt(i))) {
                    if (digits < 3) {
                        frac = frac * 10 + (s.charAt(i) - '0');
                        digits++;
                    }
                    i++;
                }
                while (digits < 3) {
                    frac *= 10;
                    digits++;
                }
                fractionMs = frac;
            }
            if (i < s.length() && (s.charAt(i) == 'Z' || s.charAt(i) == 'z')) {
                tzMinutes = 0;
            } else if (i + 5 < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) {
                int sign = s.charAt(i) == '+' ? 1 : -1;
                tzMinutes = sign * (num(s, i + 1, 2) * 60 + num(s, i + 4, 2));
            }
            long days = daysFromCivil(year, month, day);
            long secs = days * 86400L + hour * 3600L + minute * 60L + second - tzMinutes * 60L;
            return secs * 1000L + fractionMs;
        } catch (RuntimeException e) {
            return 0L;
        }
    }

    private static int num(String s, int at, int len) {
        int v = 0;
        for (int i = at; i < at + len; i++) {
            char c = s.charAt(i);
            if (c < '0' || c > '9') {
                throw new IllegalArgumentException("bad digit");
            }
            v = v * 10 + (c - '0');
        }
        return v;
    }

    /** Days since 1970-01-01 for a proleptic Gregorian date (Howard Hinnant's algorithm). */
    static long daysFromCivil(int y, int m, int d) {
        y -= m <= 2 ? 1 : 0;
        long era = (y >= 0 ? y : y - 399) / 400;
        int yoe = (int) (y - era * 400);
        int doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
        int doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
        return era * 146097 + doe - 719468;
    }

    /** Local HH:mm for an absolute timestamp. */
    public static String hhmm(long ms) {
        int sod = secondOfDay(ms);
        StringBuilder sb = new StringBuilder(5);
        two(sb, sod / 3600);
        sb.append(':');
        two(sb, (sod / 60) % 60);
        return sb.toString();
    }

    /** Local HH:mm:ss for an absolute timestamp. */
    public static String hhmmss(long ms) {
        int sod = secondOfDay(ms);
        StringBuilder sb = new StringBuilder(8);
        two(sb, sod / 3600);
        sb.append(':');
        two(sb, (sod / 60) % 60);
        sb.append(':');
        two(sb, sod % 60);
        return sb.toString();
    }

    public static int secondOfDay(long ms) {
        long local = ms + HKT;
        long secs = local / 1000L;
        if (local < 0 && local % 1000L != 0) {
            secs--;
        }
        return (int) (((secs % 86400L) + 86400L) % 86400L);
    }

    private static void two(StringBuilder sb, int v) {
        if (v < 10) {
            sb.append('0');
        }
        sb.append(v);
    }

    /** Whole minutes until [etaMs], rounded up: 2m01s -> 3, 0m30s -> 1, past -> 0. */
    public static int minutesUntil(long etaMs, long nowMs) {
        long ms = etaMs - nowMs;
        if (ms <= 0) {
            return 0;
        }
        return (int) ((ms + 59999L) / 60000L);
    }

    /** Days between two timestamps, used for "today/next day" labels. */
    public static int dayOffset(long a, long b) {
        long da = (a + HKT) / 86400000L;
        long db = (b + HKT) / 86400000L;
        return (int) (db - da);
    }
}
