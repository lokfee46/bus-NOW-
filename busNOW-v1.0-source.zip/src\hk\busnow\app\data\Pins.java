package hk.busnow.app.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import hk.busnow.app.model.Pin;

/** Pinned arrivals, stored as one small JSON string in SharedPreferences. */
public final class Pins {

    private static final String PREFS = "busnow";
    private static final String KEY = "pins";

    private Pins() {
    }

    public static List<Pin> load(Context c) {
        List<Pin> out = new ArrayList<Pin>();
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY, null);
        if (raw == null || raw.length() == 0) {
            return out;
        }
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Pin p = new Pin();
                p.op = o.optInt("op");
                p.route = o.optString("route");
                p.bound = o.optInt("bound");
                p.svc = o.optInt("svc");
                p.stopKey = o.optLong("stopKey");
                p.stopId = o.optString("stopId");
                p.stopIdx = o.optInt("stopIdx", -1);
                p.stopTc = o.optString("stopTc");
                p.stopSc = o.optString("stopSc");
                p.stopEn = o.optString("stopEn");
                p.destTc = o.optString("destTc");
                p.destSc = o.optString("destSc");
                p.destEn = o.optString("destEn");
                p.addedAt = o.optLong("addedAt");
                out.add(p);
            }
        } catch (JSONException e) {
            out.clear();
        }
        return out;
    }

    public static void save(Context c, List<Pin> pins) {
        JSONArray arr = new JSONArray();
        for (Pin p : pins) {
            JSONObject o = new JSONObject();
            try {
                o.put("op", p.op);
                o.put("route", p.route);
                o.put("bound", p.bound);
                o.put("svc", p.svc);
                o.put("stopKey", p.stopKey);
                o.put("stopId", p.stopId);
                o.put("stopIdx", p.stopIdx);
                o.put("stopTc", p.stopTc);
                o.put("stopSc", p.stopSc);
                o.put("stopEn", p.stopEn);
                o.put("destTc", p.destTc);
                o.put("destSc", p.destSc);
                o.put("destEn", p.destEn);
                o.put("addedAt", p.addedAt);
            } catch (JSONException ignored) {
                // strings only, cannot fail
            }
            arr.put(o);
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply();
    }

    /** Returns false when the pin already exists. */
    public static boolean add(List<Pin> pins, Pin pin) {
        String key = pin.key();
        for (Pin p : pins) {
            if (p.key().equals(key)) {
                return false;
            }
        }
        pins.add(pin);
        return true;
    }

    public static boolean remove(List<Pin> pins, String key) {
        for (int i = 0; i < pins.size(); i++) {
            if (pins.get(i).key().equals(key)) {
                pins.remove(i);
                return true;
            }
        }
        return false;
    }

    public static Pin findByKey(List<Pin> pins, String key) {
        for (Pin p : pins) {
            if (p.key().equals(key)) {
                return p;
            }
        }
        return null;
    }
}
