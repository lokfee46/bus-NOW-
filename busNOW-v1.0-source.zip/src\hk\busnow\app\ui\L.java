package hk.busnow.app.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

import java.util.Locale;

import hk.busnow.app.R;
import hk.busnow.app.data.SeedFormat;

/** Localised text helpers (age, countdown, operator names) that need the activity context. */
public final class L {

    public static final int ARRIVING = -1;
    public static final int DEPARTED = -2;
    public static final int NO_DATA = -3;

    private L() {
    }

    public static Locale locale(int lang) {
        if (lang == 1) {
            return Locale.SIMPLIFIED_CHINESE;
        }
        if (lang == 2) {
            return Locale.ENGLISH;
        }
        return new Locale("zh", "HK");
    }

    /** Which column of the seed's names to use for the current UI language. */
    public static int lang(Context c) {
        Configuration cfg = c.getResources().getConfiguration();
        Locale l = cfg.locale;
        if (l == null) {
            return SeedFormat.TC;
        }
        String code = l.getLanguage();
        if ("en".equals(code)) {
            return SeedFormat.EN;
        }
        if ("zh".equals(code)) {
            String country = l.getCountry();
            String script = l.getScript();
            if ("Hans".equals(script) || "CN".equals(country) || "SG".equals(country)) {
                return SeedFormat.SC;
            }
            return SeedFormat.TC;
        }
        return SeedFormat.TC;
    }

    /** Remaining whole minutes (rounded up), or ARRIVING / DEPARTED. */
    public static int etaMinutes(long etaMs, long nowMs) {
        long ms = etaMs - nowMs;
        if (ms < -60000L) {
            return DEPARTED;
        }
        if (ms < 45000L) {
            return ARRIVING;
        }
        return (int) ((ms + 59999L) / 60000L);
    }

    /**
     * Index of the first arrival that has not already gone (30 s grace), or -1 when every row is
     * in the past. Without this the headline slot can be occupied by a bus that has left.
     */
    public static int firstUpcoming(hk.busnow.app.model.Eta[] list, long nowMs) {
        if (list == null) {
            return -1;
        }
        for (int i = 0; i < list.length; i++) {
            if (list[i].etaMs > nowMs - 30000L) {
                return i;
            }
        }
        return -1;
    }

    public static String ago(Context c, long fetchedAt, long nowMs) {
        long secs = Math.max(0, (nowMs - fetchedAt) / 1000L);
        if (secs < 5) {
            return c.getString(R.string.just_now);
        }
        if (secs < 60) {
            return c.getString(R.string.secs_ago, (int) secs);
        }
        if (secs < 3600) {
            return c.getString(R.string.mins_ago, (int) (secs / 60));
        }
        return c.getString(R.string.hours_ago, (int) (secs / 3600));
    }

    public static String opName(Context c, int op) {
        return c.getString(op == SeedFormat.OP_CTB ? R.string.op_ctb
                : op == 1 ? R.string.op_lwb : R.string.op_kmb);
    }

    public static String distance(Context c, int metres) {
        if (metres < 1000) {
            return c.getString(R.string.distance_m, metres);
        }
        return c.getString(R.string.distance_km, metres / 1000.0);
    }

    public static boolean isSmallScreen(Context c) {
        return c.getResources().getConfiguration().smallestScreenWidthDp < 300;
    }

    public static int dpToPx(Context c, float dp) {
        return Ui.dpi(c, dp);
    }

    public static String stableText(Resources r, int id) {
        return r.getString(id);
    }
}
