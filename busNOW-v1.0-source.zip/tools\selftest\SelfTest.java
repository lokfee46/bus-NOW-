import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.zip.GZIPInputStream;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Eta;
import hk.busnow.app.net.CtbApi;
import hk.busnow.app.net.KmbApi;
import hk.busnow.app.util.Clock;
import hk.busnow.app.util.Json;
import hk.busnow.app.util.TimeUtil;

/**
 * Desktop self-test for the parts of the app that must be right: seed parsing/lookup, JSON parsing,
 * time handling, and the two arrival parsers against recorded real responses.
 *
 * Run with tools\selftest.cmd (uses the plain JDK, no Android).
 */
public final class SelfTest {

    private static int checks;

    public static void main(String[] args) throws Exception {
        Path root = Paths.get(args.length > 0 ? args[0] : ".").toAbsolutePath().normalize();
        timeTests();
        jsonTests();
        clockTests();
        seedTests(root);
        kmbFixture(root);
        ctbFixture(root);
        System.out.println("selftest: PASS " + checks + " checks");
    }

    private static void ok(boolean cond, String what) {
        checks++;
        if (!cond) {
            throw new AssertionError("FAIL: " + what);
        }
    }

    private static void eq(Object got, Object want, String what) {
        ok(got == null ? want == null : got.equals(want),
                what + " (want " + want + ", got " + got + ")");
    }

    // ------------------------------------------------------------------ time
    private static void timeTests() {
        Calendar hk = Calendar.getInstance(TimeZone.getTimeZone("GMT+8"));
        hk.clear();
        hk.set(2026, Calendar.NOVEMBER, 1, 8, 50, 0);
        eq(TimeUtil.parseIso("2026-11-01T08:50:00+08:00"), hk.getTimeInMillis(), "iso with +08:00");

        Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        utc.clear();
        utc.set(2026, Calendar.NOVEMBER, 1, 8, 50, 0);
        eq(TimeUtil.parseIso("2026-11-01T08:50:00Z"), utc.getTimeInMillis(), "iso with Z");
        eq(TimeUtil.parseIso("2026-11-01T08:50:00.250+08:00"),
                hk.getTimeInMillis() + 250L, "iso with millis");

        eq(TimeUtil.hhmm(hk.getTimeInMillis()), "08:50", "hhmm");
        eq(TimeUtil.hhmmss(hk.getTimeInMillis()), "08:50:00", "hhmmss");
        eq(TimeUtil.minutesUntil(hk.getTimeInMillis() + 121000L, hk.getTimeInMillis()), 3, "minutes ceil");
        eq(TimeUtil.minutesUntil(hk.getTimeInMillis() + 59000L, hk.getTimeInMillis()), 1, "minutes under a minute");
        eq(TimeUtil.minutesUntil(hk.getTimeInMillis() - 1000L, hk.getTimeInMillis()), 0, "minutes past");
        eq(TimeUtil.parseIso("garbage"), 0L, "iso garbage");
    }

    // ------------------------------------------------------------------ json
    private static void jsonTests() {
        Object v = Json.parse("{\"a\":\"x\\u4e2d\",\"b\":[1,2.5,true,null],\"c\":{\"d\":\"e\"}}");
        Map<String, Object> o = Json.obj(v);
        eq(Json.str(o, "a"), "x中", "json unicode escape");
        List<Object> b = Json.arr(o.get("b"));
        eq(b.size(), 4, "json array size");
        eq(((Number) b.get(0)).longValue(), 1L, "json int");
        ok(b.get(1) instanceof Double, "json double");
        eq(Json.str(Json.obj(o.get("c")), "d"), "e", "json nested");
        eq(Json.str(o, "missing"), null, "json missing key");
    }

    // ------------------------------------------------------------------ clock
    private static void clockTests() {
        Clock.reset();
        long recv = System.currentTimeMillis();
        long sent = recv - 400L;
        long server = recv + 3000L;
        Clock.observe(server, sent, recv);
        eq(Clock.offset(), server + 200L - recv, "server clock offset");
        ok(Clock.synced(), "clock marked synced");
        Clock.reset();
        Clock.observe(0L, 10L, 20L);
        ok(!Clock.synced(), "missing Date header ignored");
    }

    // ------------------------------------------------------------------- seed
    private static void seedTests(Path root) throws Exception {
        byte[] raw = gunzip(root.resolve("assets/seed.bin.gz"));
        SeedFormat s = SeedFormat.parse(raw);
        ok(s.stopCount > 5000, "seed stops");
        ok(s.routeCount > 1500, "seed routes");
        ok(s.refCount > 30000, "seed refs");
        ok(s.generatedAt > 1700000000L, "seed timestamp");

        int kmbStop = s.findStop(SeedFormat.OP_KMB, 0xA3ADFCDF8487ADB9L);
        ok(kmbStop >= 0, "find KMB stop by key");
        ok(s.stopName(kmbStop, SeedFormat.TC).contains("中秀茂坪"), "KMB stop name TC");
        eq(s.stopId(kmbStop), "A3ADFCDF8487ADB9", "KMB stop id round-trip");

        int ctbStop = s.findStop(SeedFormat.OP_CTB, 1027L);
        ok(ctbStop >= 0, "find CTB stop by key");
        ok(s.stopName(ctbStop, SeedFormat.TC).contains("中環"), "CTB stop name TC");
        eq(s.stopId(ctbStop), "001027", "CTB stop id round-trip");

        int[] r1a = s.searchRoutes("1a", 10);
        ok(r1a.length > 0, "route search is case-insensitive");
        boolean out = false;
        boolean in = false;
        for (int r : r1a) {
            if (s.routeName(r).equalsIgnoreCase("1A")) {
                if (s.routeBound[r] == 0) {
                    out = true;
                } else {
                    in = true;
                }
            }
        }
        ok(out && in, "route 1A has both directions");

        int[] stops = s.searchStops("旺角", 10);
        ok(stops.length > 0, "stop search by TC name");
        ok(s.searchStops("Mong Kok", 10).length > 0, "stop search by EN name");

        int[] board = s.routesAtStop(kmbStop);
        ok(board.length > 0, "routes at stop");
        boolean has1a = false;
        for (int r : board) {
            if (s.routeName(r).equals("1A")) {
                has1a = true;
            }
        }
        ok(has1a, "1A calls at the test stop");

        for (int r = 0; r < s.routeCount; r++) {
            int start = s.routeRefStart[r];
            int count = s.routeRefCount[r];
            ok(start >= 0 && count > 0 && start + count <= s.refCount, "route ref range " + r);
        }
        for (int k = 0; k < s.refCount; k++) {
            ok(s.refs[k] >= 0 && s.refs[k] < s.stopCount, "ref target " + k);
        }

        int[] near = s.nearby(22.318856, 114.231353, 5);
        eq(near.length, 5, "nearby limit");
        ok(s.distanceTo(near[0], 22.318856, 114.231353) < 300, "nearest stop is the stop itself");

        byte[] bad = raw.clone();
        bad[bad.length - 1] ^= 0x5A;
        boolean rejected = false;
        try {
            SeedFormat.parse(bad);
        } catch (Exception e) {
            rejected = true;
        }
        ok(rejected, "checksum rejects a tampered seed");
    }

    // ------------------------------------------------------------- fixtures
    private static void kmbFixture(Path root) throws Exception {
        String body = new String(Files.readAllBytes(root.resolve("tools/fixtures/kmb-eta.json")), "UTF-8");
        Arrivals out = KmbApi.parse(body, 1, 0, SeedFormat.TC, 3, 0L);
        ok(out.ok(), "kmb parse ok");
        ok(out.list.length > 0, "kmb outbound rows");
        for (Eta e : out.list) {
            ok(e.destTc.contains("尖沙咀"), "kmb outbound filtered to its own direction: " + e.destTc);
            ok(e.etaMs > 0, "kmb eta parsed");
        }
        Arrivals in = KmbApi.parse(body, 1, 1, SeedFormat.TC, 3, 0L);
        ok(in.list.length > 0, "kmb inbound rows");
        for (Eta e : in.list) {
            ok(e.destTc.contains("中秀茂坪"), "kmb inbound filtered: " + e.destTc);
        }
        ok(out.list[0].etaMs <= out.list[out.list.length - 1].etaMs, "kmb sorted ascending");

        Arrivals none = KmbApi.parse(body, 9, 0, SeedFormat.TC, 3, 0L);
        eq(none.list.length, 0, "unknown service type yields nothing");
    }

    private static void ctbFixture(Path root) throws Exception {
        String body = new String(Files.readAllBytes(root.resolve("tools/fixtures/ctb-stop-eta.json")), "UTF-8");
        CtbApi.StopEta se = CtbApi.parse(body, SeedFormat.TC, 3, 0L);
        ok(se.error == null, "ctb parse ok");
        ok(!se.byRoute.isEmpty(), "ctb routes parsed");
        int rows = 0;
        for (Map.Entry<String, Arrivals> en : se.byRoute.entrySet()) {
            Arrivals a = en.getValue();
            ok(a.list.length > 0 && a.list.length <= 3, "ctb limit per route");
            for (Eta e : a.list) {
                ok(e.etaMs > 0, "ctb eta parsed");
                ok(e.destTc.length() > 0, "ctb dest localised");
            }
            rows += a.list.length;
            ok(en.getKey().contains("|"), "ctb key shape");
        }
        ok(rows > 0, "ctb rows total");
        ok(se.byRoute.containsKey("1|1"), "ctb route 1 inbound present");
    }

    // -------------------------------------------------------------- helpers
    private static byte[] gunzip(Path p) throws Exception {
        InputStream in = new GZIPInputStream(Files.newInputStream(p));
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream(1400000);
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            return bos.toByteArray();
        } finally {
            in.close();
        }
    }
}
