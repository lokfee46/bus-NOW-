package hk.busnow.app.net;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Eta;
import hk.busnow.app.util.Json;
import hk.busnow.app.util.TimeUtil;

/** KMB / LWB ("九巴・龍運") real-time arrivals. */
public final class KmbApi {

    private static final String BASE = "https://data.etabus.gov.hk/v1/transport/kmb";

    private KmbApi() {
    }

    /**
     * Arrivals for one route at one stop. The endpoint returns every direction at that stop, so rows
     * are filtered by direction and service type before anything is shown.
     */
    public static Arrivals eta(String stopId, String route, int svc, int bound, int lang, int limit) {
        long startedAt = System.currentTimeMillis();
        String url = BASE + "/eta/" + stopId + "/" + route + "/" + svc + "?_=" + (startedAt / 1000L);
        try {
            Http.Result r = Http.getRetry(url, 3);
            return parse(r.body, svc, bound, lang, limit, startedAt);
        } catch (IOException e) {
            return new Arrivals(new Eta[0], startedAt, 0, msg(e));
        } catch (RuntimeException e) {
            return new Arrivals(new Eta[0], startedAt, 0, "parse");
        }
    }

    /** Pure parser (kept separate so the desktop self-test can feed it recorded responses). */
    public static Arrivals parse(String body, int svc, int bound, int lang, int limit, long startedAt) {
        Map<String, Object> root = Json.obj(Json.parse(body));
        List<Object> rows = Json.arr(root.get("data"));
        List<Eta> out = new ArrayList<Eta>(limit);
        long dataTs = 0;
        long cutoff = startedAt > 0 ? startedAt - 120000L : Long.MIN_VALUE;
        if (rows != null) {
            for (Object o : rows) {
                Map<String, Object> row = Json.obj(o);
                String dir = Json.str(row, "dir");
                int rowSvc = Json.integer(row, "service_type", 1);
                if (!matchesDir(dir, bound) || rowSvc != svc) {
                    continue;
                }
                long etaMs = TimeUtil.parseIso(Json.str(row, "eta"));
                if (etaMs <= 0 || etaMs < cutoff) {
                    continue;
                }
                long rowTs = TimeUtil.parseIso(Json.str(row, "data_timestamp"));
                if (rowTs > dataTs) {
                    dataTs = rowTs;
                }
                String rmk = pick(Json.str(row, lang == 1 ? "rmk_sc" : lang == 2 ? "rmk_en" : "rmk_tc"),
                        Json.str(row, "rmk_en"),
                        Json.str(row, "rmk_tc"));
                boolean scheduled = isScheduled(rmk, Json.str(row, "rmk_en"));
                out.add(new Eta(etaMs, Json.integer(row, "eta_seq", 0), scheduled, rmk,
                        Json.str(row, "dest_tc"), Json.str(row, "dest_sc"), Json.str(row, "dest_en")));
            }
        }
        Collections.sort(out);
        Eta[] list = out.size() > limit
                ? out.subList(0, limit).toArray(new Eta[limit]) : out.toArray(new Eta[0]);
        return new Arrivals(list, startedAt, dataTs, null);
    }

    static boolean matchesDir(String dir, int bound) {
        if (dir == null) {
            return false;
        }
        return bound == 0 ? "O".equals(dir) : "I".equals(dir);
    }

    static boolean isScheduled(String remark, String rmkEn) {
        String r = (remark == null ? "" : remark) + " " + (rmkEn == null ? "" : rmkEn);
        return r.indexOf("原定") >= 0 || r.indexOf("Scheduled") >= 0 || r.indexOf("班次表") >= 0;
    }

    private static String pick(String a, String b, String c) {
        if (a != null && a.length() > 0) {
            return a;
        }
        if (c != null && c.length() > 0) {
            return c;
        }
        return b == null ? "" : b;
    }

    static String msg(IOException e) {
        String m = e.getMessage();
        return m == null ? "network" : m;
    }
}
