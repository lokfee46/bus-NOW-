package hk.busnow.app.net;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import hk.busnow.app.model.Arrivals;
import hk.busnow.app.model.Eta;
import hk.busnow.app.util.Json;
import hk.busnow.app.util.TimeUtil;

/**
 * Citybus real-time arrivals via the OGCIO batch gateway: one request returns every route serving
 * that stop, which is what makes Citybus cheap for the app (and for the operator's servers).
 */
public final class CtbApi {

    private static final String BASE = "https://rt.data.gov.hk/v1/transport/batch/stop-eta/CTB/";

    private CtbApi() {
    }

    public static final class StopEta {
        public final Map<String, Arrivals> byRoute;
        public final long fetchedAt;
        public final String error;

        StopEta(Map<String, Arrivals> byRoute, long fetchedAt, String error) {
            this.byRoute = byRoute;
            this.fetchedAt = fetchedAt;
            this.error = error;
        }
    }

    public static String key(String route, int bound) {
        return route + "|" + bound;
    }

    public static StopEta stopEta(String stopId, int lang, int limit) {
        long startedAt = System.currentTimeMillis();
        String langCode = lang == 1 ? "zh-hans" : lang == 2 ? "en" : "zh-hant";
        String url = BASE + stopId + "?lang=" + langCode + "&_=" + (startedAt / 1000L);
        try {
            Http.Result r = Http.getRetry(url, 3);
            return parse(r.body, lang, limit, startedAt);
        } catch (IOException e) {
            return new StopEta(new HashMap<String, Arrivals>(), startedAt, KmbApi.msg(e));
        } catch (RuntimeException e) {
            return new StopEta(new HashMap<String, Arrivals>(), startedAt, "parse");
        }
    }

    /** Pure parser, used by the app and by the desktop self-test. */
    public static StopEta parse(String body, int lang, int limit, long startedAt) {
        Map<String, Object> root = Json.obj(Json.parse(body));
        List<Object> rows = Json.arr(root.get("data"));
        Map<String, List<Eta>> grouped = new HashMap<String, List<Eta>>();
        long dataTs = 0;
        long cutoff = startedAt > 0 ? startedAt - 120000L : Long.MIN_VALUE;
        if (rows != null) {
            for (Object o : rows) {
                Map<String, Object> row = Json.obj(o);
                String route = Json.str(row, "route");
                String dir = Json.str(row, "dir");
                if (route == null || dir == null) {
                    continue;
                }
                long etaMs = TimeUtil.parseIso(Json.str(row, "eta"));
                if (etaMs <= 0 || etaMs < cutoff) {
                    continue;
                }
                long rowTs = TimeUtil.parseIso(Json.str(row, "data_timestamp"));
                if (rowTs > dataTs) {
                    dataTs = rowTs;
                }
                int bound = "I".equals(dir) ? 1 : 0;
                String rmk = Json.str(row, "rmk");
                boolean scheduled = Json.bool(row, "noGPS") || KmbApi.isScheduled(rmk, null);
                String dest = Json.str(row, "dest");
                Eta e = new Eta(etaMs, Json.integer(row, "eta_seq", 0), scheduled, rmk,
                        lang == 0 ? dest : "", lang == 1 ? dest : "", lang == 2 ? dest : "");
                String key = key(route, bound);
                List<Eta> list = grouped.get(key);
                if (list == null) {
                    list = new ArrayList<Eta>(3);
                    grouped.put(key, list);
                }
                list.add(e);
            }
        }
        Map<String, Arrivals> byRoute = new HashMap<String, Arrivals>();
        for (Map.Entry<String, List<Eta>> en : grouped.entrySet()) {
            List<Eta> list = en.getValue();
            Collections.sort(list);
            Eta[] arr = list.size() > limit
                    ? list.subList(0, limit).toArray(new Eta[limit]) : list.toArray(new Eta[0]);
            byRoute.put(en.getKey(), new Arrivals(arr, startedAt, dataTs, null));
        }
        return new StopEta(byRoute, startedAt, null);
    }
}
