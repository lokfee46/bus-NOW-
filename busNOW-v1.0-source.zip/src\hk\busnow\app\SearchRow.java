package hk.busnow.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import hk.busnow.app.data.SeedFormat;
import hk.busnow.app.ui.L;
import hk.busnow.app.ui.Style;

/** Adapter for search results: routes or stops, never both at once. */
final class SearchRow extends BaseAdapter {

    static final int MODE_ROUTE = 0;
    static final int MODE_STOP = 1;

    private final Context c;
    private final SeedFormat seed;
    private final int lang;
    private final int ink3;
    private int mode = MODE_ROUTE;
    private int[] routes = new int[0];
    private int[] stops = new int[0];

    SearchRow(Context c, SeedFormat seed, int lang) {
        this.c = c;
        this.seed = seed;
        this.lang = lang;
        this.ink3 = c.getResources().getColor(R.color.ink3);
    }

    void setData(int mode, int[] routes, int[] stops) {
        this.mode = mode;
        this.routes = routes == null ? new int[0] : routes;
        this.stops = stops == null ? new int[0] : stops;
        notifyDataSetChanged();
    }

    SeedFormat seed() {
        return seed;
    }

    int mode() {
        return mode;
    }

    int routeAt(int position) {
        return routes[position];
    }

    int stopAt(int position) {
        return stops[position];
    }

    @Override
    public int getCount() {
        return mode == MODE_ROUTE ? routes.length : stops.length;
    }

    @Override
    public Object getItem(int position) {
        return mode == MODE_ROUTE ? Integer.valueOf(routes[position]) : Integer.valueOf(stops[position]);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    @Override
    public int getItemViewType(int position) {
        return mode;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (mode == MODE_ROUTE) {
            return routeView(position, convertView, parent);
        }
        return stopView(position, convertView, parent);
    }

    private View routeView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null || v.getTag() == null || !(v.getTag() instanceof RouteHolder)) {
            v = LayoutInflater.from(c).inflate(R.layout.item_route, parent, false);
            RouteHolder h = new RouteHolder();
            h.badge = (TextView) v.findViewById(R.id.badge);
            h.title = (TextView) v.findViewById(R.id.title);
            h.subtitle = (TextView) v.findViewById(R.id.subtitle);
            h.chevron = (ImageView) v.findViewById(R.id.chevron);
            h.chevron.setColorFilter(ink3);
            v.setTag(h);
        }
        RouteHolder h = (RouteHolder) v.getTag();
        int ri = routes[position];
        Style.routeBadge(h.badge, seed.routeOp[ri]);
        h.badge.setText(seed.routeName(ri));
        h.title.setText(c.getString(R.string.direction_to, seed.routeDest(ri, lang)));
        String sub = L.opName(c, seed.routeOp[ri]);
        if (seed.routeSvc[ri] != 1) {
            sub = sub + " · " + c.getString(R.string.service_type, seed.routeSvc[ri]);
        }
        h.subtitle.setText(sub);
        return v;
    }

    private View stopView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null || v.getTag() == null || !(v.getTag() instanceof StopHolder)) {
            v = LayoutInflater.from(c).inflate(R.layout.item_stop, parent, false);
            StopHolder h = new StopHolder();
            h.title = (TextView) v.findViewById(R.id.title);
            h.subtitle = (TextView) v.findViewById(R.id.subtitle);
            h.chevron = (ImageView) v.findViewById(R.id.chevron);
            h.chevron.setColorFilter(ink3);
            v.setTag(h);
        }
        StopHolder h = (StopHolder) v.getTag();
        int si = stops[position];
        h.title.setText(seed.stopName(si, lang));
        h.subtitle.setText(L.opName(c, seed.stopOp[si]));
        return v;
    }

    private static final class RouteHolder {
        TextView badge;
        TextView title;
        TextView subtitle;
        ImageView chevron;
    }

    private static final class StopHolder {
        TextView title;
        TextView subtitle;
        ImageView chevron;
    }
}
