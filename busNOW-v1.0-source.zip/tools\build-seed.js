'use strict';
/*
 * Builds assets/seed.bin.gz — the offline route/stop index shipped inside the APK.
 *
 * Sources (official open data, see docs/02):
 *   KMB/LWB : https://data.etabus.gov.hk/v1/transport/kmb/{route,stop,route-stop}
 *   Citybus : https://rt.data.gov.hk/v2/transport/citybus/{route/CTB,route-stop/CTB/{r}/{dir},stop/{id}}
 *
 * KMB is fetched with curl: its WAF rejects the TLS fingerprint of Node's OpenSSL stack (403).
 * Citybus is fetched with Node's https agent (keep-alive, 12 sockets) because it is a lot of calls.
 *
 * Everything is cached under tools/.seed-cache/ so a re-run is instant and resumable.
 *
 * usage:
 *   node tools/build-seed.js            # use cache when present
 *   node tools/build-seed.js --refresh  # ignore cache
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const https = require('https');
const { execFileSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const CACHE = path.join(ROOT, 'tools', '.seed-cache');
const REFRESH = process.argv.includes('--refresh');
const UA = 'busNOW-seed/1.0 (offline index builder)';

const agent = new https.Agent({ keepAlive: true, maxSockets: 12 });
const OP_KMB = 0;
const OP_CTB = 1;

// ---------------------------------------------------------------- fetch utils
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/** Synchronous sleep, only used on the curl (KMB) retry path. */
function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function getJson(url, tries = 5) {
  return new Promise((resolve, reject) => {
    const attempt = (n) => {
      const req = https.get(url, {
        agent,
        family: 4,
        headers: { 'accept-encoding': 'gzip', 'accept': 'application/json', 'user-agent': UA },
      }, (res) => {
        if (res.statusCode === 429 || res.statusCode >= 500) {
          res.resume();
          if (n < tries) return void sleep(700 * n).then(() => attempt(n + 1));
          return reject(new Error('HTTP ' + res.statusCode + ' ' + url));
        }
        if (res.statusCode !== 200) {
          res.resume();
          return reject(new Error('HTTP ' + res.statusCode + ' ' + url));
        }
        let stream = res;
        if (res.headers['content-encoding'] === 'gzip') stream = res.pipe(zlib.createGunzip());
        const chunks = [];
        stream.on('data', (d) => chunks.push(d));
        stream.on('end', () => {
          try {
            resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
          } catch (e) {
            if (n < tries) return void sleep(700 * n).then(() => attempt(n + 1));
            reject(e);
          }
        });
        stream.on('error', reject);
      });
      req.setTimeout(45000, () => req.destroy(new Error('timeout ' + url)));
      req.on('error', (e) => {
        if (n < tries) return void sleep(700 * n).then(() => attempt(n + 1));
        reject(e);
      });
    };
    attempt(1);
  });
}

function cachedJson(name) {
  const p = path.join(CACHE, name);
  if (!REFRESH && fs.existsSync(p) && fs.statSync(p).size > 8) {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  }
  return null;
}

function saveJson(name, obj) {
  const p = path.join(CACHE, name);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj));
}

function curlJson(url, name, tries = 5) {
  const hit = cachedJson(name);
  if (hit) return hit;
  let last;
  const backoff = [5000, 15000, 30000, 60000];
  for (let i = 0; i < tries; i++) {
    try {
      const bin = execFileSync(process.platform === 'win32' ? 'curl.exe' : 'curl', [
        '-sS', '--compressed', '--max-time', '150',
        '-H', 'Accept: application/json',
        '-H', 'Accept-Language: zh-HK,zh;q=0.9,en;q=0.8',
        '-H', 'Referer: https://data.gov.hk/',
        '-H', 'User-Agent: Mozilla/5.0 (Linux; Android 13) busNOW/1.0',
        url,
      ], { maxBuffer: 256 * 1024 * 1024 });
      const text = bin.toString('utf8');
      if (text.charCodeAt(0) !== 123) {
        throw new Error('non-JSON response (' + text.length + ' bytes)');
      }
      const obj = JSON.parse(text);
      saveJson(name, obj);
      return obj;
    } catch (e) {
      last = e;
      console.warn('  curl retry ' + (i + 1) + '/' + tries + ' ' + url + ' -> ' + e.message);
      sleepSync(backoff[Math.min(i, backoff.length - 1)]);
    }
  }
  throw last;
}

async function mapLimit(items, limit, fn, label) {
  let next = 0;
  let done = 0;
  const workers = new Array(Math.min(limit, items.length)).fill(0).map(async () => {
    for (;;) {
      const i = next++;
      if (i >= items.length) return;
      await fn(items[i], i);
      done++;
      if (label && done % 200 === 0) console.log('  ' + label + ' ' + done + '/' + items.length);
    }
  });
  await Promise.all(workers);
}

// ------------------------------------------------------------------ bigint u64
function u64(hexOrDec, radix) {
  try {
    return radix === 16 ? BigInt('0x' + hexOrDec) : BigInt(hexOrDec);
  } catch (e) {
    return null;
  }
}

// ------------------------------------------------------------------- collect
async function collectKmb() {
  const API = 'https://data.etabus.gov.hk/v1/transport/kmb';
  console.log('KMB: route list');
  const routes = curlJson(API + '/route', 'kmb/route.json').data;
  console.log('KMB: stop list');
  const stops = curlJson(API + '/stop', 'kmb/stop.json').data;
  console.log('KMB: route-stop');
  const rs = curlJson(API + '/route-stop', 'kmb/route-stop.json').data;
  console.log('  routes=' + routes.length + ' stops=' + stops.length + ' refs=' + rs.length);

  const stopById = new Map();
  for (const s of stops) {
    const k = u64(s.stop, 16);
    if (k === null) continue;
    stopById.set(s.stop, { key: k, op: OP_KMB, lat: Math.round(parseFloat(s.lat) * 1e6), lon: Math.round(parseFloat(s.long) * 1e6), tc: s.name_tc, sc: s.name_sc, en: s.name_en });
  }

  const groups = new Map();
  for (const r of rs) {
    const key = r.route + '|' + r.bound + '|' + r.service_type;
    let g = groups.get(key);
    if (!g) {
      g = { route: r.route, bound: r.bound, svc: parseInt(r.service_type, 10) || 1, rows: [] };
      groups.set(key, g);
    }
    g.rows.push(r);
  }
  for (const g of groups.values()) {
    g.rows.sort((a, b) => parseInt(a.seq, 10) - parseInt(b.seq, 10));
  }

  const out = [];
  for (const r of routes) {
    const key = r.route + '|' + r.bound + '|' + r.service_type;
    const g = groups.get(key);
    if (!g || !g.rows.length) continue;
    const stopIds = g.rows.map((x) => x.stop);
    out.push({
      op: OP_KMB,
      route: r.route,
      bound: r.bound === 'I' ? 1 : 0,
      svc: parseInt(r.service_type, 10) || 1,
      orig: { tc: r.orig_tc, sc: r.orig_sc, en: r.orig_en },
      dest: { tc: r.dest_tc, sc: r.dest_sc, en: r.dest_en },
      stopIds,
    });
  }
  return { stops: stopById, routes: out };
}

async function collectCtb() {
  console.log('CTB: route list');
  const list = await getJson('https://rt.data.gov.hk/v2/transport/citybus/route/CTB');
  const names = [...new Set(list.data.map((r) => r.route))].sort();
  console.log('  ' + list.data.length + ' entries, ' + names.length + ' distinct routes');

  const routeDirs = [];
  const needed = new Set();
  await mapLimit(names, 10, async (name) => {
    for (const dir of ['outbound', 'inbound']) {
      const cacheName = 'ctb/route-stop/' + encodeURIComponent(name) + '_' + dir + '.json';
      let js = cachedJson(cacheName);
      if (!js) {
        try {
          js = await getJson('https://rt.data.gov.hk/v2/transport/citybus/route-stop/CTB/' +
            encodeURIComponent(name) + '/' + dir);
          saveJson(cacheName, js);
        } catch (e) {
          console.warn('  route-stop fail ' + name + ' ' + dir + ': ' + e.message);
          continue;
        }
      }
      const rows = (js.data || []).slice().sort((a, b) => a.seq - b.seq);
      if (!rows.length) continue;
      for (const r of rows) needed.add(r.stop);
      routeDirs.push({ route: name, bound: dir === 'inbound' ? 1 : 0, stopIds: rows.map((r) => r.stop) });
    }
  }, 'route-stop');
  console.log('  route-directions=' + routeDirs.length + ' distinct stops=' + needed.size);

  const stopMap = new Map();
  const ids = [...needed].sort();
  await mapLimit(ids, 10, async (id) => {
    const cacheName = 'ctb/stop/' + id + '.json';
    let js = cachedJson(cacheName);
    if (!js) {
      try {
        js = await getJson('https://rt.data.gov.hk/v2/transport/citybus/stop/' + id);
        saveJson(cacheName, js);
      } catch (e) {
        console.warn('  stop fail ' + id + ': ' + e.message);
        return;
      }
    }
    const d = js.data;
    if (!d || !d.stop) return;
    stopMap.set(id, {
      key: BigInt(id),
      op: OP_CTB,
      lat: Math.round(parseFloat(d.lat) * 1e6),
      lon: Math.round(parseFloat(d.long) * 1e6),
      tc: d.name_tc,
      sc: d.name_sc,
      en: d.name_en,
    });
  }, 'stop detail');

  // origin/destination come from the real first/last stop names: Citybus' route list has no direction.
  const out = [];
  for (const rd of routeDirs) {
    const first = stopMap.get(rd.stopIds[0]);
    const last = stopMap.get(rd.stopIds[rd.stopIds.length - 1]);
    if (!first || !last) continue;
    out.push({
      op: OP_CTB,
      route: rd.route,
      bound: rd.bound,
      svc: 0,
      orig: { tc: first.tc, sc: first.sc, en: first.en },
      dest: { tc: last.tc, sc: last.sc, en: last.en },
      stopIds: rd.stopIds,
    });
  }
  return { stops: stopMap, routes: out };
}

// ---------------------------------------------------------------- serialise
function build(kmb, ctb) {
  const stopList = [];
  const stopIndexByKey = new Map();
  const opKey = (op, key) => op + ':' + key.toString();

  function internStop(op, id, info) {
    const k = opKey(op, info.key);
    let idx = stopIndexByKey.get(k);
    if (idx !== undefined) return idx;
    idx = stopList.length;
    stopList.push({
      key: info.key,
      op,
      lat: info.lat | 0,
      lon: info.lon | 0,
      tc: info.tc || id,
      sc: info.sc || info.tc || id,
      en: info.en || info.tc || id,
    });
    stopIndexByKey.set(k, idx);
    return idx;
  }

  const routes = [];
  function addRoutes(block) {
    for (const r of block.routes) {
      const refs = [];
      for (const sid of r.stopIds) {
        const info = block.stops.get(sid);
        if (!info) continue;
        refs.push(internStop(r.op, sid, info));
      }
      if (!refs.length) continue;
      routes.push({
        op: r.op,
        route: r.route,
        bound: r.bound,
        svc: r.svc,
        orig: r.orig,
        dest: r.dest,
        refs,
      });
    }
  }
  addRoutes(kmb);
  addRoutes(ctb);

  console.log('  joined: stops=' + stopList.length + ' routes=' + routes.length +
    ' refs=' + routes.reduce((a, r) => a + r.refs.length, 0));

  // --- strings
  const poolMap = new Map();
  const poolOrder = [];
  const emptyOff = 0;
  poolMap.set('', emptyOff);
  poolOrder.push('');
  let poolBytes = 1;
  function strOff(s) {
    if (s === undefined || s === null) s = '';
    s = String(s);
    if (poolMap.has(s)) return poolMap.get(s);
    const off = poolBytes;
    poolMap.set(s, off);
    poolOrder.push(s);
    poolBytes += Buffer.byteLength(s, 'utf8') + 1;
    return off;
  }

  for (const s of stopList) {
    strOff(s.tc);
    strOff(s.sc);
    strOff(s.en);
  }
  for (const r of routes) {
    strOff(r.route);
    strOff(r.orig.tc); strOff(r.orig.sc); strOff(r.orig.en);
    strOff(r.dest.tc); strOff(r.dest.sc); strOff(r.dest.en);
  }

  // --- indices
  const stopIdx = stopList.map((_, i) => i).sort((a, b) => {
    const A = stopList[a];
    const B = stopList[b];
    if (A.op !== B.op) return A.op - B.op;
    return A.key < B.key ? -1 : A.key > B.key ? 1 : 0;
  });
  const routeIdx = routes.map((_, i) => i).sort((a, b) => {
    const A = routes[a];
    const B = routes[b];
    const an = A.route.toUpperCase();
    const bn = B.route.toUpperCase();
    if (an !== bn) return an < bn ? -1 : 1;
    if (A.op !== B.op) return A.op - B.op;
    if (A.bound !== B.bound) return A.bound - B.bound;
    return A.svc - B.svc;
  });

  // --- layout
  const HEADER = 64;
  const poolOff = HEADER;
  const stopsOff = poolOff + poolBytes;
  const stopsBytes = stopList.length * 32;
  const routesOff = stopsOff + stopsBytes;
  const ROUTE_RECORD = 40;
  const routesBytes = routes.length * ROUTE_RECORD;
  const refsOff = routesOff + routesBytes;
  const refsCount = routes.reduce((a, r) => a + r.refs.length, 0);
  const refsBytes = refsCount * 2;
  const stopIndexOff = refsOff + refsBytes;
  const stopIndexBytes = stopIdx.length * 4;
  const routeIndexOff = stopIndexOff + stopIndexBytes;
  const routeIndexBytes = routeIdx.length * 4;
  const total = routeIndexOff + routeIndexBytes;

  const buf = Buffer.alloc(total);
  buf.write('BNOW', 0, 'ascii');
  buf.writeUInt16LE(1, 4);
  buf.writeUInt16LE(0, 6);
  buf.writeUInt32LE(Math.floor(Date.now() / 1000), 8);
  buf.writeUInt32LE(stopList.length, 12);
  buf.writeUInt32LE(routes.length, 16);
  buf.writeUInt32LE(refsCount, 20);
  buf.writeUInt32LE(poolBytes, 24);
  buf.writeUInt32LE(poolOff, 28);
  buf.writeUInt32LE(stopsOff, 32);
  buf.writeUInt32LE(routesOff, 36);
  buf.writeUInt32LE(refsOff, 40);
  buf.writeUInt32LE(stopIndexOff, 44);
  buf.writeUInt32LE(routeIndexOff, 48);
  buf.writeUInt32LE(0, 52); // crc, filled last

  // pool
  let p = poolOff;
  for (const s of poolOrder) {
    if (s) {
      buf.write(s, p, 'utf8');
      p += Buffer.byteLength(s, 'utf8');
    }
    buf[p++] = 0;
  }

  // stops
  p = stopsOff;
  for (const s of stopList) {
    buf.writeBigUInt64LE(s.key, p);
    buf.writeUInt8(s.op, p + 8);
    buf.writeUInt8(0, p + 9);
    buf.writeUInt16LE(0, p + 10);
    buf.writeInt32LE(s.lat, p + 12);
    buf.writeInt32LE(s.lon, p + 16);
    buf.writeUInt32LE(strOff(s.tc), p + 20);
    buf.writeUInt32LE(strOff(s.sc), p + 24);
    buf.writeUInt32LE(strOff(s.en), p + 28);
    p += 32;
  }

  // routes + refs
  p = routesOff;
  let refAt = refsOff;
  for (const r of routes) {
    buf.writeUInt8(r.op, p);
    buf.writeUInt8(r.bound, p + 1);
    buf.writeUInt8(r.svc, p + 2);
    buf.writeUInt8(0, p + 3);
    buf.writeUInt32LE(strOff(r.route), p + 4);
    buf.writeUInt32LE(strOff(r.orig.tc), p + 8);
    buf.writeUInt32LE(strOff(r.orig.sc), p + 12);
    buf.writeUInt32LE(strOff(r.orig.en), p + 16);
    buf.writeUInt32LE(strOff(r.dest.tc), p + 20);
    buf.writeUInt32LE(strOff(r.dest.sc), p + 24);
    buf.writeUInt32LE(strOff(r.dest.en), p + 28);
    buf.writeUInt32LE((refAt - refsOff) / 2, p + 32);
    buf.writeUInt16LE(r.refs.length, p + 36);
    buf.writeUInt16LE(0, p + 38);
    p += ROUTE_RECORD;
    for (const idx of r.refs) {
      buf.writeUInt16LE(idx, refAt);
      refAt += 2;
    }
  }

  for (let i = 0; i < stopIdx.length; i++) buf.writeUInt32LE(stopIdx[i], stopIndexOff + i * 4);
  for (let i = 0; i < routeIdx.length; i++) buf.writeUInt32LE(routeIdx[i], routeIndexOff + i * 4);

  const crc = zlib.crc32(buf) >>> 0;
  buf.writeUInt32LE(crc, 52);

  return {
    buf,
    stops: stopList.length,
    routes: routes.length,
    refs: refsCount,
    pool: poolBytes,
    crc,
  };
}

// --------------------------------------------------------------------- main
(async () => {
  const t0 = Date.now();
  fs.mkdirSync(CACHE, { recursive: true });
  const kmb = await collectKmb();
  const ctb = await collectCtb();
  const built = build(kmb, ctb);
  const gz = zlib.gzipSync(built.buf, { level: 9 });
  const outDir = path.join(ROOT, 'assets');
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, 'seed.bin.gz'), gz);
  const manifest = {
    format: 'BNOW',
    version: 1,
    generatedAt: new Date().toISOString(),
    counts: { stops: built.stops, routes: built.routes, refs: built.refs },
    sizes: { raw: built.buf.length, gzip: gz.length, pool: built.pool },
    crc32: built.crc >>> 0,
    sha256: require('crypto').createHash('sha256').update(gz).digest('hex'),
  };
  fs.writeFileSync(path.join(outDir, 'seed-manifest.json'), JSON.stringify(manifest, null, 2));
  console.log('seed: ' + (gz.length / 1024).toFixed(1) + ' KB gzip / ' +
    (built.buf.length / 1024).toFixed(1) + ' KB raw, stops=' + built.stops +
    ' routes=' + built.routes + ' refs=' + built.refs +
    ' pool=' + (built.pool / 1024).toFixed(0) + ' KB, ' + ((Date.now() - t0) / 1000).toFixed(1) + 's');
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
