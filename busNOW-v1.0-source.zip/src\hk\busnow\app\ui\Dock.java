package hk.busnow.app.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import hk.busnow.app.R;

/** Floating glass tab bar. */
public class Dock extends GlassCard {

    public static final int NOW = 0;
    public static final int SEARCH = 1;
    public static final int NEARBY = 2;
    public static final int SETTINGS = 3;

    public interface OnPick {
        void onPick(int tab);
    }

    private final LinearLayout row;
    private final View[] items = new View[4];
    private final ImageView[] icons = new ImageView[4];
    private final TextView[] labels = new TextView[4];
    private int selected = -1;
    private OnPick listener;

    public Dock(Context c, AttributeSet attrs) {
        super(c, attrs);
        setRadius(26);
        row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        addView(row, new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        int[] iconRes = {R.drawable.ic_home, R.drawable.ic_search,
                R.drawable.ic_nearby, R.drawable.ic_settings};
        int[] labelRes = {R.string.tab_now, R.string.tab_search,
                R.string.tab_nearby, R.string.tab_settings};
        for (int i = 0; i < 4; i++) {
            LinearLayout item = new LinearLayout(c);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setClickable(true);
            item.setFocusable(true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    LayoutParams.MATCH_PARENT, 1f);
            item.setLayoutParams(lp);

            ImageView icon = new ImageView(c);
            icon.setImageResource(iconRes[i]);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                    Ui.dpi(c, 21), Ui.dpi(c, 21));
            icon.setLayoutParams(ilp);
            item.addView(icon);

            TextView label = new TextView(c);
            label.setText(labelRes[i]);
            label.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 9.5f);
            label.setTypeface(Ui.medium());
            label.setGravity(Gravity.CENTER);
            label.setIncludeFontPadding(false);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            tlp.topMargin = Ui.dpi(c, 2);
            label.setLayoutParams(tlp);
            item.addView(label);

            final int tab = i;
            item.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onPick(tab);
                    }
                }
            });
            row.addView(item);
            items[i] = item;
            icons[i] = icon;
            labels[i] = label;
        }
        select(NOW);
    }

    public void setOnPick(OnPick l) {
        listener = l;
    }

    /** Watch-sized screens: keep the icons, drop the labels and shrink the touch targets. */
    public void setCompact(boolean compact) {
        for (int i = 0; i < 4; i++) {
            labels[i].setVisibility(compact ? GONE : VISIBLE);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) icons[i].getLayoutParams();
            int size = Ui.dpi(getContext(), compact ? 19 : 21);
            if (lp.width != size) {
                lp.width = size;
                lp.height = size;
                icons[i].setLayoutParams(lp);
            }
        }
    }

    public void select(int tab) {
        selected = tab;
        int ink = getResources().getColor(R.color.ink3);
        int accent = getResources().getColor(R.color.accent);
        int accentBg = Ui.alpha(getResources().getColor(R.color.accent), 0x24);
        for (int i = 0; i < 4; i++) {
            boolean on = i == tab;
            int color = on ? accent : ink;
            icons[i].setImageTintList(ColorStateList.valueOf(color));
            labels[i].setTextColor(color);
            if (on) {
                GradientDrawable bg = new GradientDrawable();
                bg.setCornerRadius(Ui.dp(getContext(), 15));
                bg.setColor(accentBg);
                items[i].setBackground(bg);
                items[i].setPadding(0, Ui.dpi(getContext(), 3), 0, Ui.dpi(getContext(), 3));
            } else {
                items[i].setBackground(null);
                items[i].setPadding(0, Ui.dpi(getContext(), 3), 0, Ui.dpi(getContext(), 3));
            }
        }
    }

    public int selected() {
        return selected;
    }
}
