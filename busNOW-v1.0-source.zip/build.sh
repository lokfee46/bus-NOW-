#!/usr/bin/env bash
# bus NOW - command line Android build (no Gradle, no third-party dependencies).
#
# Requires: JAVA_HOME (JDK 17+), ANDROID_SDK_ROOT (or ANDROID_HOME) with build-tools 36 and
# platform android-36, Node.js.
#
# NOTE: this script mirrors build.cmd one-to-one, but it has not been executed on the Windows
# build machine (no bash there). The Windows path is the verified one.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

: "${JAVA_HOME:?set JAVA_HOME to a JDK 17+}"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [ -z "$SDK" ]; then
  echo "[busNOW] set ANDROID_SDK_ROOT (or ANDROID_HOME)" >&2
  exit 1
fi

BT="$(ls -d "$SDK"/build-tools/* 2>/dev/null | sort -V | tail -1)"
PLAT="$(ls -d "$SDK"/platforms/android-3* 2>/dev/null | sort -V | tail -1)"
PLAT_JAR="$PLAT/android.jar"
[ -x "$BT/aapt2" ] || { echo "[busNOW] aapt2 not found in $BT" >&2; exit 1; }
[ -f "$PLAT_JAR" ] || { echo "[busNOW] android.jar not found under $SDK/platforms" >&2; exit 1; }
command -v node >/dev/null || { echo "[busNOW] node not found" >&2; exit 1; }

VERSION="$(awk -F= '$1=="name"{print $2}' version.txt)"
VERCODE="$(awk -F= '$1=="code"{print $2}' version.txt)"

BUILD="$ROOT/build"
GEN="$BUILD/gen"
CLS="$BUILD/classes"
DEX="$BUILD/dex"
OUT="$ROOT/dist"
KS="$ROOT/keystore/busnow.keystore"
KSPASS="busnow2026"
APK="$OUT/busNOW-$VERSION.apk"

rm -rf "$BUILD"
mkdir -p "$GEN" "$CLS" "$DEX" "$OUT" "$ROOT/keystore"

echo "[busNOW] version $VERSION ($VERCODE) / $BT"

echo "==> icons"
node tools/make-icons.js

echo "==> aapt2 compile"
"$BT/aapt2" compile --dir res -o "$BUILD/res.zip" --no-crunch

echo "==> aapt2 link"
"$BT/aapt2" link -o "$BUILD/base.apk" -I "$PLAT_JAR" --manifest AndroidManifest.xml \
  -R "$BUILD/res.zip" -A "$ROOT/assets" --java "$GEN" \
  --min-sdk-version 21 --target-sdk-version 36 \
  --version-code "$VERCODE" --version-name "$VERSION" --auto-add-overlay

mkdir -p "$GEN/hk/busnow/app"
cat > "$GEN/hk/busnow/app/Version.java" <<EOF
package hk.busnow.app;

public final class Version {
    public static final String NAME = "$VERSION";
    public static final int CODE = $VERCODE;
    private Version() {}
}
EOF

echo "==> javac"
find src "$GEN" -name '*.java' | sed 's/.*/"&"/' > "$BUILD/sources.txt"
"$JAVA_HOME/bin/javac" -encoding UTF-8 -source 8 -target 8 -bootclasspath "$PLAT_JAR" \
  -classpath "$PLAT_JAR" -d "$CLS" -nowarn -Xlint:none "@$BUILD/sources.txt"

echo "==> d8"
# d8's argfile must contain bare paths (it does not strip quotes)
find "$CLS" -name '*.class' > "$BUILD/classes.txt"
"$BT/d8" --release --min-api 21 --lib "$PLAT_JAR" --output "$DEX" "@$BUILD/classes.txt"

echo "==> pack"
node tools/pack.js "$BUILD/base.apk" "$DEX/classes.dex" "$BUILD/unsigned.apk"

echo "==> zipalign check"
"$BT/zipalign" -c -p -v 4 "$BUILD/unsigned.apk" > /dev/null

echo "==> sign"
if [ ! -f "$KS" ]; then
  "$JAVA_HOME/bin/keytool" -genkeypair -keystore "$KS" -alias busnow -keyalg RSA -keysize 2048 \
    -validity 10950 -storepass "$KSPASS" -keypass "$KSPASS" \
    -dname "CN=bus NOW, OU=hk.busnow, O=busnow, L=Hong Kong, C=HK"
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias busnow \
  --ks-pass "pass:$KSPASS" --key-pass "pass:$KSPASS" \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$APK" "$BUILD/unsigned.apk"
"$BT/apksigner" verify --print-certs "$APK" > /dev/null

echo "==> verify"
"$BT/aapt2" dump badging "$APK" | head -8
node tools/verify-apk.js "$APK"

SIZE="$(wc -c < "$APK")"
echo "output: $APK"
echo "size:   $SIZE bytes"
if [ "$SIZE" -gt 819200 ]; then
  echo "[fail] APK larger than the 800 KB budget" >&2
  exit 1
fi
echo "[busNOW] build ok"
