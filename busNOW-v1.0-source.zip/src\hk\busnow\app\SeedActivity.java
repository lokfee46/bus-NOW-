package hk.busnow.app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import hk.busnow.app.data.Seed;
import hk.busnow.app.data.SeedFormat;

/** Base for screens that cannot render before the bundled index is parsed (usually < 100 ms). */
public abstract class SeedActivity extends BaseActivity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private int waits;

    protected abstract void onSeedReady(SeedFormat seed);

    protected void onSeedMissing() {
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Seed.preload(this);
        main.post(new Runnable() {
            @Override
            public void run() {
                poll();
            }
        });
    }

    private void poll() {
        if (isFinishing()) {
            return;
        }
        SeedFormat s = Seed.peek();
        if (s != null) {
            onSeedReady(s);
            return;
        }
        if (waits++ > 100) {
            onSeedMissing();
            return;
        }
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                poll();
            }
        }, 120L);
    }
}
